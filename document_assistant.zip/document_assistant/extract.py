# -*- coding: utf-8 -*-
"""docx -> structured JSON + markdown.   pip install lxml"""
import json, re, sys, zipfile
from pathlib import Path
from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
def q(t): return "{%s}%s" % (W, t)
def tag(e): return etree.QName(e).localname if isinstance(e.tag, str) else ""

clean = lambda s: re.sub(r"\s+", " ", s or "").strip()

VALID_TRACKED_CHANGES = ("accepted", "original", "all")


def text_of(p, mode: str = "accepted") -> str:
    """Collects a paragraph's text, honouring Word's Track Changes per `mode`.

    A tracked edit wraps its run in `<w:ins>` (inserted — text lives in the
    normal `<w:t>`) or `<w:del>` (deleted — text lives in `<w:delText>`, a
    DIFFERENT tag). The naive `p.iter(q("t"))` this replaced always picked up
    `<w:ins>` text (no filter) and never `<w:delText>` (wrong tag entirely) —
    which is the "accepted" reading by accident, REGARDLESS of what
    `tracked_changes` was actually set to. `original` and `all` silently
    behaved exactly like `accepted`.

      accepted  — insertions kept, deletions dropped (the merged, final text)
      original  — insertions dropped, deletions kept (text as it stood before
                  the proposed edits — what unaccepted tracked changes would
                  make a compliance reading of "current policy" wrong about)
      all       — both kept, nothing filtered (everything anyone proposed)
    """
    parts: list[str] = []

    def walk_runs(el, in_ins: bool, in_del: bool) -> None:
        name = tag(el)
        if name == "ins":
            in_ins = True
        elif name == "del":
            in_del = True
        elif name == "t":
            if not in_del and not (mode == "original" and in_ins):
                parts.append(el.text or "")
        elif name == "delText":
            if mode in ("original", "all"):
                parts.append(el.text or "")
        for child in el:
            walk_runs(child, in_ins, in_del)

    walk_runs(p, False, False)
    return "".join(parts)

# A vertically merged cell's continuation rows carry the value of the cell
# above them. REPEAT_VMERGE=True writes that value into every continuation
# row, which reads unambiguously; False leaves them blank, like Word shows.
REPEAT_VMERGE = True


def is_heading(p, txt):
    pPr = p.find(q("pPr"))
    if pPr is not None:
        st = pPr.find(q("pStyle"))
        if st is not None and (st.get(q("val")) or "").lower().startswith("heading"):
            return True
    return len(txt) < 90 and (txt.isupper() or bool(re.match(r"^\d+(\.\d+)*[.)]?\s+\S", txt)))


def is_list(p):
    pPr = p.find(q("pPr"))
    return pPr is not None and pPr.find(q("numPr")) is not None


def table_rows(tbl, mode: str = "accepted"):
    """Rows of this table only — nested tables are handled separately.
    Continuation cells of a vertical merge keep their column position so the
    grid stays aligned."""
    rows = []
    for tr in tbl.findall(q("tr")):
        cells = []
        for tc in tr.findall(q("tc")):
            pr = tc.find(q("tcPr"))
            if pr is not None:
                vm = pr.find(q("vMerge"))
                if vm is not None and vm.get(q("val")) in (None, "continue"):
                    i = len(cells)
                    above = rows[-1][i] if rows and i < len(rows[-1]) else ""
                    cells.append(above if REPEAT_VMERGE else "")
                    continue
            cells.append(clean(" ".join(text_of(p, mode) for p in tc.findall(q("p")))))
        if cells:
            rows.append(cells)
    return rows


def rows_to_md(rows):
    if not rows:
        return ""
    n = max(len(r) for r in rows)
    if n == 0:
        return ""
    padded = [r + [""] * (n - len(r)) for r in rows]       # ragged rows -> rectangle
    if n > 1:
        return "\n".join([" | ".join(padded[0]), " | ".join(["---"] * n)]
                         + [" | ".join(r) for r in padded[1:]])
    return "\n".join(" | ".join(r) for r in padded)


def own_cells(tbl):
    """Cells of this table only. Using iter() here would descend into nested
    tables and make them be emitted more than once."""
    for tr in tbl.findall(q("tr")):
        for tc in tr.findall(q("tc")):
            yield tc


def walk(container, blocks, source, counter, in_textbox=False, depth=0, mode="accepted"):
    for el in container:
        name = tag(el)

        if name == "sdt":                                  # content control
            body = el.find(q("sdtContent"))
            if body is not None:
                walk(body, blocks, source, counter, in_textbox, depth, mode)

        elif name == "tbl":
            counter["t"] += 1
            rows = table_rows(el, mode)
            block = {"id": f"t{counter['t']:04d}", "type": "table",
                     "source": source, "in_textbox": in_textbox,
                     "rows": rows, "text": rows_to_md(rows)}
            if depth:
                block["nested"] = True
                block["depth"] = depth
            blocks.append(block)

            for tc in own_cells(el):                       # direct children only
                for child in tc:
                    if tag(child) == "tbl":
                        walk([child], blocks, source, counter, in_textbox, depth + 1, mode)
                    elif tag(child) == "p":
                        for tx in child.iter(q("txbxContent")):
                            walk(tx, blocks, source, counter, True, depth, mode)

        elif name == "p":
            txt = clean(text_of(el, mode))
            if txt:
                counter["p"] += 1
                kind = ("heading" if is_heading(el, txt)
                        else "list" if is_list(el) else "paragraph")
                blocks.append({"id": f"p{counter['p']:04d}", "type": kind,
                               "source": source, "in_textbox": in_textbox,
                               "text": txt})
            for tx in el.iter(q("txbxContent")):           # text boxes
                walk(tx, blocks, source, counter, True, depth, mode)


def notes(z, part, source, blocks, counter, mode="accepted"):
    if part not in z.namelist():
        return
    for note in etree.fromstring(z.read(part)):
        if note.get(q("type")) in ("separator", "continuationSeparator"):
            continue
        txt = clean(" ".join(text_of(p, mode) for p in note.iter(q("p"))))
        if txt:
            counter["n"] += 1
            blocks.append({"id": f"n{counter['n']:04d}", "type": "note",
                           "source": source, "in_textbox": False,
                           "note_id": note.get(q("id")), "text": txt})


def comments(z):
    if "word/comments.xml" not in z.namelist():
        return []
    out = []
    for c in etree.fromstring(z.read("word/comments.xml")):
        txt = clean(" ".join(text_of(p) for p in c.iter(q("p"))))
        if txt:
            out.append({"id": c.get(q("id")), "author": c.get(q("author")) or "",
                        "date": c.get(q("date")) or "", "text": txt})
    return out


def to_markdown(blocks, include_header_footer=True):
    out = []
    if include_header_footer:
        hd = [b["text"] for b in blocks if b["source"] == "header"]
        if hd:
            out.append("<!-- header: " + " | ".join(hd) + " -->")
    for b in blocks:
        if b["source"] in ("header", "footer"):
            continue
        suffix = "  <!-- textbox -->" if b["in_textbox"] else ""
        if b["type"] == "heading":
            out.append(f"## {b['text']}")
        elif b["type"] == "list":
            out.append(f"- {b['text']}{suffix}")
        elif b["type"] == "table":
            out.append(b["text"] + (f"  <!-- nested table, depth {b['depth']} -->"
                                    if b.get("nested") else suffix))
        elif b["type"] == "note":
            out.append(f"> {b['text']}")
        else:
            out.append(b["text"] + suffix)
    if include_header_footer:
        ft = [b["text"] for b in blocks if b["source"] == "footer"]
        if ft:
            out.append("<!-- footer: " + " | ".join(ft) + " -->")
    return "\n\n".join(out)


def extract(path, tracked_changes: str = "accepted"):
    path = Path(path)
    mode = tracked_changes if tracked_changes in VALID_TRACKED_CHANGES else "accepted"
    blocks, counter = [], {"p": 0, "t": 0, "n": 0}

    with zipfile.ZipFile(path) as z:
        names = z.namelist()

        for part in sorted(n for n in names if re.match(r"word/header\d*\.xml$", n)):
            walk(etree.fromstring(z.read(part)), blocks, "header", counter, mode=mode)

        root = etree.fromstring(z.read("word/document.xml"))
        walk(root.find(q("body")), blocks, "body", counter, mode=mode)

        notes(z, "word/footnotes.xml", "footnote", blocks, counter, mode)
        notes(z, "word/endnotes.xml", "endnote", blocks, counter, mode)

        for part in sorted(n for n in names if re.match(r"word/footer\d*\.xml$", n)):
            walk(etree.fromstring(z.read(part)), blocks, "footer", counter, mode=mode)

        cmts = comments(z)

    warnings = []
    if any(b["in_textbox"] for b in blocks):
        warnings.append("İçerik bir metin kutusundan okundu; okuma sırası basılı "
                        "belgeden farklı olabilir.")
    if cmts:
        warnings.append(f"{len(cmts)} adet Word yorumu var.")
    if mode != "accepted":
        warnings.append(f"tracked_changes={mode}: bu, banka dokümanının resmi "
                        "yayınlanmış hâli olmayabilir.")

    return {
        "file": path.name,
        "warnings": warnings,
        "headers":   [b["text"] for b in blocks if b["source"] == "header"],
        "footers":   [b["text"] for b in blocks if b["source"] == "footer"],
        "headings":  [b["text"] for b in blocks if b["type"] == "heading"],
        "tables":    [b["rows"] for b in blocks if b["type"] == "table"],
        "footnotes": [b["text"] for b in blocks if b["source"] in ("footnote", "endnote")],
        "comments":  cmts,
        "blocks":    blocks,
        "markdown":  to_markdown(blocks, include_header_footer=False),
        "stats": {
            "paragraphs": sum(1 for b in blocks if b["type"] == "paragraph"),
            "headings":   sum(1 for b in blocks if b["type"] == "heading"),
            "lists":      sum(1 for b in blocks if b["type"] == "list"),
            "tables":     sum(1 for b in blocks if b["type"] == "table"),
            "notes":      sum(1 for b in blocks if b["type"] == "note"),
            "comments":   len(cmts),
        },
    }


if __name__ == "__main__":
    out_dir = Path("output")
    out_dir.mkdir(exist_ok=True)
    for arg in sys.argv[1:]:
        p = Path(arg)
        data = extract(p)
        (out_dir / f"{p.stem}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        (out_dir / f"{p.stem}.md").write_text(data["markdown"], encoding="utf-8")
        print(f"{p.name}  ->  output/{p.stem}.json  {data['stats']}")
