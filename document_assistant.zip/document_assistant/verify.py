# -*- coding: utf-8 -*-
"""Citation verification.

One rule cuts most hallucination out of this pipeline: a quote the model
attributes to a block must appear in that block, verbatim. Normalisation folds
away formatting noise (curly quotes, dashes, non-breaking spaces, markdown
escapes) but never wording — a paraphrase must fail.

Three distinct failures are reported separately, because they mean different
things to a reviewer:
  * quote absent from the document      -> fabricated
  * quote present but in another block  -> real text, wrong anchor
  * block id unknown                    -> fabricated anchor
"""
from __future__ import annotations
import re
import unicodedata

_FOLD = {
    "‘": "'", "’": "'", "“": '"', "”": '"',
    "ʼ": "'", "´": "'",
    "‐": "-", "‑": "-", "‒": "-", "–": "-",
    "—": "-", "−": "-",
    " ": " ", "​": "", "﻿": "",
}


def tr_lower(text: str) -> str:
    """`str.lower()` turns "İ" into "i" + U+0307 (combining dot), so
    "YÖNETİM KURULU".lower() == "yöneti̇m kurulu" and no plain-ASCII-`i`
    pattern matches it. Folding "İ" to "i" first fixes that. "I" is left to
    the default ("i"), not Turkish "ı": the patterns here accept both
    ([ıi]) and English words ("IF NEEDED") must keep matching."""
    return (text or "").replace("İ", "i").lower()


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text or "")
    for a, b in _FOLD.items():
        text = text.replace(a, b)
    text = re.sub(r"\\([\\`*_{}\[\]()#+\-.!|~<>])", r"\1", text)   # markdown escapes
    text = text.replace("**", "").replace("__", "").replace("`", "")
    return re.sub(r"\s+", " ", text).strip()


def _body(blocks):
    """Üst/alt bilgi blokları (sayfa başlığı, imza/onay tablosu, sayfa no) hiçbir
    zaman kanıt olarak kabul edilmez: model onlardan alıntı yapsa bile sonuç
    sayfasına taşınmaz."""
    return [b for b in blocks if b.get("source") not in ("header", "footer")]


def verify_quote(blocks, block_id: str, quote: str) -> tuple[bool, str]:
    blocks = _body(blocks)
    needle = normalize(quote)
    if not needle:
        return False, "boş alıntı"

    block = next((b for b in blocks if b["id"] == block_id), None)
    if block is None:
        return False, f"bilinmeyen blok id: {block_id}"

    if needle in normalize(block["text"]):
        return True, "birebir doğrulandı"

    whole = normalize(" ".join(b["text"] for b in blocks))
    if needle in whole:
        owner = next((b["id"] for b in blocks if needle in normalize(b["text"])), "?")
        return False, f"alıntı {owner} bloğuna ait, {block_id}'e değil"

    return False, "alıntı belgede bulunamadı"


def find_quote(blocks, quote: str) -> tuple[bool, str]:
    """`verify_quote` gibi ama hangi bloğa ait olduğu İDDİA EDİLMEDEN — belgenin
    TAMAMINDA arar. Ters kontrol (belge → BSEB) için: model hangi blok id'sinden
    alıntı yaptığını söylemez, sadece bir cümle söyler; o cümle gerçekten
    belgede var mı, varsa hangi blokta, onu buluruz."""
    needle = normalize(quote)
    if not needle:
        return False, ""
    for b in _body(blocks):
        if needle in normalize(b["text"]):
            return True, b["id"]
    return False, ""
