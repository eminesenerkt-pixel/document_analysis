# BSEB Uygunluk Taraması — Projenin Mantığı (Baştan Sona)

Bu belge, projeyi hiç tanımayan birinin okuyup "neden böyle tasarlanmış,
nasıl çalışıyor" sorularının ikisine de cevap bulabilmesi için yazıldı.
Kod referansı için [`KOD_REHBERI.md`](../KOD_REHBERI.md)'ye, görsel akış
için [`workflow_graph.svg`](workflow_graph.svg) ve
[`proje_mimarisi.svg`](proje_mimarisi.svg)'ye bakabilirsin — burada
**neden** sorusuna odaklanıyoruz, **nasıl**'ın ayrıntısı oralarda.

---

## 1. Problem: Bu proje neden var?

Bir katılım bankası, BSEB — *Bankaların Bilgi Sistemleri ve Elektronik
Bankacılık Hizmetleri Hakkında Yönetmelik* — adlı bir düzenlemeye uymak
zorunda. Bu düzenleme onlarca madde, yüzlerce alt-gereksinim içeriyor:
"BS Strateji Komitesi kurulmalı", "uzaktan erişim çok faktörlü kimlik
doğrulama gerektirir", "iz kayıtları en az şu kadar süre saklanır" gibi.

Bankanın da onlarca **iç doküman**ı var: güvenlik politikaları, erişim
prosedürleri, yedekleme talimatları, vs. Her yıl (ya da her doküman
güncellendiğinde) birinin oturup şunu sorması gerekiyor: **bu doküman,
düzenlemenin ona uygulanan her maddesini gerçekten karşılıyor mu?**

Bunu elle yapmak — 8-10 dokümanı, 255 maddeye karşı, madde madde okumak —
haftalar sürer ve insan gözünden kaçan boşluklar bırakır. Bu proje bu işi
otomatikleştiriyor: bir LLM'e (yapay zeka modeline) dokümanları okutup her
maddeye karşı bir yargı ürettiriyor, ama **kontrolsüz** bir şekilde değil.

### Neden sadece "dokümanı LLM'e ver, uygun mu diye sor" yeterli değil?

İlk akla gelen, saf yaklaşım şu olurdu: dokümanı ve düzenlemeyi birlikte
modele verip "bu uygun mu?" diye sormak. Bunun üç ciddi sorunu var:

1. **Halüsinasyon**: Model "şu satırda böyle yazıyor" derken metni
   uydurabilir. Uydurma bir alıntıya dayanan bir uygunluk raporu, denetim
   açısından işe yaramaz — hatta tehlikelidir.
2. **Tekrarlanamazlık**: Aynı soruyu iki kez sorsan farklı cevap
   alabilirsin. Bir denetim raporunun "neden bu sonuca varıldığı"
   sorusuna hep aynı cevabı verebilmesi gerekir.
3. **"Hangi madde kontrol edildi?" sorusuna cevap yok**: Model dokümanı
   genel olarak değerlendirdiğinde, 255 maddenin hangisinin gerçekten
   sorgulandığını, hangisinin atlandığını kimse bilemez. Bir düzenleyici
   "peki m.29/11'i kontrol ettiniz mi?" diye sorduğunda "sanırım" demek
   yeterli değildir.

Bu üçü, projenin tüm mimarisini şekillendiren tasarım kararlarının
kaynağı. Aşağıdaki her bölüm, aslında bu üç soruna verilen bir cevap.

---

## 2. Temel Fikir: Kurallar Aranmaz, Dayatılır

Yapay zeka projelerinde çok yaygın bir desen **RAG** (Retrieval-Augmented
Generation): bir soru sorulur, ilgili olabilecek metin parçaları
(embedding benzerliğiyle) bulunur, model bunlara bakarak cevap verir.

Bu proje **kasıtlı olarak RAG kullanmıyor** düzenleme tarafında. Sebebi
basit: RAG "*var olanı*" bulmakta iyidir — "bu konuda ne yazıyor?" gibi.
Ama bir uygunluk taraması "*yok olanı*" bulmalı — "bu doküman, madde
29/11'in gerektirdiği şeyi hiç yazmamış" gibi. Bir madde dokümanda hiç
geçmiyorsa, embedding benzerliği ona hiçbir şeyi "benzer" bulamaz — çünkü
benzeyecek bir şey yok. %90 recall'lu bir arama, 25 tane kontrol
edilmemiş madde demektir ve kimse bunların hangileri olduğunu bilmez.

**Çözüm**: Düzenlemenin 255 maddesinin **hepsi**, her doküman için, bir
**kural tablosuyla** (embedding değil, düz mantıksal eşleşme) süzülüp
modele tek tek "bu senin için geçerli mi, geçerliyse karşılanmış mı?"
diye sorulur. Model hiçbir zaman "hangi maddeye bakayım" diye seçim
yapmaz — bu seçim tamamen kod tarafından, kurala göre yapılır. Bu
sayede rapor her zaman şu soruya cevap verebilir: *"255 maddenin
hepsine bakıldı mı?"* — Evet, çünkü hepsi tabloya girdi.

---

## 3. Kuralların Kendisi: Register (`data/bseb_register.xlsx`)

Düzenlemenin PDF'i **çalışma zamanında hiçbir zaman okunmaz/parse
edilmez**. Onun yerine, bir kişi PDF'i **bir kere, elle** 255 satırlık bir
Excel tablosuna dönüştürmüş. Bu dönüşüm — PDF'teki cümlenin atomik,
kontrol edilebilir bir kurala çevrilmesi — projenin en kıymetli, en çok
emek verilen parçası. Neden Excel? Çünkü:

- **Denetlenebilir**: bir insan açıp okuyabilir, "bu satır doğru mu"
  diye kontrol edebilir.
- **Diff'lenebilir**: düzenleme değiştiğinde, bu tablonun eski/yeni hâli
  karşılaştırılabilir — bir denetim izi bırakır. Kod tarafında hiçbir
  şey değişmez, sadece bu dosya güncellenir.

Register'da üç sayfa var:

| Sayfa | Ne içerir |
|---|---|
| **Register** (255 satır) | Her satır bir atomik kural: id, hangi madde, tam metin, risk seviyesi (Kritik/Yüksek/Orta/Düşük), hangi ana/yan konuya ait, kontrol sorusu, koşullu mu |
| **Konu Sözlüğü** (54 satır) | Kapalı bir konu kataloğu — "uzaktan_erişim", "veri_sınıflandırma" gibi. Modelin bir dokümanı sınıflandırırken seçebileceği TEK kaynak bu liste; model yeni bir konu icat edemez |
| **Koşul Kodları** (15 satır) | "Banka bulut kullanıyor mu?" gibi, bankaya özel gerçeklere bağlı 15 madde. Cevap `data/bank_profile.json`'da |

---

## 4. Bir Belge Nasıl Taranır? (Document Graph)

Bir doküman yüklendiğinde, sırayla şu adımlardan geçer (bkz.
`workflow_graph.svg`, "1 · Belge Grafı" paneli). Her adımı **neden**
var olduğuyla anlatıyoruz, sadece ne yaptığıyla değil.

### 4.1 `ingest` — Word dosyasını parçalara ayırma

Bir `.docx` dosyası aslında bir ZIP arşividir, içinde XML dosyaları
vardır. `ingest`, bu XML'i gezip her paragrafı, tabloyu, dipnotu,
yorumu ayrı bir "blok" olarak çıkarır, her bloğa bir kimlik (`p0001`,
`t0003` gibi) verir. **Bu kimlikler kritiktir** — ilerideki her alıntı
doğrulaması bu bloklara karşı yapılacak.

### 4.2 `profile_document` — Kimlik bilgisi (kod, model yok)

Belgenin başlığı, doküman kodu, sürümü, onaylayan makamı gibi bilgiler
regex ile (metin deseniyle) çıkarılır — model kullanılmaz, çünkü bu
saf biçimsel bir bilgi, yargı gerektirmez.

### 4.3 `select_topics` — Model ilk kez devreye giriyor

Modele belgenin sadece amaç/kapsam bölümü ve başlıkları gösterilir,
54'lük **kapalı** konu kataloğundan, belgenin **kendisinin yönetmeyi
beyan ettiği** konuları seçmesi istenir. "Kapalı liste" önemli: model
"veri_güvenliği_v2" gibi bir konu icat edemez, sadece listedeki 54
koddan seçebilir — böylece ilerideki tablo sorgusu hep tutarlı çalışır.

### 4.4 `recall_guard` — İkinci bir güvenlik ağı

Modeller genelde *az* seçer, fazla değil. `recall_guard`, seçilmeyen
ama kod adı belge metninde geçen "yakın-ıskalanan" konuları bulup
modele ikinci kez "bunlar gerçekten dışarıda mı kaldı?" diye sorar. Ucuz
bir ekstra çağrı, ama bir konu alanının **tamamen sessizce** kaybolmasına
karşı sigorta.

### 4.5 Üç Halka: Hangi Madde Bu Belgeye Sorulur?

Buraya kadar model belgenin **konularını** belirledi (örn.
"uzaktan_erişim", "dokuman_yonetimi"). Şimdi kod devreye girip 255
maddeden hangilerinin bu belgeye sorulacağına karar veriyor —
**tablo sorgusuyla**, model karışmadan:

- **Evrensel halka**: 8 madde (m.5, doküman kontrolü). Her belgeye
  uygulanır, model hiç sorulmaz — çünkü bunlar "doküman kodu var mı,
  onaylayan kim" gibi saf biçimsel sorular, kural motoruyla (`check_
  metadata`) karara bağlanır.
- **Ana konu (core) halkası**: bir maddenin "ana konusu" (`ana_konu`),
  belgenin beyan ettiği konulardan biriyse, bu madde **doğrudan bu
  belgenin sorumluluğu**. Soru: *"bu gereksinim burada karşılanmış mı?"*
  Boşluk = bulgu.
- **Sınır (border) halkası**: bir maddenin "yan konusu" (`yan_konu`)
  belgenin bir konusuna değiyorsa ama ana konusu değilse, bu belge o
  maddeden **doğrudan** sorumlu değil — ama konudan tamamen habersiz
  görünmemeli. Soru değişir: *"bu belge, bu konunun asıl sahibi olan
  başka bir dokümana geçerli bir referans veriyor mu?"*

**Neden bu ayrım önemli?** Uzaktan erişim prosedürü, anahtar yönetiminden
sorumlu değildir (o başka bir dokümanın işi) ama anahtar yönetiminin var
olduğunu bilmezden de gelmemelidir — en azından "bkz. Kriptografik
Kontroller Dokümanı" gibi bir referans vermesi beklenir. Core ve border'ı
birleştirmek her belgeyi değindiği HER konudan sorumlu tutardı (adil
değil); border'ı tamamen atlamak bir bağımlılığın sessizce kaybolmasına
izin verirdi. Ölçüldüğünde: bir Bilgi Güvenliği dokümanına uygulanan
maddelerin **%72'si** düzenlemenin "güvenlik" bölümü dışında yaşıyor —
işte bu yüzden konu haritası (register), düzenlemenin kendi bölüm
yapısından daha güvenilir bir rehber.

### 4.6 Koşullu Maddeler — Banka Gerçekleri

15 madde, "banka bulut kullanıyor mu?" gibi bankaya özel gerçeklere
bağlı. Bu cevaplar `data/bank_profile.json`'da — ayrı bir dosyada,
çünkü bunlar **modelin tahmin edeceği** değil, **birinin imzalayacağı**
gerçekler. Cevaplanmamış bir koşul yok sayılmaz, "bu koşul yanıtsız"
diye uyarıya düşer.

### 4.7 `evaluate_core` / `evaluate_border` — Asıl Yargı

Seçilen her aday madde için **ayrı bir model çağrısı**. Belgenin
tamamı + tek bir madde, modele verilir; model şu şemayla cevap vermek
**zorunda** (serbest metin kabul edilmez):

- **hüküm**: uygun / kısmi / çelişkili / belirtilmemiş / kapsam dışı /
  incelemeye muhtaç
- **kanıt**: hangi bloktan (`p0041` gibi), birebir hangi cümle
- **eksik unsurlar**: madde birden fazla şey istiyorsa, hangileri eksik

**Kritik/Yüksek riskli** maddeler **3 kez** sorulur (farklı örnekleme
ile) ve çoğunluk oyu alınır — anlaşmazlık varsa (2/3 değil 3/3) güven
düşürülür, insan incelemesine gider. Bu, "önemli konularda tek bir
zar atışına güvenme" ilkesi.

### 4.8 `verify_citations` — Kontrolün Kontrolü (kod, model yok)

Bu, **halüsinasyon sorununa** verilen doğrudan cevap. Modelin verdiği
her alıntı, iddia ettiği bloğun gerçek metninde **birebir** (kelime
kelime, biçimlendirme farkları göz ardı edilerek) aranır. Üç farklı
başarısızlık ayrı ayrı ele alınır:

1. Blok kimliği hiç yok → uydurma çapa
2. Alıntı gerçek ama **başka** bir blokta → yanlış yere bağlanmış
3. Alıntı belgenin hiçbir yerinde yok → tamamen uydurma

Doğrulanamayan bir kanıta dayanan olumlu hüküm **silinmez**, "incelemeye
muhtaç"a düşürülür — böylece bir incelemeci "modelin ne iddia ettiğini
ve neden kabul edilmediğini" görebilir.

### 4.9 `challenge` — Model Kendi Kendine İtiraz Ediyor

Sadece **olumsuz** hükümler (belirtilmemiş/çelişkili/kısmi) için: modele
kendi bulgusu gösterilir, "bunu çürütebilir misin?" diye sorulur. Model
belgenin metninden bir karşı-kanıt bulursa, hüküm "incelemeye muhtaç"a
düşer. Bu, tüm sistemdeki **en etkili yanlış-pozitif filtresi**: bir iş
birimine "eksiğiniz var" diye haksız yere gitmek, gerçek bir eksiği
kaçırmaktan (insan incelemesi zaten yakalar) daha pahalıya mal olur.

### 4.10 `route_for_review` — İnsan Ne Zaman Devreye Girer

Hükmü "incelemeye muhtaç" olan ya da güveni eşiğin (varsayılan 0.6)
altında kalan her bulgu ayrı bir listeye (`pending_review`) ayrılır.
Sistem hiçbir zaman "%100 eminim" iddiasında bulunmaz; belirsizliği
gizlemek yerine açıkça işaretler.

---

## 5. Tüm Belgeler Bittikten Sonra: Corpus Graph

Yukarıdaki akış **tek bir belge** içindi. Ama asıl denetim sorusu
başka: *"255 maddenin hepsi, korpustaki HERHANGİ bir belgede karşılanmış
mı?"* Bunu tek bir belgenin akışı yapısal olarak cevaplayamaz — bu yüzden
tüm belgeler bittikten sonra ayrı bir geçiş çalışır:

- **`reverse_scan`** (kod): hangi maddelerin hiçbir belgede olumlu bir
  hükümle karşılanmadığını bulur — bunlara "yetim gereksinim" denir.
- **`evidence_agent`** (**projedeki tek otonom bileşen**): her yetim
  gereksinim için, model bir arama sorgusu üretir → korpusta BM25 (bir
  sözcük-eşleşmeli arama algoritması, embedding değil — çünkü düzenleyici
  Türkçe tam-eşleşme ağırlıklı) ile aranır → sonuç okunur → model "devam
  et" ya da "sonuca vardım" der. En fazla 4 tur. **Neden otonom
  olması güvenli**: çıktısı bir yargı değil, doğrulanabilir bir olgu —
  "X belgesinde bulundu" ya da "arandı, yok". Yargı kısmı (evaluate_core/
  border) hep deterministik kalıyor; otonomluk sadece "bul ya da bulama"
  gibi kontrol edilebilir bir görevde kullanılıyor.
- **`recommend`**: doğrulanmış her olumsuz bulgu için düzeltme metni
  yazdırılır — ama sadece **verilen düzenleme lafzına** dayanarak; model
  dışarıdan bir standart ya da sayısal eşik icat edemez.
- **`render_report`**: hiçbir karar vermeyen, sadece her şeyi
  `output/report/findings_<run_id>.json`'a yazan son adım.

---

## 6. Modelle Nasıl Konuşuyoruz? (`llm.py`)

Sistem, OpenAI'nin `/chat/completions` sözleşmesini konuşan **herhangi
bir** uç noktaya bağlanabilir — kurumun kendi ağ geçidi (APISIX vb.
arkasında Qwen3-235B-A22B), ya da geliştirme sırasında Groq gibi bir
dış servis. Birkaç önemli detay:

- **Sıcaklık 0**: yargı çağrılarında model her zaman en olası cevabı
  verir, rastgelelik yok — aynı girdi hep aynı çıktıyı üretsin diye.
- **Yapılandırılmış çıktı**: model serbest metin değil, şemaya uyan JSON
  döndürmek zorunda; şema uyuşmazsa çağrı başarısız sayılır.
- **Belge her zaman İLK sırada**: aynı belge için ~yüzlerce çağrı
  yapıldığından, belgeyi hep prompt'un başına koymak sunucunun "prefix
  cache" mekanizmasının devreye girmesini sağlar (tekrar eden kısmı
  yeniden işlememek).
- **Düşünme modu kapalı**: Qwen3 varsayılan olarak her cevaptan önce
  uzun bir "düşünme" bloğu üretir — yapılandırılmış, kısa bir yargı için
  gereksiz, hem süreyi hem maliyeti katlar; kapatılır.
- **Kurumsal ağ geçidi ayrıntıları**: header adı/öneki, sertifika,
  ek header'lar — hepsi `.env`'den, koda hiçbir şey hardcode edilmeden.

---

## 7. Kimlik ve Güvenlik — İki Ayrı Kullanım

Projede AD (Active Directory) **iki farklı, kasıtlı olarak birbirinden
bağımsız** yerde kullanılıyor — ikisini karıştırmamak önemli:

| | `directory.py` | `webapp/auth.py` |
|---|---|---|
| **Soru** | Belgedeki "onaylayan" ismi gerçek bir AD hesabına karşılık geliyor mu? | Web arayüzüne giriş yapan kişi gerçekten kim olduğunu iddia ediyor mu? |
| **Parola** | Hiç kullanılmaz — salt okunur arama | Kullanılır — AD'ye karşı tek seferlik doğrulanır, hiç saklanmaz |
| **Ne zaman çalışır** | `check_metadata` sırasında, isteğe bağlı (`LDAP_ENABLED`) | Her web oturumu açılışında (`USE_LDAP_LOGIN`) |
| **Bulunamama ne anlama gelir** | "İnsan kontrol etsin" uyarısı | Giriş reddedilir |

Bir isim AD'de bulunması, o kişinin **o belgeyi gerçekten onayladığı**
anlamına gelmez — sadece o isimde aktif bir hesap olduğu anlamına gelir.
Bu bilinçli bir sınır: sistem asla kanıtlayamayacağı bir şeyi kanıtlanmış
gibi göstermez.

---

## 8. Arayüzler — Aynı Motoru İki Şekilde Çağırmak

- **CLI** (`main.py`): tek operatörlük, otomasyon dostu — `run`,
  `extract`, `check`, `trace`, `graph` komutları. `trace` özellikle
  önemli: bir uç nokta olmadan bile (sahte cevaplarla) tüm akışı, her
  prompt'u, her kararı ekrana basar — kod okumadan sistemin ne yaptığını
  görmenin en hızlı yolu.
- **Web arayüzü** (`webapp/`, Flask): çok kullanıcılı — her kişi kendi
  AD hesabıyla girer, kendi taramalarını görür, başkasının taramasına
  erişemez. Tarama arka planda bir thread'de çalışır, ilerleme
  tarayıcıya **gerçek zamanlı** (Server-Sent Events) akar — Streamlit'in
  yerini aldı çünkü çok-kullanıcılı oturum kavramı Streamlit'e doğal
  olarak sığmıyordu.

İkisi de **aynı** `graph.py`/`nodes/*` fonksiyonlarını çağırır — iş
mantığı hiçbir yerde iki kez yazılmadı.

---

## 9. Hepsi Bir Arada: Uçtan Uca Bir Örnek

Bir kullanıcı, web arayüzünden `DOC-02_Uzaktan_Erisim...docx` yüklüyor:

1. Dosya `webapp/uploads/<kullanıcı>/<run_id>/`'a kaydedilir.
2. `extract.py` dosyayı bloklara ayırır (`ingest` bunu zaten yapacak
   olsa da, arama indeksi için ayrıca `output/.../extract/`'e de yazılır).
3. `select_topics` modele belgenin amacını okutur: "uzaktan_erisim",
   "dokuman_yonetimi" konularını seçer.
4. `recall_guard` bunları teyit eder, ek bir konu bulmaz.
5. `check_metadata` (kod) 8 evrensel maddeyi kural ile karara bağlar —
   örneğin "doküman kodu var, gizlilik derecesi eksik" → kısmi.
6. `expand_requirements` 255 maddeden ~20 tanesini aday olarak seçer
   (1 ana konu, 11 sınır, 8 evrensel).
7. Bu 20 madde **paralel** olarak `evaluate_core`/`evaluate_border`'a
   dağıtılır; Yüksek riskli olanlar 3'er kez sorulur.
8. Her sonucun alıntısı `verify_citations` ile doğrulanır — birebir
   eşleşmeyen bir alıntı "incelemeye muhtaç"a düşürülür.
9. Olumsuz hükümler `challenge`'dan geçer — biri çürütülür, diğerleri
   sağlam kalır.
10. Tüm belgeler bitince (bu örnekte tek belge) `reverse_scan` hiçbir
    belgede karşılanmayan maddeleri bulur, `evidence_agent` korpusta
    arar.
11. `recommend` her olumsuz bulgu için düzeltme metni yazar.
12. Kullanıcı, web arayüzünde her bulguyu renkli bir kart olarak görür;
    "Detayı göster"e tıklayınca gerekçe ve tavsiye akarak görüntülenir.
13. `output/report/findings_<run_id>.json` indirilebilir hâlde durur.

---

## 10. Nereye Bakmalı? (Hızlı Referans)

| Sorun | Bak |
|---|---|
| "Bu fonksiyon ne yapıyor?" | [`KOD_REHBERI.md`](../KOD_REHBERI.md) |
| "Akış görsel olarak nasıl?" | [`workflow_graph.svg`](workflow_graph.svg) |
| "Tüm proje bileşenleri nasıl bağlanıyor?" | [`proje_mimarisi.svg`](proje_mimarisi.svg) |
| "Gerçek bir belgede tek bir madde nasıl işleniyor?" | `python -m dokuman_inceleme.main trace --document ... --req REQ-...` |
| "Neden böyle tasarlandı?" (bu belge) | Yukarısı |
