> Bilgi Teknolojileri süreçlerini kurum içi dil modeliyle destekleyen üç asistan projesi.
> Bu sayfa portföyün özetidir; her projenin ayrıntısı, gelişim aşamaları ve diyagramları kendi sayfasındadır.

[[_TOC_]]

---

## Üç proje bir bakışta

| | 🛠️ **Hizmet Masası Asistanı** | 📄 **Dokümantasyon Asistanı** | 🔍 **Denetim Asistanı** |
|---|---|---|---|
| **Amaç** | Hizmet masası uzmanının çözüm üretmesi, olay tespiti ve haftalık analiz | Banka BT dokümanlarının mevzuata uyumu, sahipliği, güncelliği ve tutarlılığı | Denetim bulgularının takibi, kontrol testlerinin otomasyonu ve kanıt yönetimi |
| **Durum** | 🟢 Geliştirme — üç uygulama çalışır durumda | 🟡 **Faz 1 tamamlandı** — mevzuat uyum incelemesi | ⚪ Kapsam taslağı — onay bekliyor |
| **Uygulamalar** | Mercek Asistanı · Mercek Alarm · Mercek Analist | BSEB Uyum İncelemesi (`dokuman_inceleme`) | — |
| **Girdi** | Mercek kayıtları, bilgi tabanı, kurum içi siteler | Word dokümanları, BSEB register'ı, banka profili | Denetim bulguları, kontrol tanımları, kanıtlar |
| **Çıktı** | Kaynaklı çözüm, alarm e-postası, haftalık olay raporu | Değişiklik talepleri, üç seviyeli rapor | *(taslak)* Bulgu takip panosu, kontrol test raporları |
| **Sayfa** | [Hizmet Masası Asistanı](/Hizmet-Masası-Asistanı) | [Dokümantasyon Asistanı](/Dokümantasyon-Asistanı) | [Denetim Asistanı](/Denetim-Asistanı) |

---

## Portföy haritası

::: mermaid
graph LR
    subgraph HM["Hizmet Masası Asistanı"]
        HM1["Mercek Asistanı<br/>agentic çözüm sohbeti"]
        HM2["Mercek Alarm<br/>anlık olay uyarısı · BSEB 23.1"]
        HM3["Mercek Analist<br/>haftalık olay analizi"]
    end

    subgraph DA["Dokümantasyon Asistanı"]
        DA1["Faz 1 · BSEB Uyum İncelemesi<br/>TAMAMLANDI"]
        DA2["Faz 2 · Envanter, sahiplik, güncellik"]
        DA3["Faz 3 · Tutarlılık ve terim farkları"]
        DA4["Faz 4 · Nasıl yapılır? soru-cevap"]
        DA5["Faz 5 · Çoklu mevzuat ve çerçeveler"]
        DA1 --> DA2 --> DA3 --> DA4 --> DA5
    end

    subgraph DN["Denetim Asistanı"]
        DN1["Bulgu takibi"]
        DN2["Kontrol testi otomasyonu"]
        DN3["Kanıt arşivi"]
    end

    subgraph ORTAK["Ortak altyapı"]
        LLM[("Dil modeli · Qwen3<br/>kurum içi ağ geçidi")]
        EMB[("BGE-M3<br/>gömme modeli")]
        MIL[("Milvus<br/>vektör deposu")]
        AD[("Kurumsal dizin<br/>AD / LDAP")]
    end

    HM1 --- LLM
    HM1 --- MIL
    HM2 --- EMB
    HM3 --- MIL
    DA1 --- LLM
    DA1 --- AD
    HM1 --- AD

    HM2 -. "kontrol testi deseni" .-> DN2
    DA1 -. "uyum bulguları" .-> DN1

    classDef done fill:#e8f5e9,stroke:#2e7d32,color:#1b1b1b
    classDef plan fill:#f5f5f5,stroke:#9e9e9e,color:#555555,stroke-dasharray:4 3
    classDef live fill:#e3f2fd,stroke:#1565c0,color:#1b1b1b
    classDef infra fill:#fff8e1,stroke:#f9a825,color:#1b1b1b
    class DA1 done
    class DA2,DA3,DA4,DA5,DN1,DN2,DN3 plan
    class HM1,HM2,HM3 live
    class LLM,EMB,MIL,AD infra
:::

> Yeşil: tamamlanan faz · Mavi: çalışan uygulama · Gri kesikli: planlanan · Sarı: ortak altyapı

---

## Zaman çizelgesi

::: mermaid
gantt
    title Gerçekleşen çalışmalar (2026)
    dateFormat YYYY-MM-DD
    axisFormat %d %b

    section Hizmet Masası
    Keşif, veri analizi, ilk prototipler      :done, hm1, 2026-07-02, 2026-07-28
    Modüler yeniden yazım                     :done, hm2, 2026-07-28, 2026-08-12
    BT Mercek AI v5 (çok ajanlı platform)     :done, hm3, 2026-08-12, 2026-08-17
    Mercek Asistanı (agentic, Milvus)         :active, hm4, 2026-08-17, 2026-10-08
    Mercek Alarm ve Analist ayrıştı           :milestone, hm5, 2026-09-27, 0d

    section Dokümantasyon
    Faz 1 · BSEB Uyum İncelemesi              :done, da1, 2026-09-14, 2026-10-08
    Sağlamlaştırma ve üç seviyeli rapor       :milestone, da2, 2026-10-08, 0d

    section Denetim
    Kapsam taslağı                            :active, dn1, 2026-10-08, 7d
:::

> Tarihler proje klasörlerinin oluşturulma ve son değişiklik tarihlerinden alınmıştır; gün düzeyinde yaklaşıktır.

---

## Ortak tasarım ilkeleri

Üç proje de aynı ilkelerle geliştiriliyor. Bunlar yeni bir proje başlarken de geçerli:

| İlke | Ne demek | Nerede görülür |
|---|---|---|
| **Sayıyı kod üretir, model yorumlar** | Metrik, eşik, sayım, öncelik kural katmanında hesaplanır; dil modeli yalnızca yorum ve metin yazar | Mercek Asistanı, Mercek Analist, uyum incelemesinde öncelik |
| **Kanıtsız iddia yok** | Modelin dayandığı her alıntı kaynak metinde aranır; bulunamazsa sonuç insan incelemesine düşer | Uyum incelemesi (alıntı doğrulama), kurum bilgisi ajanı (%82 benzerlik eşiği) |
| **Dürüst bozulma** | Bir bileşen yoksa uygulama yine açılır ama bunu **gizlemez** — "DEMO", "atlandı" ya da "ölçüt kapalı" diye yazar | Mercek Asistanı yedek mod, Mercek Alarm metin ölçütü |
| **Model hangi kuralı kontrol edeceğini seçmez** | Hangi gereksinimin ya da kontrolün çalışacağına tablo ve kod karar verir | BSEB register'ı (255 gereksinim), alarm kuralı |
| **Kurum içinde kalır** | Dil modeli kurum içi ağ geçidinde, gömme modeli diskte; dışarıya veri gitmez | Tüm projeler |
| **Kurumsal kimlik** | Giriş AD hesabıyla; roller ve yetkiler sunucuda denetlenir | Tüm web uygulamaları |

---

## Sayfalar

[[_TOSP_]]

| Sayfa | İçerik |
|---|---|
| [Hizmet Masası Asistanı](/Hizmet-Masası-Asistanı) | Üç uygulama, gelişim aşamaları, ajan akışı |
| [Dokümantasyon Asistanı](/Dokümantasyon-Asistanı) | Beş beklenti, faz planı, Faz 1'in ayrıntısı ve gelişim günlüğü |
| [Denetim Asistanı](/Denetim-Asistanı) | Önerilen kapsam ve karar bekleyen konular |
| [Kullanılan Komponentler](/Kullanılan-Komponentler) | Teknoloji yığını, dış sistemler, proje × bileşen matrisi |
