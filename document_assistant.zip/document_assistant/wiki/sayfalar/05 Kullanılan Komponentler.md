> Üç projenin teknoloji yığını, bağlandığı kurum sistemleri ve hangi bileşenin hangi projede kullanıldığı.

[[_TOC_]]

---

## Katmanlı görünüm

::: mermaid
graph TB
    subgraph UI["Sunum"]
        U1["Flask web arayüzü<br/>Waitress (üretim sunucusu)"]
        U2["Canlı ilerleme<br/>SSE · yoklama"]
        U3["Raporlar<br/>ReportLab PDF · HTML · JSON · .eml"]
    end
    subgraph ORK["Orkestrasyon"]
        O1["LangGraph<br/>ajan ve iş akışı grafları"]
        O2["Kural katmanı<br/>pandas · NumPy · SciPy · scikit-learn"]
    end
    subgraph AI["Yapay zekâ"]
        A1["Qwen3-32B<br/>Mercek Asistanı · Alarm · Analist"]
        A2["Qwen3-235B-A22B<br/>uyum incelemesi"]
        A3["BGE-M3<br/>dense + sparse gömme"]
        A4["bge-reranker-v2-m3<br/>yeniden sıralama"]
    end
    subgraph DATA["Veri"]
        D1[("Milvus<br/>hibrit arama · RRF")]
        D2[("SQLite<br/>yerel veritabanı · checkpoint")]
        D3[("Excel / JSON<br/>register · profil · kayıtlar")]
        D4[("Word .docx<br/>lxml ile ayrıştırma")]
    end
    subgraph KURUM["Kurum sistemleri"]
        K1["APISIX / vLLM<br/>model ağ geçidi"]
        K2["Active Directory<br/>LDAP"]
        K3["SMTP<br/>e-posta"]
        K4["Bilge · Bilgin<br/>WordPress REST"]
    end
    UI --> ORK --> AI
    ORK --> DATA
    AI --> K1
    UI --> K2
    U3 --> K3
    O1 --> K4
:::

---

## Proje × bileşen matrisi

| Bileşen | Mercek Asistanı | Mercek Alarm | Mercek Analist | Uyum İncelemesi (Faz 1) |
|---|:-:|:-:|:-:|:-:|
| **Python 3** | ✅ | ✅ | ✅ | ✅ |
| **Flask** | ✅ | ✅ | ✅ | ✅ |
| **Waitress** | ✅ | ✅ | ✅ | — |
| **LangGraph** | ✅ | — | — | ✅ |
| **Qwen3 (kurum ağ geçidi)** | ✅ 32B | ✅ 32B · alarm yorumu | ✅ 32B · olay yazımı | ✅ 235B-A22B |
| **BGE-M3** (FlagEmbedding) | ✅ | ✅ metin ölçütü | ✅ | — |
| **bge-reranker-v2-m3** | ✅ | — | — | — |
| **Milvus** (pymilvus) | ✅ okuma + yazma | — | ✅ salt okunur | — |
| **SQLite** | — | ✅ | ✅ | ✅ checkpoint |
| **pandas / NumPy / SciPy** | ✅ | ✅ | ✅ | — |
| **scikit-learn** | — | ✅ | ✅ | — |
| **PyTorch** | ✅ | ✅ | ✅ | — |
| **openpyxl** | ✅ | ✅ | ✅ | ✅ register |
| **lxml** (Word XML) | — | — | — | ✅ |
| **httpx / requests** | ✅ requests | ✅ requests | ✅ requests | ✅ httpx |
| **ldap3** (AD girişi) | ✅ | ✅ | ✅ | ✅ |
| **ReportLab** (PDF) | — | — | — | ✅ |
| **SMTP / .eml** | — | ✅ | — | — |

---

## Bileşenler ve görevleri

### Yapay zekâ

| Bileşen | Görev | Not |
|---|---|---|
| **Qwen3-32B** | Mercek Asistanı'nda niyet, netleştirme, çözüm, kalite kapısı, gerekçe; Alarm'da e-posta yorumu; Analist'te olay yazımı | Kurum içi APISIX ağ geçidi, OpenAI uyumlu uç. Model bağlı değilse Alarm bildirimi yorumsuz gönderir |
| **Qwen3-235B-A22B** | Uyum incelemesinde konu seçimi, gereksinim değerlendirmesi, itiraz, ikinci kontrol, birleştirme | vLLM, 16K bağlam. Karar çağrılarında sıcaklık 0 ve düşünme kapalı; ikinci kontrolde düşünme açık |
| **BGE-M3** | Metni vektöre çevirir: dense (anlam) + sparse (kayıt no, kısaltma gibi sözcük eşleşmesi) | Diskte, çevrimdışı. Yoksa TF-IDF'e düşer ve bunu ekranda söyler |
| **bge-reranker-v2-m3** | Getirilen kaynakları yeniden sıralar | Cross-encoder |

### Orkestrasyon

| Bileşen | Görev |
|---|---|
| **LangGraph** | Mercek Çözüm Ajanı (niyet → kategori → getirme → kurum bilgisi → netleştirme → çözüm → kalite → gerekçe → aksiyon → hazır çözüm). Uyum incelemesinde belge grafı (paralel fan-out, ikinci kontrol, doğrulama, itiraz) ve korpus grafı |
| **Kural katmanı** | Sayılar, eşikler, gruplama, öncelik ve künye kuralları: model yok, her çalıştırmada aynı sonuç |

### Veri

| Bileşen | Görev |
|---|---|
| **Milvus** | `_tickets` (mercekler + künye) ve `_kb` (türetilmiş bilgi tabanı + uzman çözümleri) koleksiyonları. Hibrit arama: dense + sparse, RRF |
| **SQLite** | Mercek Alarm ve Analist'in yerel veritabanı, alarm denetim izi (hash zinciri), uyum incelemesinde LangGraph checkpoint |
| **BSEB register'ı** (Excel) | 255 gereksinim, 54 konu, 15 koşul kodu |
| **Banka profili** (JSON) | Koşullu gereksinimlerin yanıtları |

### Kurum sistemleri

| Sistem | Kim kullanır | Ne için |
|---|---|---|
| **APISIX / vLLM ağ geçidi** | Tüm projeler | Dil modeline erişim. Kurum CA sertifikası ve özel başlık desteği var |
| **Active Directory (LDAP)** | Tüm web uygulamaları | Giriş. Uyum incelemesinde ayrıca onaylayan ve sahibin gerçek, aktif bir hesap olup olmadığının kontrolü |
| **SMTP** | Mercek Alarm | Alarm ve yükseltme e-postaları. Tanımlı değilse `.eml` dosyası olarak yazılır |
| **Bilge · Bilgin** (WordPress REST) | Mercek Asistanı | Kurum içi terim ve çözüm araması, canlı |
| **BOA DYS** | *Dokümantasyon Asistanı Faz 2 (planlı)* | Doküman envanteri ve sürüm bilgisi |

---

## Ortak güvenlik ve işletim özellikleri

| Özellik | Açıklama |
|---|---|
| **Kurum içinde kalır** | Model ve gömme kurum içinde; dışarıya veri gitmez |
| **AD girişi + rol** | Bölüm erişimi ve eylem yetkisi ayrı; sunucu her istekte kendi kontrolünü yapar |
| **Parola saklanmaz** | AD'de yalnızca o an bağlanılarak doğrulanır; demo hesaplar pbkdf2-hmac-sha256 ile |
| **CSRF ve dosya güvenliği** | Uyum incelemesinde form belirteci, güvenli dosya adı, yalnızca `.docx` |
| **Ayarlar tek dosyada** | `.env`; gerçek ortam değişkeni dosyadaki ayarı ezer |
| **Çevrimdışı kurulum** | Paketler ve modeller internetsiz kurulabilir (bkz. `servicedesk_ai/docs/KURULUM.md`) |
