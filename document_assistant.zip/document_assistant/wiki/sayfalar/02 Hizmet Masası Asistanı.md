> Hizmet masası kayıtları (**Mercek**) üzerinde çalışan üç uygulamalı bir aile: uzmana çözüm yazan bir
> asistan, kısa sürede çok sayıda benzer kayıt açıldığında uyaran bir alarm ve haftanın olaylarını
> çıkaran bir analist.

[[_TOC_]]

| | |
|---|---|
| **Durum** | 🟢 Geliştirme — üç uygulama çalışır durumda |
| **Kullanıcılar** | Hizmet Masası uzmanları ve yöneticileri, Kesinti Yönetimi |
| **Veri** | Mercek kayıtları, türetilmiş bilgi tabanı, uzman onaylı çözümler, kurum içi bilgi siteleri (Bilge · Bilgin) |
| **Model** | Qwen3-32B (APISIX ağ geçidi) · BGE-M3 gömme · bge-reranker-v2-m3 |

---

## Üç uygulama

| Uygulama | Ne yapar | Kim kullanır | Ayrıntı |
|---|---|---|---|
| **Mercek Asistanı** (`servicedesk_ai`) | Uzman sorunu yazar; ajan kategoriyi bulur, benzer kayıtları ve bilgi tabanını getirir, gerekirse soru sorar, kaynaklı çözüm yazar, kalite kapısından geçirir | Hizmet Masası uzmanı | [Mercek Asistanı](/Hizmet-Masası-Asistanı/Mercek-Asistanı) |
| **Mercek Alarm** (`mercek_alarm`) | 60 dakikada ≥10 benzer kayıt açılırsa Hizmet Masası ve Kesinti Yönetimi'ni uyarır; 13 senaryolu kontrol testi ve değiştirilemez denetim izi | Uzman, yönetici, Kesinti Yönetimi | [Mercek Alarm](/Hizmet-Masası-Asistanı/Mercek-Alarm) |
| **Mercek Analist** (`mercek_analist`) | Haftanın kayıtlarını anlamsal olarak gruplar, en büyük 5 grubu olay olarak yazdırır: özet, major incident değerlendirmesi, kök neden, öneri | Hizmet Masası yöneticisi | [Mercek Analist](/Hizmet-Masası-Asistanı/Mercek-Analist) |

::: mermaid
graph TB
    MERCEK[("Mercek kayıtları<br/>xlsx / csv")]
    IDX["İndeksleme hattı<br/>BGE-M3 dense + sparse"]
    MIL[("Milvus<br/>_tickets · _kb")]
    SQL[("SQLite<br/>yerel veritabanı")]

    MERCEK --> IDX --> MIL
    MERCEK --> SQL

    subgraph A["Mercek Asistanı"]
        A1["Agentic çözüm sohbeti"]
    end
    subgraph B["Mercek Alarm"]
        B1["20 sn'de bir kural<br/>alan + metin benzerliği"]
    end
    subgraph C["Mercek Analist"]
        C1["Haftalık anlamsal gruplama<br/>+ RAG + olay yazımı"]
    end

    MIL --> A1
    MIL -. "hazır vektörler, salt okunur" .-> C1
    SQL --> B1
    SQL --> C1

    A1 --> O1(["Kaynaklı çözüm<br/>+ aksiyon + hazır betik"])
    B1 --> O2(["Alarm e-postası<br/>yükseltme · denetim izi"])
    C1 --> O3(["Haftalık olay kartları"])

    classDef app fill:#e3f2fd,stroke:#1565c0,color:#1b1b1b
    classDef store fill:#f5f5f5,stroke:#616161,color:#1b1b1b
    classDef out fill:#e8f5e9,stroke:#2e7d32,color:#1b1b1b
    class A1,B1,C1 app
    class MERCEK,MIL,SQL store
    class O1,O2,O3 out
:::

> Alarm ve Analist bilerek ayrı uygulamalar: Alarm yalnızca yerel veritabanıyla çalışır, Milvus'a ya da başka bir sisteme bağlı değildir. Böylece uyarı mekanizması diğer bileşenlerin kesintisinden etkilenmez.

---

## Öne çıkanlar

- **Agentic ama denetlenebilir:** her mesaj aynı LangGraph zincirinden geçer (niyet kapısı → kategori → getirme → kurum bilgisi → netleştirme → çözüm → kalite kapısı → gerekçe → aksiyon → hazır çözüm). Geliştirici modunda her adım, süresi ve modele giden tam istem ekranda görünür.
- **Netleştirme döngüsünün sınırı yok, kalite döngüsünün var:** bilgi yetersizse asistan uzman yeterli bilgi verene kadar soru sorar. Kalite kapısı çözümü reddederse çözüm yalnızca bir kez daha yazılır.
- **Kurum bilgisi ajanı (Bilge · Bilgin):** model kurum içi terimleri (BOA, fon kredi…) bilmez. Ajan bu terimleri kurum sitelerinde canlı arar ve yalnızca alıntıyla doğrulanan tanımları kullanır.
- **Hazır çözüm ajanı:** ekibin `.bat` betik ve SQL sorgu kütüphanesinden uygun olanı **seçer**, kendisi yazmaz ve hiçbir şey çalıştırmaz. Sorgu önerisi yalnızca banka müşterisi vakalarında yapılır.
- **Ekip konuştukça öğrenir:** uzman çözümü düzenleyip bilgi tabanına gönderir. Biçim, kopya ve model rubriğinden oluşan üç kapıyı geçen çözüm doğrudan Milvus'a yazılır.
- **BSEB 23.1 denetim bulgusu kapatıldı:** Mercek Alarm, bulgunun istediği alarmı ve kurulum öncesi kontrol testlerini kayıt altına alıyor.

---

## Alt sayfalar

[[_TOSP_]]

| Sayfa | İçerik |
|---|---|
| [Gelişim Aşamaları](/Hizmet-Masası-Asistanı/Gelişim-Aşamaları) | İlk prototipten üç uygulamaya: ne yapıldı, ne eklendi, ne kaldırıldı |
| [Mercek Asistanı](/Hizmet-Masası-Asistanı/Mercek-Asistanı) | Ajan akışı adım adım, sequence diyagramı, 11 aşama görseli |
| [Mercek Alarm](/Hizmet-Masası-Asistanı/Mercek-Alarm) | Kural, alarm yaşam döngüsü, kontrol testleri |
| [Mercek Analist](/Hizmet-Masası-Asistanı/Mercek-Analist) | Haftalık analiz hattı |
