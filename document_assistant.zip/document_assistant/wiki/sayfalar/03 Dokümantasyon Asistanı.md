> Bankanın BT politika ve dokümanlarını mevzuata, uluslararası çerçevelere, organizasyon şemasına ve birbirlerine
> karşı okuyan; "nasıl yapılır, nerede yazıyor, kimin, güncel mi, uyumlu mu?" sorularına kanıtlı cevap veren asistan.

[[_TOC_]]

| | |
|---|---|
| **Durum** | 🟡 **Faz 1 tamamlandı**: BSEB Uyum İncelemesi (`dokuman_inceleme`) |
| **Sıradaki** | Faz 2: Doküman envanteri, sahiplik ve güncellik |
| **Kullanıcılar** | BT Uyum, BT Yönetişim, doküman sahibi birimler |

---

## Temel girdiler

| Girdi | Kapsam | Öncelik |
|---|---|---|
| **Bankacılık mevzuatı** | BSEB, CBDDO, Elektronik Bankacılık Yönetmeliği | 🔴 Öncelikli |
| **Uluslararası çerçeveler** | COBIT, ITIL, PCI-DSS, ISO 27001/27002, TSE 50600-3 | 🟠 |
| **Banka BT politika ve dokümanları** | BOA DYS, Word, PDF, JPEG vb. | 🔴 Öncelikli |
| **Banka süreçleri** | BOA IT ekranları, süreç listeleme ekranı vb. | 🟡 |
| **BT organizasyon şeması** | Müdürlük ve servis adları, sorumlular | 🟡 |

## Temel beklentiler

| # | Beklenti | Örnek soru | Faz |
|---|---|---|---|
| 1 | **Nasıl yapılır?** | "Log yönetimi süreci BSEB'e göre nasıl olmalı?" | Faz 4 |
| 2 | **Nerede, kimin?** | "Log yönetimi bankada hangi dokümanlarda geçiyor, sahibi kim?" | Faz 2 |
| 3 | **Mevzuat uyumluluğu** | "Bu doküman grubu mevzuata uyumlu mu, nerede olgunlaştırılmalı?" | ✅ **Faz 1** |
| 4 | **Farklılıklar** | "Dokümanlardaki müdürlük ve servis adları org. şemasıyla uyuşuyor mu? Terim ve imla hataları?" | Faz 3 |
| 5 | **Güncellik** | "Hangi dokümanlar güncellenmemiş? En son kim, ne zaman güncelledi?" | Faz 2 |

---

## Faz planı

::: mermaid
graph TB
    subgraph F1["FAZ 1 · TAMAMLANDI · BSEB Uyum İncelemesi"]
        F1a["Word → bloklar<br/>künye çıkarımı"]
        F1b["255 gereksinimlik register<br/>üç halka"]
        F1c["Madde madde değerlendirme<br/>alıntı doğrulama · itiraz"]
        F1d["Bölüm bazlı birleştirme<br/>üç seviyeli rapor"]
    end
    subgraph F2["FAZ 2 · Envanter, sahiplik, güncellik"]
        F2a["BOA DYS bağlantısı"]
        F2b["Doküman envanteri<br/>kod · sahip · onaylayan · revizyon"]
        F2c["Konu → doküman araması<br/>'log yönetimi nerede geçiyor?'"]
        F2d["Güncel olmayanlar raporu"]
    end
    subgraph F3["FAZ 3 · Tutarlılık"]
        F3a["Org. şeması ile isim karşılaştırma"]
        F3b["Terim sözlüğü ve farkları"]
        F3c["İmla denetimi"]
    end
    subgraph F4["FAZ 4 · Nasıl yapılır?"]
        F4a["Mevzuat + banka dokümanı üzerinden<br/>kaynaklı soru-cevap"]
    end
    subgraph F5["FAZ 5 · Çoklu mevzuat ve çerçeveler"]
        F5a["CBDDO · E-Bankacılık Yön."]
        F5b["COBIT · ITIL · PCI-DSS<br/>ISO 27001/27002 · TSE 50600-3"]
        F5c["PDF · JPEG (OCR) · BOA ekranları"]
    end
    F1 ==> F2 ==> F3 ==> F4 ==> F5

    classDef done fill:#e8f5e9,stroke:#2e7d32,color:#1b1b1b
    classDef next fill:#e3f2fd,stroke:#1565c0,color:#1b1b1b
    classDef plan fill:#f5f5f5,stroke:#9e9e9e,color:#555555
    class F1a,F1b,F1c,F1d done
    class F2a,F2b,F2c,F2d next
    class F3a,F3b,F3c,F4a,F5a,F5b,F5c plan
:::

> Faz sırası **önerilir**: her faz bir öncekinin ürettiği yapı taşını kullanacak şekilde dizildi. Sıra ve kapsam, iş birimiyle birlikte netleştirilecek.

### Faz 1'den sonraki fazlara ne taşınıyor?

| Faz 1'de hazır olan | Kullanılacağı faz |
|---|---|
| Word ayrıştırıcı: paragraf, tablo, dipnot, metin kutusu, izlenen değişiklikler | Tüm fazlar |
| Künye çıkarımı: doküman kodu, sürüm, revizyon tarihi, sahip, onaylayan, yürürlük onayı | **Faz 2**: envanter ve güncellik |
| AD/LDAP kişi sorgusu: onaylayan/sahip gerçek ve aktif bir hesap mı? | **Faz 2** sahiplik, **Faz 3** org. şeması |
| Doküman bölümleme (başlıklara göre) | **Faz 2** arama, **Faz 4** soru-cevap |
| BM25 korpus araması ve kanıt ajanı | **Faz 2** "nerede geçiyor?", **Faz 4** |
| Register yaklaşımı: mevzuat bir kez, elle, atomik gereksinim tablosuna çevrilir | **Faz 5**: her yeni mevzuat ya da çerçeve aynı şablonla eklenir |
| Alıntı doğrulama ve itiraz turu | Tüm fazlar: kanıtsız iddia yok |
| Üç seviyeli rapor: ekip / iç / ayrıntılı | Tüm fazlar |

---

## Alt sayfalar

[[_TOSP_]]

| Sayfa | İçerik |
|---|---|
| [Faz 1 BSEB Uyum İncelemesi](/Dokümantasyon-Asistanı/Faz-1-BSEB-Uyum-İncelemesi) | Mimari, kullanıcı akışı (sequence), üç halka, kontroller, çıktılar |
| [Faz 1 Gelişim Günlüğü](/Dokümantasyon-Asistanı/Faz-1-Gelişim-Günlüğü) | Aşama aşama ne yapıldı, ne eklendi, hangi hatalar düzeltildi |
