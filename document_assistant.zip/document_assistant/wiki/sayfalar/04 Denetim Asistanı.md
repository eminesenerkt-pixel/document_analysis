> ⚠️ **Taslak — kapsam onay bekliyor.** Bu sayfadaki kapsam, diğer iki projede hazır olan yapı taşlarından türetilmiş bir **öneridir**.
> Kesinleşen kararlar işlendikçe güncellenecek.

[[_TOC_]]

| | |
|---|---|
| **Durum** | ⚪ Kapsam taslağı |
| **Amaç (öneri)** | İç ve dış denetim bulgularını kayıttan kapanışa kadar izlemek; kapanış için gereken kontrol testlerini ve kanıtları otomatik, değiştirilemez biçimde üretmek |
| **Kullanıcılar (öneri)** | BT Uyum, BT Risk, bulgu sahibi birimler, İç Denetim |

---

## Neden?

Diğer iki projede denetimle ilgili iki parça zaten ortaya çıktı:

1. **Mercek Alarm** bir denetim bulgusunu (**BSEB 23.1**) kapatmak için yazıldı. Bulgunun istediği kontrolü kurdu ve bu kontrolün **kurulumdan önce test edildiğini** kanıtlayan bir yapı getirdi: 13 senaryo, üretim koduyla test, imzalanabilir rapor, hash zincirli denetim izi.
2. **Dokümantasyon Asistanı** dokümanlardaki mevzuat boşluklarını madde madde ve alıntıyla buluyor. Bunlar denetimde sorulacak soruların ta kendisi.

Denetim Asistanı bu iki deseni tek bir yerde topluyor: **bulgu → aksiyon → kontrol testi → kanıt → kapanış.**

---

## Önerilen akış

::: mermaid
graph LR
    S1[("Denetim bulgusu<br/>İç Denetim · BDDK · bağımsız denetim")] --> A["Bulgu kaydı<br/>mevzuat maddesine bağlanır"]
    DOC[("Dokümantasyon Asistanı<br/>uyum bulguları")] -.-> A
    A --> B["Aksiyon planı<br/>sahip · termin"]
    B --> C["Kontrol tanımı<br/>ne test edilecek?"]
    C --> D["Kontrol testi<br/>üretim koduyla, geçici ortamda"]
    D --> E["Kanıt paketi<br/>rapor + SHA-256 + denetim izi"]
    E --> F{"Kapanış onayı"}
    F -- "eksik" --> B
    F -- "tamam" --> G(["Kapalı bulgu<br/>kanıtıyla arşivde"])
    classDef plan fill:#f5f5f5,stroke:#9e9e9e,color:#1b1b1b,stroke-dasharray:4 3
    classDef out fill:#e8f5e9,stroke:#2e7d32,color:#1b1b1b
    class A,B,C,D,E plan
    class G out
:::

---

## Önerilen yetenekler

| # | Yetenek | Hazır yapı taşı | Kaynak proje |
|---|---|---|---|
| 1 | **Bulgu kaydı ve takibi**: sahip, termin, durum, yükseltme | Alarm yaşam döngüsü (üstlenme, yükseltme, kapatma notu zorunlu) | Mercek Alarm |
| 2 | **Bulguyu mevzuat maddesine bağlama** | 255 gereksinimlik BSEB register'ı, madde → gereksinim eşlemesi | Dokümantasyon Asistanı |
| 3 | **Kontrol testi çerçevesi**: her kontrol için senaryolar, üretim koduyla ve gerçek ayarlarla | K01–K13 senaryo yapısı, geçici veritabanı, sabitlenmiş zaman | Mercek Alarm |
| 4 | **Değiştirilemez kanıt**: imzalanabilir rapor, SHA-256, hash zincirli iz | Kontrol testi raporu ve denetim izi | Mercek Alarm |
| 5 | **Doküman kanıtı**: "bu bulgu için doküman güncellendi mi?" | Uyum taraması ve ekip raporu (değişiklik talepleri) | Dokümantasyon Asistanı |
| 6 | **Denetim öncesi hazırlık paketi**: açık bulgular, kanıtlar, test sonuçları | Üç seviyeli rapor deseni | Dokümantasyon Asistanı |

---

## Karar bekleyen konular

| Konu | Seçenekler |
|---|---|
| Bulgu kaynakları | Yalnız iç denetim mi; BDDK ve bağımsız denetim bulguları da mı? |
| Bulgu kayıt sistemi | Mevcut bir sistemle (ör. GRC aracı) entegrasyon mu, bağımsız kayıt mı? |
| İlk pilot | Önerilen: BSEB 23.1 (Mercek Alarm) bulgusunu uçtan uca bu akıştan geçirmek. Kontrol testleri ve kanıt zaten mevcut |
| Kanıt saklama | Rapor arşivinin yeri ve saklama süresi |
| Roller | Bulgu sahibi, kapanış onaylayıcısı, denetim gözlemcisi |

---

## Sonraki adımlar

- [ ] Kapsamın iş birimiyle netleştirilmesi
- [ ] Pilot bulgunun seçilmesi
- [ ] Faz planının çıkarılması ve bu sayfanın kesin kapsamla güncellenmesi
