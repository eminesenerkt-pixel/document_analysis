# Azure DevOps Wiki'ye kopyalama rehberi

Her sayfa `sayfalar/` altında ayrı bir dosya. Dosyayı açın, **tamamını** kopyalayıp Azure'daki sayfanın düzenleyicisine yapıştırın.

## 1. Sayfa ağacı: adları birebir böyle verin

Sayfalar arası bağlantılar sayfa adına göre çalışır. Adı farklı yazarsanız bağlantı kırılır.

| Sıra | Azure'daki sayfa adı | Nerede | Dosya |
|---|---|---|---|
| 1 | **Proje Portföyü** | Kök. İlk bu oluşturulursa ana sayfa olur | `sayfalar/01 Proje Portföyü.md` |
| 2 | **Hizmet Masası Asistanı** | Kök | `sayfalar/02 Hizmet Masası Asistanı.md` |
| 2.1 | **Gelişim Aşamaları** | *Hizmet Masası Asistanı* → Add sub-page | `sayfalar/02.1 Gelişim Aşamaları.md` |
| 2.2 | **Mercek Asistanı** | *Hizmet Masası Asistanı* → Add sub-page | `sayfalar/02.2 Mercek Asistanı.md` |
| 2.3 | **Mercek Alarm** | *Hizmet Masası Asistanı* → Add sub-page | `sayfalar/02.3 Mercek Alarm.md` |
| 2.4 | **Mercek Analist** | *Hizmet Masası Asistanı* → Add sub-page | `sayfalar/02.4 Mercek Analist.md` |
| 3 | **Dokümantasyon Asistanı** | Kök | `sayfalar/03 Dokümantasyon Asistanı.md` |
| 3.1 | **Faz 1 BSEB Uyum İncelemesi** | *Dokümantasyon Asistanı* → Add sub-page | `sayfalar/03.1 Faz 1 BSEB Uyum İncelemesi.md` |
| 3.2 | **Faz 1 Gelişim Günlüğü** | *Dokümantasyon Asistanı* → Add sub-page | `sayfalar/03.2 Faz 1 Gelişim Günlüğü.md` |
| 4 | **Denetim Asistanı** | Kök | `sayfalar/04 Denetim Asistanı.md` |
| 5 | **Kullanılan Komponentler** | Kök | `sayfalar/05 Kullanılan Komponentler.md` |

Sayfa adına `#` başlığı yazmayın; Azure sayfa adını zaten başlık olarak gösterir. Dosyalarda bu yüzden başlık satırı yok.

## 2. Görseller

Diyagramların çoğu Mermaid ile yazıldı; Azure bunları kendisi çizer, ek bir şey gerekmez. Yalnızca iki sayfada hazır PNG görseller var. Bu sayfalarda görselin gideceği yerde şöyle bir işaret göreceksiniz:

> 📎 **GÖRSEL BURAYA:** `02.2_hm_00_genel_resim.png`

Bu iki satırı silin ve `gorseller/` klasöründeki aynı adlı dosyayı o noktaya sürükleyip bırakın. Azure dosyayı yükleyip bağlantıyı kendisi yazar.

| Sayfa | Görsel sayısı | Dosyalar |
|---|---|---|
| `02.2 Mercek Asistanı` | 15 | `02.2_hm_00_genel_resim.png`, `02.2_hm_01_mesajin_gelisi.png`, `02.2_hm_02_niyet_kapisi.png`, `02.2_hm_03_kategori_ve_getirme.png`, `02.2_hm_03b_kurum_bilgisi.png`, `02.2_hm_kurum_arama_ajani.png`, `02.2_hm_04_netlestirme_dongusu.png`, `02.2_hm_05_cozum_ve_kalite.png`, `02.2_hm_06_gerekce_ve_aksiyon.png`, `02.2_hm_07a_hazir_cozum_adaylar.png`, `02.2_hm_07b_hazir_cozum_karar.png`, `02.2_hm_08_yanit_ve_ekran.png`, `02.2_hm_09_bilgi_tabanina_ekleme.png`, `02.2_hm_10_veri_ve_indeksleme.png`, `02.2_hm_mercek_sistem_akisi.png` |
| `03.1 Faz 1 BSEB Uyum İncelemesi` | 6 | `03.1_dok_workflow_graph.png`, `03.1_dok_proje_mimarisi.png`, `03.1_dok_asama_1_kural_secimi.png`, `03.1_dok_asama_1b_ikinci_kontrol.png`, `03.1_dok_asama_2_degerlendirme.png`, `03.1_dok_asama_3_korpus_taramasi.png` |

Görselleri şimdilik eklemek istemezseniz işaret satırlarını silmeniz yeterli; sayfalar onlarsız da eksiksiz okunur.

## 3. Yapıştırdıktan sonra kontrol

- [ ] Mermaid diyagramları çiziliyor mu? (`::: mermaid` blokları)
- [ ] Sayfa içi tablolar (`[[_TOC_]]`) ve alt sayfa listeleri (`[[_TOSP_]]`) görünüyor mu?
- [ ] "Proje Portföyü"ndeki tablodan diğer sayfalara giden bağlantılar açılıyor mu?

Bir diyagram çizilmezse Azure'un Mermaid sürümü o sözdizimini desteklemiyor olabilir. Hangi diyagram olduğunu söyleyin, daha basit bir sözdizimiyle yeniden yazarım.

## Diğer dosyalar

- Kullanıcı akışı sequence diyagramının kaynağı: `../doc/kullanici_akisi_sequence.mmd`
