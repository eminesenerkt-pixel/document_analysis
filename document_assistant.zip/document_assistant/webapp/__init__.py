# -*- coding: utf-8 -*-
"""webapp — çok kullanıcılı, AD girişli Flask arayüzü.

    cd <proje klasörü>
    python run_web.py

CLI'nin (`main.py`) ve tek-operatörlük Streamlit arayüzünün yerini alır;
aynı `graph.py`/`nodes/*` iş mantığını çağırır (bkz. `jobs.py`), üstüne
oturum/kullanıcı ayrımı ve tarayıcı arayüzü ekler.
"""
from __future__ import annotations
import secrets
from pathlib import Path

from flask import Flask, abort, jsonify, request, session

from ..config import APP_VERSION, Config

from . import render
from .routes import bp

_EPHEMERAL_SECRET = secrets.token_hex(32)  # süreç yeniden başlarsa oturumlar düşer


def create_app(cfg: Config | None = None) -> Flask:
    cfg = cfg or Config()
    app = Flask(__name__)
    app.secret_key = cfg.web.secret_key or _EPHEMERAL_SECRET
    if not cfg.web.secret_key:
        app.logger.warning(
            "FLASK_SECRET_KEY ayarlanmamış — oturumlar her yeniden başlatmada "
            "sıfırlanacak. Kalıcı olması için .env'e ekleyin.")

    render.register_filters(app)
    app.register_blueprint(bp)

    # CSRF: oturuma bağlı tek bir rastgele belirteç. Her POST (giriş, banka
    # profili, tarama başlatma) bunu form alanı ya da X-CSRF-Token başlığı
    # olarak geri göndermek zorunda — başka bir siteden tetiklenen bir form
    # gönderimi bu değeri bilemez.
    def csrf_token() -> str:
        if "_csrf" not in session:
            session["_csrf"] = secrets.token_urlsafe(32)
        return session["_csrf"]

    @app.before_request
    def _check_csrf():
        if request.method != "POST":
            return None
        sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token", "")
        expected = session.get("_csrf", "")
        if not expected or not secrets.compare_digest(sent, expected):
            if request.path.startswith("/api/"):
                # Arayüz JS'i JSON bekliyor; HTML hata sayfası "sunucuya
                # ulaşılamadı" gibi yanıltıcı bir mesaja dönüşürdü.
                return jsonify({"error": "Oturum belirteci geçersiz. Sayfayı yenileyip "
                                         "tekrar deneyin."}), 400
            abort(400, description="Geçersiz ya da eksik form belirteci (CSRF). "
                                   "Sayfayı yenileyip tekrar deneyin.")
        return None

    @app.context_processor
    def _inject_globals():
        return {"app_title": "BSEB Uygunluk Taraması", "brand": "Kuveyt Türk",
                "csrf_token": csrf_token, "app_version": APP_VERSION}

    return app
