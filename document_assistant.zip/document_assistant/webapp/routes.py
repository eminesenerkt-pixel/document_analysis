# -*- coding: utf-8 -*-
"""webapp/routes.py — tüm HTTP uçları.

İş mantığı burada yazılmaz: taramanın kendisi `jobs.py` (ki o da
`graph`/`nodes.consolidate`'i çağırır) içinde yaşar. Bu dosya
sadece istek/yanıt, oturum ve dosya yükleme/indirmeyi yönetir.
"""
from __future__ import annotations
import io
import json
import secrets
import time
from datetime import datetime
from pathlib import Path

from flask import (Blueprint, Response, abort, jsonify, redirect,
                   render_template, request, send_file, session, url_for)

from ..config import PACKAGE_DIR, Config
from ..report_pdf import build_internal_pdf, build_pdf_report, build_team_pdf

# Bir taramanın üç PDF'i: dosya adı öneki + üretici.
PDF_KINDS = {
    "ekip":      ("belge-revizyon-talepleri", build_team_pdf),
    "ic":        ("bseb-ic-rapor", build_internal_pdf),
    "ayrintili": ("bseb-ayrintili-denetim-kaydi", build_pdf_report),
}

from . import jobs
from .auth import authenticate, current_user, demo_accounts, login_required

bp = Blueprint("web", __name__)


def _base_config() -> Config:
    return Config()


def _safe_next(target: str | None) -> str:
    """Yalnızca bu uygulamanın kendi yollarına dönülür. `next` doğrudan
    kullanılırsa /login?next=https://baska-site girişten sonra kullanıcıyı
    dışarıya (ör. sahte bir giriş sayfasına) gönderir."""
    if (target and target.startswith("/") and not target.startswith("//")
            and "\\" not in target and ":" not in target.split("?", 1)[0]):
        return target
    return url_for("web.index")


def _safe_upload_name(raw: str) -> str | None:
    """Tarayıcının gönderdiği dosya adından yalnızca SON bileşen alınır —
    "../../config.py" ya da "C:\\x\\y.docx" gibi bir ad upload klasörünün
    dışına yazamaz. Türkçe karakterler korunur (werkzeug.secure_filename
    onları siler). Yalnızca .docx kabul edilir: ayrıştırıcı eski .doc
    biçimini okuyamaz."""
    name = Path((raw or "").replace("\\", "/")).name.strip()
    name = "".join(c for c in name if c.isprintable() and c not in '<>:"|?*')
    if not name or name in (".", "..") or name.startswith("."):
        return None
    if Path(name).suffix.lower() != ".docx":
        return None
    return name


# ------------------------------------------------------------------- giriş
@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user() is not None:
        return redirect(url_for("web.index"))

    cfg = _base_config()
    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        user = authenticate(username, password, cfg)
        if user is None:
            error = "Kullanıcı adı veya parola hatalı."
        else:
            session["user"] = user.to_session()
            session.permanent = True
            return redirect(_safe_next(request.args.get("next")))

    return render_template("login.html", error=error,
                           use_ldap=cfg.web.use_ldap_login,
                           demo_accounts=demo_accounts(cfg))


@bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("web.login"))


def _load_profile(cfg: Config) -> dict:
    path = Path(cfg.paths.bank_profile_json)
    raw = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    questions = {k: v for k, v in raw.items() if not k.startswith("_")}
    labels = {k: raw.get(f"_{k}", k) for k in questions}
    answered = sum(1 for v in questions.values() if isinstance(v, bool))
    return {"questions": questions, "labels": labels, "answered": answered,
           "total": len(questions)}


# -------------------------------------------------------------------- ana
@bp.route("/")
@login_required
def index():
    cfg = _base_config()
    user = current_user()
    my_jobs = sorted(
        (j for j in jobs.JOBS.values() if j.owner == user.username),
        key=lambda j: j.created_at, reverse=True)[:10]
    return render_template("index.html", user=user, cfg=cfg, jobs=my_jobs,
                           profile=_load_profile(cfg),
                           can_edit_profile=cfg.web.can_edit_profile(user.username))


# -------------------------------------------------------------- banka profili
@bp.route("/profile", methods=["POST"])
@login_required
def profile():
    cfg = _base_config()
    if not cfg.web.can_edit_profile(current_user().username):
        abort(403, description="Banka profilini değiştirme yetkiniz yok.")
    path = Path(cfg.paths.bank_profile_json)
    raw = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    questions = {k: v for k, v in raw.items() if not k.startswith("_")}

    merged = dict(raw)
    for code in questions:
        choice = request.form.get(f"cond_{code}", "unknown")
        merged[code] = {"yes": True, "no": False, "unknown": None}.get(choice)
    path.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")
    return redirect(url_for("web.index"))


# -------------------------------------------------------------------- tarama
@bp.route("/api/scan", methods=["POST"])
@login_required
def start_scan():
    user = current_user()
    files = request.files.getlist("documents")
    files = [f for f in files if f.filename]
    if not files:
        return jsonify({"error": "Dosya seçilmedi."}), 400

    mode = request.form.get("mode", "single")
    if mode not in ("single", "corpus"):
        mode = "single"
    if mode == "single" and len(files) > 1:
        return jsonify({"error": "Tek belge modunda yalnızca bir dosya yüklenebilir."}), 400
    if mode == "corpus":
        return jsonify({"error": "Korpus incelemesi henüz aktif değil."}), 400

    names = [_safe_upload_name(f.filename) for f in files]
    if any(n is None for n in names):
        return jsonify({"error": "Yalnızca .docx uzantılı Word dosyaları yüklenebilir."}), 400

    # Saniye çözünürlüğündeki zaman damgası tek başına benzersiz değil: aynı
    # saniyede başlayan iki tarama JOBS'ta birbirinin üzerine yazıyordu.
    run_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
    cfg = _base_config()
    cfg.run_id = run_id
    safe_user = "".join(c for c in user.username if c.isalnum() or c in "._-") or "kullanici"
    # PACKAGE_DIR'e sabitlenir — çalışma dizinine göre bırakılırsa, uygulama
    # proje klasörü dışından başlatıldığında (ör. bir servis/systemd
    # birimi, ya da farklı bir cwd'den `python run_web.py`) yüklemeler ve
    # çıktılar proje klasörünün dışına sessizce yazılır.
    cfg.paths.documents_dir = str(PACKAGE_DIR / "uploads" / safe_user / run_id)
    cfg.paths.extract_dir = str(PACKAGE_DIR / "output" / safe_user / run_id / "extract")
    cfg.paths.report_dir = str(PACKAGE_DIR / "output" / safe_user / run_id / "report")

    upload_dir = Path(cfg.paths.documents_dir)
    upload_dir.mkdir(parents=True, exist_ok=True)
    saved_paths = []
    for f, name in zip(files, names):
        dest = upload_dir / name
        if dest.resolve().parent != upload_dir.resolve():
            return jsonify({"error": "Geçersiz dosya adı."}), 400
        f.save(dest)
        saved_paths.append(str(dest))

    jobs.start_scan(cfg, user.username, saved_paths, mode=mode)
    return jsonify({"run_id": run_id})


@bp.route("/api/scan/<run_id>/events")
@login_required
def scan_events(run_id: str):
    user = current_user()
    job = jobs.get_job(run_id)
    if job is None or job.owner != user.username:
        return jsonify({"error": "not_found"}), 404

    def stream():
        since = 0
        # İlk anlık görüntü + iş bitene kadar canlı akış. Kısa aralıklarla
        # yoklama (0.4s) — ayrı bir mesaj kuyruğu/broker kurmaya değecek
        # kadar yüksek trafikli bir uç değil.
        while True:
            lines, since = job.snapshot_log(since)
            for line in lines:
                yield f"data: {json.dumps(line, ensure_ascii=False)}\n\n"
            if job.status != "running":
                yield f"event: {job.status}\ndata: {json.dumps(job.error)}\n\n"
                break
            time.sleep(0.4)

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@bp.route("/api/scan/<run_id>/results")
@login_required
def scan_results(run_id: str):
    user = current_user()
    job = jobs.get_job(run_id)
    if job is None or job.owner != user.username or job.result is None:
        return jsonify({"error": "not_found"}), 404
    return render_template("results.html", result=job.result)


@bp.route("/api/scan/<run_id>/report.json")
@login_required
def scan_report(run_id: str):
    user = current_user()
    job = jobs.get_job(run_id)
    if job is None or job.owner != user.username or job.result is None:
        return jsonify({"error": "not_found"}), 404
    report_path = Path(job.result.get("report_path", ""))
    if not report_path.is_file():
        return jsonify({"error": "report_missing"}), 404
    return send_file(report_path, as_attachment=True, download_name=report_path.name,
                     mimetype="application/json")


@bp.route("/api/scan/<run_id>/report.pdf")
@login_required
def scan_report_pdf(run_id: str):
    user = current_user()
    job = jobs.get_job(run_id)
    if job is None or job.owner != user.username or job.result is None:
        return jsonify({"error": "not_found"}), 404
    return scan_report_pdf_kind(run_id, "ayrintili")


@bp.route("/api/scan/<run_id>/report-<kind>.pdf")
@login_required
def scan_report_pdf_kind(run_id: str, kind: str):
    user = current_user()
    job = jobs.get_job(run_id)
    if job is None or job.owner != user.username or job.result is None:
        return jsonify({"error": "not_found"}), 404
    if kind not in PDF_KINDS:
        return jsonify({"error": "unknown_report"}), 404
    prefix, build = PDF_KINDS[kind]
    return send_file(io.BytesIO(build(job.result)), as_attachment=True,
                     download_name=f"{prefix}-{run_id}.pdf", mimetype="application/pdf")
