# -*- coding: utf-8 -*-
"""webapp/render.py — sonuç görünümü için etiket/renk eşlemeleri.

Sadece sunum. `templates/results.html` bunları Jinja filtresi olarak
kullanır; iş mantığına (bir hükmün ne anlama geldiğine) dokunmaz.
"""
from __future__ import annotations

from ..labels import RING_LABEL, SEVERITY_LABEL, VERDICT_LABEL, sorted_findings

VERDICT_CLASS = {
    "satisfied": "positive", "satisfied_by_ref": "positive",
    "partial": "warning",
    "not_mentioned": "negative", "contradicted": "negative",
    "out_of_scope": "neutral", "needs_review": "review",
}
SEVERITY_CLASS = {"critical": "negative", "high": "negative",
                  "medium": "warning", "low": "neutral"}


def verdict_counts(documents: list[dict]) -> dict:
    counts: dict[str, int] = {}
    for doc in documents:
        for f in doc.get("findings", []):
            counts[f["verdict"]] = counts.get(f["verdict"], 0) + 1
    return counts


def register_filters(app) -> None:
    app.jinja_env.filters["verdict_label"] = lambda v: VERDICT_LABEL.get(v, v)
    app.jinja_env.filters["verdict_class"] = lambda v: VERDICT_CLASS.get(v, "neutral")
    app.jinja_env.filters["ring_label"] = lambda r: RING_LABEL.get(r, r)
    app.jinja_env.filters["severity_label"] = lambda s: SEVERITY_LABEL.get(s, s or "—")
    app.jinja_env.filters["severity_class"] = lambda s: SEVERITY_CLASS.get(s, "neutral")
    app.jinja_env.filters["sorted_findings"] = sorted_findings
    app.jinja_env.filters["pct"] = lambda x: f"{float(x):.0%}"

    @app.template_filter("recommendation")
    def _recommendation(raw):
        import json
        try:
            return json.loads(raw) if raw else None
        except (json.JSONDecodeError, TypeError):
            return None
