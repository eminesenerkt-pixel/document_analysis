# -*- coding: utf-8 -*-
"""webapp/jobs.py — arka planda çalışan taramalar.

Bir tarama LLM gecikmesi yüzünden dakikalarca sürebilir; Flask'ın tek bir
HTTP isteğinde bunu beklemek pratik değil (tarayıcı/ara sunucu zaman
aşımına uğrar). Bu yüzden tarama ayrı bir thread'de çalışır, ilerleme
`ScanJob.log`'a yazılır; arayüz bunu `/api/scan/<run_id>/events` üzerinden
Server-Sent Events ile CANLI olarak okur — Streamlit sürümündeki
uyku-tabanlı sahte akışın aksine, burada gerçek bir arka plan işinin
gerçek zamanlı günlüğüdür.

İş kaydı bellek-içi (`JOBS` sözlüğü) tutulur — tek süreçli, kurum içi bir
araç için yeterli. Birden fazla worker sürecine (gunicorn -w N gibi)
ölçeklenecekse bu kayıt Redis/veritabanına taşınmalı; şimdilik gerek yok.
"""
from __future__ import annotations
import json
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Literal

from ..config import APP_VERSION, Config
from ..extract import extract as extract_docx
from ..graph import build_document_graph
from ..llm import LLMClient
from ..nodes import consolidate as consolidate_nodes
from ..nodes import corpus as corpus_nodes
from ..registry import load_registry
from ..search import build_search

JobStatus = Literal["running", "done", "error"]

_REGISTRY_CACHE: dict[str, object] = {}
_REGISTRY_LOCK = threading.Lock()


def _cached_registry(cfg: Config):
    """`load_registry` zaten `@lru_cache`'li ama argümanlar (yol/sayfa adı)
    her seferinde aynı olduğu sürece bu zaten önbellekten döner; burada
    ekstra bir şey yapmıyoruz, sadece tek bir çağrı noktası tutuyoruz."""
    return load_registry(cfg.paths.register_xlsx, cfg.paths.register_sheet,
                         cfg.paths.topics_sheet)


@dataclass
class ScanJob:
    run_id: str
    owner: str
    created_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    status: JobStatus = "running"
    log: list[dict] = field(default_factory=list)
    result: dict | None = None
    error: str = ""
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def emit(self, text: str) -> None:
        """A complete status line — one step finished or started."""
        with self._lock:
            self.log.append({"kind": "line", "text": text})

    def stream(self, text: str) -> None:
        """A token fragment from a live LLM call. The UI appends it to the
        line currently being built rather than starting a new one, so a
        streamed answer appears the way it is actually generated — one
        piece at a time — instead of popping in whole once the call returns."""
        with self._lock:
            self.log.append({"kind": "delta", "text": text})

    def finish(self, result: dict) -> None:
        with self._lock:
            self.result = result
            self.status = "done"

    def fail(self, error: str) -> None:
        with self._lock:
            self.error = error
            self.status = "error"

    def snapshot_log(self, since: int) -> tuple[list[str], int]:
        with self._lock:
            return list(self.log[since:]), len(self.log)


JOBS: dict[str, ScanJob] = {}
_JOBS_LOCK = threading.Lock()

# Biten işler bu süreden sonra bellekten silinir; süreç aylarca açık kalsa
# bile JOBS sınırsız büyümez. Rapor dosyaları diskte (output/) kalır.
JOB_RETENTION_S = 24 * 3600


def _prune_jobs() -> None:
    """_JOBS_LOCK tutulurken çağrılır. Çalışan bir işe asla dokunmaz."""
    now = datetime.now()
    for run_id in [rid for rid, j in JOBS.items()
                   if j.status != "running"
                   and (now - datetime.fromisoformat(j.created_at)).total_seconds()
                   > JOB_RETENTION_S]:
        del JOBS[run_id]


def get_job(run_id: str) -> ScanJob | None:
    with _JOBS_LOCK:
        return JOBS.get(run_id)


def start_scan(cfg: Config, owner: str, saved_paths: list[str], mode: str = "single") -> ScanJob:
    job = ScanJob(run_id=cfg.run_id, owner=owner)
    with _JOBS_LOCK:
        _prune_jobs()
        JOBS[cfg.run_id] = job
    thread = threading.Thread(target=_run_scan, args=(job, cfg, saved_paths, mode), daemon=True)
    thread.start()
    return job


def _run_scan(job: ScanJob, cfg: Config, saved_paths: list[str], mode: str = "single") -> None:
    """`mode`:
      "single"  one document, evaluated on its own. The corpus-level question
                ("is this requirement covered by a DIFFERENT document?") is
                meaningless with nothing else to check against, so reverse_scan
                and evidence_agent — which only make sense across a real
                document set — are skipped rather than reporting every topic
                this one document was never about as a false "gap".
      "corpus"  the full multi-document pass, unused for now (upload screen
                keeps it disabled until it is wired up)."""
    try:
        job.emit("Belgeler ayrıştırılıyor...")
        extract_dir = Path(cfg.paths.extract_dir)
        extract_dir.mkdir(parents=True, exist_ok=True)
        for p in saved_paths:
            data = extract_docx(p, tracked_changes=cfg.policy.tracked_changes)
            (extract_dir / f"{Path(p).stem}.json").write_text(
                json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

        search_fn = build_search(cfg.paths.extract_dir)
        registry = _cached_registry(cfg)
        client = LLMClient(cfg.llm)
        doc_graph = build_document_graph(client, registry, cfg, progress=job.emit)

        records = []
        for i, path in enumerate(saved_paths):
            name = Path(path).name
            job.emit(f"{name} taranıyor ({i + 1}/{len(saved_paths)})...")
            result = doc_graph.invoke({"path": path, "findings": [], "reverse_findings": [],
                                       "pending_review": []})
            findings = result.get("findings", [])
            reverse_findings = result.get("reverse_findings", [])
            for f in findings + reverse_findings:
                # Sonuç sayfası "REQ-5.5.a" gibi iç kodları değil, BSEB'in
                # kendi madde numarasını ve gereksinim cümlesini gösterir —
                # okuyan kişi teknik olmak zorunda değil.
                req = registry.by_id.get(f["req_id"])
                f["article"] = req["article"] if req else ""
                f["requirement_text"] = req["text"] if req else ""
            doc_id = result.get("document_id", path)
            records.append({
                "document_id": doc_id,
                "path": path,
                "sha256": result.get("sha256", ""),
                "profile": result.get("profile", {}),
                "findings": findings,
                "reverse_findings": reverse_findings,
                "sections": consolidate_nodes.build_sections(result.get("blocks", [])),
                "warnings": result.get("warnings", []),
                "error": result.get("error", ""),
            })
            if result.get("error"):
                job.emit(f"  uyarı: {result['error']}")

        state = {"run_id": job.run_id, "document_paths": saved_paths, "documents": records,
                 "mode": mode, "app_version": APP_VERSION}

        if mode == "corpus":
            job.emit("Kapsam kontrolü yapılıyor...")
            state.update(corpus_nodes.reverse_scan(state, registry=registry, cfg=cfg))

            if state["orphan_requirements"]:
                job.emit(f"{len(state['orphan_requirements'])} gereksinim başka "
                         "belgelerde aranıyor...")
                state.update(corpus_nodes.evidence_agent(
                    state, client=client, registry=registry, cfg=cfg, search=search_fn,
                    progress=job.emit))
        else:
            state["covered_requirements"] = {}
            state["orphan_requirements"] = []
            state["missing_document_types"] = []

        job.emit("Tavsiyeler yazılıyor...")
        state.update(consolidate_nodes.consolidate(state, client=client, registry=registry,
                                                   cfg=cfg, progress=job.emit, stream=job.stream))

        job.emit("Rapor oluşturuluyor...")
        state.update(corpus_nodes.render_report(state, registry=registry, cfg=cfg))

        job.emit("Tamamlandı.")
        job.finish(state)
    except Exception as exc:                                       # noqa: BLE001
        job.emit("Hata oluştu.")
        job.fail(_friendly_error(exc) + "\n" + traceback.format_exc(limit=6))


def _friendly_error(exc: Exception) -> str:
    """İlk satır arayüzde gösterilen, kullanıcıya dönük özet; altındaki ham
    iz ise "Teknik ayrıntılar" içinde kalır. Bilinen gateway hataları için
    ne yapılacağını söyler."""
    text = str(exc)
    if "CERTIFICATE_VERIFY_FAILED" in text:
        return ("Model sunucusunun sertifikası doğrulanamadı. Kurum kök sertifikasını "
                "(LLM_CA_BUNDLE) .env dosyasında tanımlayın ya da BS ekibine danışın.")
    if "context length" in text or "input tokens" in text:
        return ("Belge veya kural listesi, modelin bağlam sınırını aştı. "
                "REVERSE_CHECK_CHUNK_CHARS / REVERSE_CHECK_RULES_PER_BATCH değerlerini küçültün.")
    if "LLM request failed" in text or "LLM stream failed" in text:
        return "Model sunucusuna ulaşılamadı ya da yanıt alınamadı. Bağlantıyı ve .env ayarlarını kontrol edin."
    return "Tarama beklenmedik bir hatayla durdu. Ayrıntılar için 'Teknik ayrıntıları göster'e bakın."
