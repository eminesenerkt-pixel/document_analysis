// webapp/static/js/app.js — sunum katmanı: yükleme, canlı ilerleme (SSE),
// sonuçların yerinde açılıp kapanması. İş mantığına dokunmaz; sunucudaki
// /api/scan* uçlarının ince bir istemcisidir.
(function () {
  "use strict";

  const dropzone = document.getElementById("dropzone");
  const fileInput = document.getElementById("fileInput");
  const fileList = document.getElementById("fileList");
  const startBtn = document.getElementById("startBtn");
  const scanForm = document.getElementById("scanForm");
  const consolePanel = document.getElementById("consolePanel");
  const consoleEl = document.getElementById("console");
  const progressBar = document.getElementById("progressBar");
  const resultsContainer = document.getElementById("resultsContainer");
  const stepsEl = document.getElementById("steps");
  const detailsToggle = document.getElementById("detailsToggle");
  const spinnerEl = document.getElementById("progressSpinner");
  const titleEl = document.getElementById("progressTitle");
  const hintEl = document.getElementById("progressHint");
  const scanErrorEl = document.getElementById("scanError");

  // Hata: kısa, anlaşılır özet kullanıcıya; ham iz "Teknik ayrıntılar"a.
  function showScanError(summaryAndDetail) {
    const [summary, ...rest] = String(summaryAndDetail).split("\n");
    scanErrorEl.textContent = summary;
    scanErrorEl.style.display = "block";
    titleEl.textContent = "Tarama tamamlanamadı";
    hintEl.style.display = "none";
    spinnerEl.style.display = "none";
    stepsEl.querySelectorAll(".kt-step.active").forEach((li) => {
      li.classList.remove("active");
      li.classList.add("failed");
    });
    if (rest.length) appendLine(rest.join("\n"), true);
  }

  function resetScanUi() {
    scanErrorEl.style.display = "none";
    scanErrorEl.textContent = "";
    titleEl.textContent = "Belgeniz inceleniyor";
    hintEl.style.display = "";
    spinnerEl.style.display = "";
  }

  if (detailsToggle) {
    detailsToggle.addEventListener("click", () => {
      const open = consoleEl.style.display !== "none";
      consoleEl.style.display = open ? "none" : "block";
      detailsToggle.classList.toggle("open", !open);
      detailsToggle.textContent = open ? "Teknik ayrıntıları göster" : "Teknik ayrıntıları gizle";
    });
  }

  // ------------------------------------------------------- adım sınıflama
  // Sunucu sabit bir "adım kodu" göndermiyor, serbest metin satırları
  // gönderiyor (bkz. jobs.py/nodes/*.py'deki progress() çağrıları) — bu
  // yüzden her satır, içeriğine göre 6 sabit adımdan birine eşleniyor.
  // Sıra önemli: daha özel örüntüler, daha genel olanlardan ÖNCE kontrol
  // edilir (ör. "öneri yazılıyor" her zaman "değerlendiriliyor"dan önce
  // gelir ama metin olarak örtüşebilecek bir yan cümle içerebilir).
  const STEP_ORDER = ["parse", "topics", "evaluate", "reverse", "recommend", "report"];
  const STEP_PATTERNS = [
    ["report", /rapor oluşturuluyor/i],
    ["recommend", /tavsiyeler yazılıyor|öneri yazılıyor|birleştiriliyor/i],
    ["reverse", /ikinci kontrol|olası aykırılık|çağrı \d+\/\d+|madde no bildirdi/i],
    ["evaluate", /evrensel halka|itiraz turu|bulgu ayakta kaldı|itiraz kabul edildi|değerlendiriliyor|kapsam kontrolü|korpusta kanıt/i],
    ["topics", /konu sınıflandırması|seçilen konular|ek konu kontrolü|çeviri kontrolü/i],
    ["parse", /ayrıştırılıyor|taranıyor \(|künye\/onay/i],
  ];

  function classifyStep(text) {
    for (const [step, re] of STEP_PATTERNS) {
      if (re.test(text)) return step;
    }
    return null;
  }

  let furthestStepIndex = -1;
  function advanceStep(text) {
    if (!stepsEl) return;
    const step = classifyStep(text);
    if (!step) return;
    const idx = STEP_ORDER.indexOf(step);
    if (idx < furthestStepIndex) return;    // geri gitme — aynı adımın tekrar eden satırları
    for (let i = 0; i < idx; i++) {
      markStep(STEP_ORDER[i], "done");      // önceki adım (ve atlanmış olabilecek aradakiler) biter
    }
    markStep(step, "active");
    furthestStepIndex = idx;
  }

  function markStep(step, state) {
    const li = stepsEl.querySelector(`[data-step="${step}"]`);
    if (!li) return;
    li.classList.remove("active", "done");
    if (state) li.classList.add(state);
  }

  function finishAllSteps() {
    if (!stepsEl) return;
    stepsEl.querySelectorAll(".kt-step").forEach((li) => {
      li.classList.remove("active");
      li.classList.add("done");
    });
  }

  function resetSteps() {
    if (!stepsEl) return;
    furthestStepIndex = -1;
    stepsEl.querySelectorAll(".kt-step").forEach((li) => li.classList.remove("active", "done"));
  }

  // ------------------------------------------------------------- yükleme
  function renderFileList() {
    fileList.innerHTML = "";
    const files = fileInput.files || [];
    for (const f of files) {
      const li = document.createElement("li");
      li.textContent = f.name;
      fileList.appendChild(li);
    }
    startBtn.disabled = files.length === 0;
  }

  if (dropzone) {
    dropzone.addEventListener("dragover", (e) => { e.preventDefault(); dropzone.classList.add("drag"); });
    dropzone.addEventListener("dragleave", () => dropzone.classList.remove("drag"));
    dropzone.addEventListener("drop", (e) => {
      e.preventDefault();
      dropzone.classList.remove("drag");
      fileInput.files = e.dataTransfer.files;
      renderFileList();
    });
    fileInput.addEventListener("change", renderFileList);
  }

  // --------------------------------------------------------- canlı konsol
  // "line": bir adım tamamlandı/başladı — her zaman yeni bir satır.
  // "delta": modelin ürettiği bir metin parçası — bir önceki delta'nın
  // açtığı satıra eklenir, böylece yanıt gerçekten üretildiği gibi, parça
  // parça görünür (sahte bir daktilo efekti değil, gerçek token akışı).
  //
  // Model çıktısı yapılandırılmış JSON'dur (nodes/consolidate.py
  // CONSOLIDATE_SCHEMA) — ham haliyle akıtılırsa kullanıcı
  // '{"internal_summary": "...", "change_requests": [...' gibi teknik bir
  // metin görür. extractProse(), akan JSON'un TAMAMINI her delta'da yeniden
  // tarar ve sadece düz-metin alanlarının değerini gösterir; anahtar adları
  // ve noktalama kullanıcıya hiç yansımaz. ŞEMA DEĞİŞİRSE BU LİSTE DE
  // DEĞİŞMELİ — eşleşmeyen alanlar konsolda boş satır olarak görünür.
  const PROSE_FIELDS = ["internal_summary", "text", "proposed_text",
                        "finding_statement", "risk", "recommendation", "reason"];

  function extractProse(raw) {
    const re = /"(\w+)"\s*:\s*"((?:[^"\\]|\\.)*)"?/g;
    const parts = [];
    let m;
    while ((m = re.exec(raw)) !== null) {
      if (!PROSE_FIELDS.includes(m[1])) continue;
      parts.push(m[2].replace(/\\n/g, " ").replace(/\\"/g, '"'));
    }
    return parts.join("  ·  ");
  }

  let openStreamLine = null;
  let openStreamText = null;
  let openStreamRaw = "";

  function closeStreamLine() {
    if (openStreamLine) {
      const cursor = openStreamLine.querySelector(".cursor");
      if (cursor) cursor.remove();
    }
    openStreamLine = null;
    openStreamText = null;
    openStreamRaw = "";
  }

  function appendLine(text, isError) {
    closeStreamLine();
    const line = document.createElement("div");
    line.className = "line";
    if (isError) line.style.color = "#ff9d9d";
    line.textContent = text;
    consoleEl.appendChild(line);
    consoleEl.scrollTop = consoleEl.scrollHeight;
  }

  function appendDelta(text) {
    if (!openStreamLine) {
      openStreamLine = document.createElement("div");
      openStreamLine.className = "line line-stream";
      openStreamText = document.createTextNode("");
      openStreamLine.appendChild(openStreamText);
      const cursor = document.createElement("span");
      cursor.className = "cursor";
      openStreamLine.appendChild(cursor);
      consoleEl.appendChild(openStreamLine);
    }
    openStreamRaw += text;
    openStreamText.nodeValue = extractProse(openStreamRaw);
    consoleEl.scrollTop = consoleEl.scrollHeight;
  }

  function setProgress(pct) {
    progressBar.style.width = Math.max(0, Math.min(100, pct)) + "%";
  }

  function watchScan(runId) {
    consolePanel.style.display = "block";
    consoleEl.innerHTML = "";
    closeStreamLine();
    resetSteps();
    resetScanUi();
    setProgress(4);
    let lineCount = 0;

    const source = new EventSource(`/api/scan/${runId}/events`);
    source.onmessage = (evt) => {
      const entry = JSON.parse(evt.data);
      if (entry.kind === "delta") {
        appendDelta(entry.text);
        return;               // bir token adım sayılmaz, ilerleme çubuğunu oynatma
      }
      appendLine(entry.text);
      advanceStep(entry.text);
      lineCount += 1;
      // Gerçek toplam adım sayısı önceden bilinmiyor (belge ve gereksinim
      // sayısına göre değişir); görsel ilerleme yavaşça 90'a yaklaşır, kesin
      // bitiş 'done' olayıyla 100'e tamamlanır.
      setProgress(Math.min(90, 4 + lineCount * 2));
    };
    source.addEventListener("done", () => {
      setProgress(100);
      finishAllSteps();
      titleEl.textContent = "Tamamlandı";
      hintEl.style.display = "none";
      spinnerEl.style.display = "none";
      source.close();
      loadResults(runId);
    });
    source.addEventListener("error", (evt) => {
      source.close();
      setProgress(100);
      if (evt.data) {
        showScanError(JSON.parse(evt.data));
      } else {
        showScanError("Sunucuyla bağlantı kesildi. Sayfayı yenileyip tekrar deneyin.");
      }
    });
    source.onerror = () => {
      // Bağlantı kesilirse (sunucu yeniden başladıysa vb.) sonsuz
      // yeniden-denemeyi EventSource'a bırakmak yerine temiz kapat.
      source.close();
    };
  }

  function loadResults(runId) {
    fetch(`/api/scan/${runId}/results`)
      .then((r) => r.text())
      .then((html) => { resultsContainer.innerHTML = html; })
      .catch(() => appendLine("Sonuçlar yüklenemedi.", true));
  }

  if (scanForm) {
    scanForm.addEventListener("submit", (e) => {
      e.preventDefault();
      startBtn.disabled = true;
      const formData = new FormData(scanForm);
      consolePanel.style.display = "block";
      resetScanUi();
      fetch("/api/scan", {
        method: "POST",
        body: formData,
        headers: { "X-CSRF-Token": formData.get("csrf_token") || "" },
      })
        .then((r) => r.json())
        .then((data) => {
          if (data.run_id) {
            watchScan(data.run_id);
          } else {
            showScanError(data.error || "Tarama başlatılamadı.");
          }
        })
        .catch(() => showScanError("Sunucuya istek gönderilemedi. Bağlantıyı kontrol edin."))
        .finally(() => { startBtn.disabled = false; });
    });
  }

  // ------------------------------------------------- geçmiş taramalar
  document.addEventListener("click", (e) => {
    if (e.target.matches(".kt-view-past")) {
      e.preventDefault();
      loadResults(e.target.dataset.runid);
      resultsContainer.scrollIntoView({ behavior: "smooth" });
    }
  });

  // http:// ile açılan iç ağ adreslerinde navigator.clipboard yoktur
  // (yalnızca https ve localhost'ta çalışır); eski yol yedek olarak kalır.
  function fallbackCopy(text, done) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand("copy"); done(); } catch (err) { /* sessizce geç */ }
    document.body.removeChild(ta);
  }

  // --------------------------------------------- belge/madde kartlarının
  // açılıp kapanması (içerik dinamik eklendiği için olay devretme kullanılır)
  document.addEventListener("click", (e) => {
    // Rapor seçici: üç buton, her biri kendi görünümünü açar.
    const tab = e.target.closest("[data-report-tab]");
    if (tab) {
      const root = tab.closest("[data-results]");
      const name = tab.dataset.reportTab;
      root.querySelectorAll("[data-report-tab]").forEach((b) =>
        b.classList.toggle("active", b === tab));
      root.querySelectorAll("[data-report]").forEach((s) => {
        s.hidden = s.dataset.report !== name;
      });
      return;
    }
    // Ekip raporu: ekrandaki metni e-postaya yapıştırılabilir düz metin olarak kopyalar.
    const copyBtn = e.target.closest("[data-copy-report]");
    if (copyBtn) {
      const src = copyBtn.closest("[data-report]").querySelector("[data-copy-source]");
      const text = src.innerText.replace(/\n{3,}/g, "\n\n").trim();
      const done = () => {
        const old = copyBtn.textContent;
        copyBtn.textContent = "Kopyalandı ✓";
        setTimeout(() => { copyBtn.textContent = old; }, 1800);
      };
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done, () => fallbackCopy(text, done));
      } else {
        fallbackCopy(text, done);
      }
      return;
    }
    const docHead = e.target.closest('[data-toggle="doc"]');
    if (docHead) {
      docHead.parentElement.classList.toggle("open");
      return;
    }
    const sectionHead = e.target.closest('[data-toggle="section"]');
    if (sectionHead) {
      const body = sectionHead.nextElementSibling;
      const open = body.style.display !== "none";
      body.style.display = open ? "none" : "block";
      sectionHead.classList.toggle("open", !open);
      return;
    }
    const findingHead = e.target.closest('[data-toggle="finding"]');
    if (findingHead) {
      const card = findingHead.closest(".kt-finding");
      const body = findingHead.nextElementSibling;
      const open = body.style.display !== "none";
      body.style.display = open ? "none" : "block";
      card.classList.toggle("collapsed", open);
    }
  });
})();
