# -*- coding: utf-8 -*-
"""webapp/auth.py — çok kullanıcılı giriş.

İki yol, tek arayüz (`authenticate`, `User`):

  USE_LDAP_LOGIN=true   kurumsal AD'ye karşı doğrular (servis hesabıyla
                        kullanıcıyı bul, sonra KENDİ parolasıyla bağlanmayı
                        dene — parola hiç saklanmaz, sadece o an denenir).
  USE_LDAP_LOGIN=false  (varsayılan) yerel demo hesap deposuna düşer, AD
                        olmadan da arayüz test edilebilsin diye.

Bu, `directory.py`'den KASITLI OLARAK ayrı bir modül:
`directory.py` bir belgedeki ismin AD'de var olup olmadığını sorar (parola
yok, salt-okunur); burası gerçek bir insanın oturum açmasını doğrular
(parola var, tek seferlik). İkisi aynı AD sunucusuna (`cfg.ldap.*`) konuşur
ama farklı sorular sorar — bkz. `config.py:LDAPConfig` docstring'i.

`ldap3` yalnızca `USE_LDAP_LOGIN=true` olduğunda, `_ldap_authenticate()`
çağrıldığında import edilir.
"""
from __future__ import annotations
import hashlib
import hmac
import logging
import os
import re
import time
from dataclasses import dataclass, field
from functools import wraps

from flask import g, jsonify, redirect, request, session, url_for

from ..config import Config, LDAPConfig

logger = logging.getLogger(__name__)

SESSION_KEY = "user"


@dataclass(frozen=True)
class User:
    username: str
    display_name: str
    email: str = ""

    def to_session(self) -> dict:
        return {"username": self.username, "display_name": self.display_name,
                "email": self.email}

    @staticmethod
    def from_session(data: dict | None) -> "User | None":
        if not data or not data.get("username"):
            return None
        return User(username=data["username"], display_name=data.get("display_name", ""),
                    email=data.get("email", ""))


# ------------------------------------------------------------------ AD girişi
#
# NOT (kurum bilgisayarında yaşanan gerçek arıza): ilk sürüm burada iki
# varsayım yapıyordu ve ikisi de kurum ortamında yanlış çıktı.
#   1. LDAP_SERVER_URI boş bırakılırsa ldap3 SESSİZCE localhost:389'a
#      bağlanmaya çalışır ve "Connection refused" verir — asıl sebep
#      ("adres hiç ayarlanmamış") gizlenir. Şimdi açıkça hata basılıyor.
#   2. Servis hesabı (LDAP_BIND_DN) her zaman var sayılıyordu. Kurumda
#      servis hesabı IT'den beklemeden, kullanıcının KENDİ hesabıyla
#      (self-bind) da doğrulama yapılabilmesi gerekti — bağlantı
#      kurulduysa parola zaten doğrulanmış demektir, ayrı bir 3. adıma
#      gerek kalmaz.
#   3. Arama filtresi tek bir {username} yer tutucusuyla hem
#      sAMAccountName hem mail alanına aynı değeri (çıplak hesap adı YA DA
#      tam e-posta) veriyordu — ikisi aynı anda doğru olamaz
#      ("sAMAccountName=esener" ile "mail=esener" iki farklı sorgu
#      gerektirir). {account}/{email} ayrımı bunu çözüyor.
def _first(values) -> str:
    return values[0] if values else ""


def _build_login_filter(template: str, username: str, cfg: LDAPConfig, escape) -> str:
    """Giriş filtresindeki yer tutucuları doldurur.

      {account}   domain öneki/soneki atılmış çıplak hesap adı → esener
      {email}     hesap adı + İLK UPN soneki                   → esener@kurum.com.tr
      {username}  filtre mail/userPrincipalName arıyorsa {email}, yoksa {account}
                  (eski, tek-yer-tutuculu filtrelerin değişmeden çalışması için)
    """
    account = username.split("@", 1)[0].split("\\")[-1]
    suffix = (cfg.upn_suffixes or [""])[0]
    email = username if "@" in username else f"{account}@{suffix}" if suffix else account
    legacy = email if re.search(r"(mail|userPrincipalName)\s*=\s*\{username\}",
                                template, re.IGNORECASE) else account
    return (template.replace("{account}", escape(account))
                    .replace("{email}", escape(email))
                    .replace("{username}", escape(legacy)))


def _ldap_authenticate(username: str, password: str, cfg: LDAPConfig) -> User | None:
    """Servis hesabıyla (varsa) kullanıcıyı bulur, sonra KENDİ parolasıyla
    bağlanmayı dener. Servis hesabı TANIMLI DEĞİLSE doğrudan kullanıcının
    kendi hesabıyla bağlanılır (self-bind) — bağlantı kurulduysa parola
    zaten doğrulanmıştır. Sebep ne olursa olsun (kullanıcı yok, parola
    yanlış, sunucuya ulaşılamadı) `None` döner — çağıran taraf tek bir hata
    mesajı gösterir, AD'nin iç detaylarını sızdırmaz."""
    try:
        from ldap3 import ALL, SUBTREE, Connection, Server
        from ldap3.core.exceptions import LDAPBindError, LDAPException, LDAPSocketOpenError
        from ldap3.utils.conv import escape_filter_chars
    except ImportError:
        logger.error("USE_LDAP_LOGIN açık ama 'ldap3' kurulu değil (pip install ldap3).")
        return None

    username = (username or "").strip()
    if not username or not password:
        return None
    if not cfg.server_uri.strip():
        # Boş adresle ldap3 sessizce localhost:389'a bağlanmaya çalışır ve
        # "Connection refused" döner — asıl neden dışarıdan görünmez.
        logger.error("USE_LDAP_LOGIN açık ama LDAP_SERVER_URI tanımlı değil. "
                     ".env'e ör. LDAP_SERVER_URI=ldaps://dc01.kurum.local:636 yazın.")
        return None

    # Servis hesabı yoksa kullanıcının kendi hesabıyla bağlanılır (UPN).
    self_bind = not cfg.bind_dn.strip()
    if self_bind:
        suffix = (cfg.upn_suffixes or [""])[0]
        bind_user = username if ("@" in username or "\\" in username) \
            else (f"{username}@{suffix}" if suffix else username)
        bind_password = password
    else:
        bind_user = cfg.bind_dn
        bind_password = cfg.bind_password

    def build_server() -> "Server":
        return Server(cfg.server_uri, get_info=ALL, use_ssl=cfg.use_ssl,
                      connect_timeout=cfg.connect_timeout)

    service_conn = None
    last_error: Exception | None = None
    for attempt in range(1, cfg.max_retries + 1):
        try:
            service_conn = Connection(build_server(), user=bind_user,
                                      password=bind_password, auto_bind=True,
                                      receive_timeout=cfg.receive_timeout)
            break
        except LDAPBindError as error:
            # Yanlış kimlik bilgisiyle tekrar denemek aynı sonucu verir —
            # boşuna beklemeden hemen çık.
            if self_bind:
                logger.warning("LDAP girişi: parola doğrulaması başarısız: %s", username)
            else:
                logger.error("LDAP servis hesabıyla bağlanılamadı "
                             "(LDAP_BIND_DN/LDAP_BIND_PASSWORD hatalı olabilir): %s", error)
            return None
        except (LDAPSocketOpenError, OSError) as error:
            last_error = error
            if attempt < cfg.max_retries:
                time.sleep(cfg.retry_delay)
        except LDAPException as error:
            logger.error("LDAP servis bağlantısı kurulamadı: %s", error)
            return None

    if service_conn is None:
        logger.error("LDAP servis bağlantısı %s denemeden sonra başarısız: %s",
                     cfg.max_retries, last_error)
        return None

    try:
        search_filter = _build_login_filter(cfg.login_search_filter, username, cfg,
                                            escape_filter_chars)
        service_conn.search(
            search_base=cfg.user_search_base, search_filter=search_filter,
            search_scope=SUBTREE,
            attributes=["displayName", "cn", "mail"])
        if not service_conn.entries:
            logger.warning("LDAP girişi: kullanıcı bulunamadı: %s", username)
            return None
        entry = service_conn.entries[0]
        user_dn = entry.entry_dn
        attrs = entry.entry_attributes_as_dict
    finally:
        service_conn.unbind()

    # Kendi hesabıyla bağlanıldıysa parola 1. adımda zaten doğrulandı —
    # ayrı bir 3. adım (ikinci bağlantı) gereksiz.
    if not self_bind:
        try:
            user_conn = Connection(build_server(), user=user_dn, password=password,
                                   receive_timeout=cfg.receive_timeout)
            if not user_conn.bind():
                logger.warning("LDAP girişi: parola doğrulaması başarısız: %s", username)
                return None
            user_conn.unbind()
        except LDAPBindError:
            logger.warning("LDAP girişi: parola doğrulaması başarısız: %s", username)
            return None
        except (LDAPSocketOpenError, OSError, LDAPException) as error:
            logger.error("LDAP doğrulama bağlantısı kurulamadı (%s): %s", user_dn, error)
            return None

    stable_username = (_first(attrs.get("mail", [])) or username).strip().lower()
    display_name = _first(attrs.get("displayName", [])) or _first(attrs.get("cn", [])) or username
    logger.info("LDAP girişi başarılı: %s", stable_username)
    return User(username=stable_username, display_name=display_name,
               email=_first(attrs.get("mail", [])))


# --------------------------------------------------------------- demo deposu
# AD henüz bağlanmadığı için (USE_LDAP_LOGIN=false) burası gerçek bir kimlik
# doğrulama değil — sadece "geçmiş taramalar kime ait" ayrımını yapabilmek
# için herhangi bir ad + sabit demo parolası kabul edilir. AD açılınca bu
# tamamen devre dışı kalır (bkz. authenticate()).
DEMO_PASSWORD = "1234"


def _hash(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 120_000).hex()


_DEMO_SALT = b"dokuman-inceleme-demo"          # sabit tuz: yalnızca demo modunda kullanılır
_DEMO_HASH = _hash(DEMO_PASSWORD, _DEMO_SALT)


def _demo_authenticate(username: str, password: str) -> User | None:
    name = (username or "").strip()
    ok = hmac.compare_digest(_hash(password or "", _DEMO_SALT), _DEMO_HASH)
    if not ok or not name:
        return None
    # Aynı ad her girişte aynı iş sahibine (job.owner) eşlensin diye normalize
    # edilir; ekranda görünen isim yazdığı hâliyle kalır.
    account = re.sub(r"\s+", ".", name.lower())
    return User(username=account, display_name=name)


def demo_accounts(cfg: Config) -> str:
    """Giriş ekranında gösterilecek ipucu metni. AD girişi açıkken ya da
    `SHOW_DEMO_ACCOUNTS=false` iken boş — üretimde kimse bunun bir arka kapı
    olduğunu düşünmesin."""
    if cfg.web.use_ldap_login or not cfg.web.show_demo_accounts:
        return ""
    return f"Herhangi bir ad ve “{DEMO_PASSWORD}” parolasıyla girebilirsin."


# ------------------------------------------------------------------- ortak
def authenticate(username: str, password: str, cfg: Config) -> User | None:
    if cfg.web.use_ldap_login:
        return _ldap_authenticate(username, password, cfg.ldap)
    return _demo_authenticate(username, password)


def current_user() -> User | None:
    if "user" not in g:
        g.user = User.from_session(session.get(SESSION_KEY))
    return g.user


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            if request.path.startswith("/api/"):
                return jsonify({"error": "unauthenticated"}), 401
            return redirect(url_for("web.login", next=request.path))
        return view(*args, **kwargs)
    return wrapper
