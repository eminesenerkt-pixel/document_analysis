# -*- coding: utf-8 -*-
"""Graph assembly.

Two compiled graphs:

  document graph   one Word file -> verified findings
  corpus graph     all files -> coverage gaps, recommendations, report

Design stance: this is a workflow, not an autonomous agent. Edges are fixed,
the model never chooses which requirement to check, and every branch is
reproducible. A compliance report has to be defensible article by article; a
ReAct loop cannot give that. The one place the model does drive its own
control flow is the evidence agent, whose output is a checkable fact rather
than a judgement.
"""
from __future__ import annotations
from functools import partial

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph

from .config import Config
from .llm import LLMClient
from .registry import Registry
from .state import CorpusState, DocumentState
from .nodes import consolidate as consolidate_nodes
from .nodes import corpus as corpus_nodes
from .nodes import evaluate as eval_nodes
from .nodes import ingest as ingest_nodes
from .nodes import metadata_rules
from .nodes import profile as profile_nodes
from .nodes import reverse_check as reverse_check_nodes


# ------------------------------------------------------------ document graph
def build_document_graph(client: LLMClient, registry: Registry, cfg: Config,
                         checkpointer=None, progress=None):
    """`progress`, given, is called with a short status string at each
    meaningful step (one requirement evaluated, one topic pass done, ...).
    Optional and unused by the CLI; the web app wires it to a job's live
    console so a user watching a scan sees every step, not just the final
    per-document line."""
    g = StateGraph(DocumentState)

    g.add_node("ingest",               partial(ingest_nodes.ingest, cfg=cfg, progress=progress))
    g.add_node("check_translation",    partial(profile_nodes.check_translation,
                                               client=client, cfg=cfg, progress=progress))
    # Konu sınıflandırmasından TAMAMEN bağımsız, paralel ikinci kontrol —
    # bkz. nodes/reverse_check.py docstring'i. Ana boru hattıyla aynı anda
    # koşar, kendi ayrı END'ine gider; bulguları normal `findings`'e değil
    # `reverse_findings`'e yazılır, üzerine yazma riski yok.
    g.add_node("reverse_check",        partial(reverse_check_nodes.reverse_check,
                                               client=client, registry=registry, cfg=cfg,
                                               progress=progress))
    g.add_node("profile_document",     partial(profile_nodes.profile_document,
                                               client=client, registry=registry, cfg=cfg,
                                               progress=progress))
    g.add_node("select_topics",        partial(profile_nodes.select_topics,
                                               client=client, registry=registry, cfg=cfg,
                                               progress=progress))
    g.add_node("recall_guard",         partial(profile_nodes.recall_guard,
                                               client=client, registry=registry, cfg=cfg,
                                               progress=progress))
    g.add_node("check_metadata",       partial(metadata_rules.check_metadata, cfg=cfg,
                                               progress=progress))
    g.add_node("expand_requirements",  partial(profile_nodes.expand_requirements,
                                               registry=registry, cfg=cfg))
    g.add_node("evaluate_core",        partial(eval_nodes.evaluate_core,
                                               client=client, cfg=cfg, progress=progress))
    g.add_node("evaluate_border",      partial(eval_nodes.evaluate_border,
                                               client=client, cfg=cfg, progress=progress))
    g.add_node("verify_citations",     partial(eval_nodes.verify_citations, cfg=cfg))
    g.add_node("challenge",            partial(eval_nodes.challenge,
                                               client=client, registry=registry, cfg=cfg,
                                               progress=progress))
    g.add_node("route_for_review",     partial(eval_nodes.route_for_review, cfg=cfg))

    g.add_edge(START, "ingest")
    g.add_conditional_edges("ingest", _ingest_ok,
                            {"ok": "check_translation", "failed": END})
    g.add_edge("check_translation", "profile_document")
    g.add_edge("check_translation", "reverse_check")
    g.add_edge("reverse_check", END)
    g.add_edge("profile_document", "select_topics")
    g.add_edge("select_topics", "recall_guard")
    g.add_edge("recall_guard", "check_metadata")          # rules, no LLM
    g.add_edge("check_metadata", "expand_requirements")

    # fan-out: one branch per candidate requirement, routed by ring
    g.add_conditional_edges("expand_requirements",
                            partial(eval_nodes.fan_out, registry=registry, cfg=cfg),
                            ["evaluate_core", "evaluate_border", "verify_citations"])

    g.add_edge("evaluate_core", "verify_citations")
    g.add_edge("evaluate_border", "verify_citations")
    g.add_edge("verify_citations", "challenge")
    g.add_edge("challenge", "route_for_review")
    g.add_edge("route_for_review", END)

    return g.compile(checkpointer=checkpointer)


def _ingest_ok(state: DocumentState) -> str:
    return "failed" if state.get("error") else "ok"


# -------------------------------------------------------------- corpus graph
def build_corpus_graph(client: LLMClient, registry: Registry, cfg: Config,
                       document_graph, search_fn, checkpointer=None):
    g = StateGraph(CorpusState)

    g.add_node("review_documents", partial(_review_documents,
                                           document_graph=document_graph, cfg=cfg))
    g.add_node("reverse_scan",     partial(corpus_nodes.reverse_scan,
                                           registry=registry, cfg=cfg))
    g.add_node("evidence_agent",   partial(corpus_nodes.evidence_agent,
                                           client=client, registry=registry,
                                           cfg=cfg, search=search_fn))
    # Öneriler bulgu başına değil, belge bölümü başına tek bir değişiklik
    # talebi olarak yazılır (bkz. nodes/consolidate.py).
    g.add_node("recommend",        partial(consolidate_nodes.consolidate,
                                           client=client, registry=registry, cfg=cfg))
    g.add_node("render_report",    partial(corpus_nodes.render_report,
                                           registry=registry, cfg=cfg))

    g.add_edge(START, "review_documents")
    g.add_edge("review_documents", "reverse_scan")
    g.add_conditional_edges("reverse_scan", _has_orphans,
                            {"search": "evidence_agent", "skip": "recommend"})
    g.add_edge("evidence_agent", "recommend")
    g.add_edge("recommend", "render_report")
    g.add_edge("render_report", END)

    return g.compile(checkpointer=checkpointer)


def _has_orphans(state: CorpusState) -> str:
    return "search" if state.get("orphan_requirements") else "skip"


def _review_documents(state: CorpusState, document_graph, cfg: Config) -> CorpusState:
    """Run the document graph once per file. Sequential by default so the
    server's prefix cache stays warm per document; parallelise here if the
    endpoint has headroom."""
    records = []
    for path in state["document_paths"]:
        result = document_graph.invoke(
            {"path": path, "findings": [], "reverse_findings": [], "pending_review": []},
            config={"configurable": {"thread_id": f"{state['run_id']}:{path}"}},
        )
        records.append({
            "document_id": result.get("document_id", path),
            "path": path,
            "sha256": result.get("sha256", ""),
            "profile": result.get("profile", {}),
            "findings": result.get("findings", []),
            "reverse_findings": result.get("reverse_findings", []),
            "sections": consolidate_nodes.build_sections(result.get("blocks", [])),
            "warnings": result.get("warnings", []),
            "error": result.get("error", ""),
        })
    return {"documents": records}


# ------------------------------------------------------------------ factory
def build(cfg: Config, search_fn, checkpointer=None):
    """Convenience: wire everything from a Config."""
    from .registry import load_registry

    client = LLMClient(cfg.llm)
    registry = load_registry(cfg.paths.register_xlsx,
                             cfg.paths.register_sheet,
                             cfg.paths.topics_sheet)
    doc_graph = build_document_graph(client, registry, cfg, checkpointer)
    corpus_graph = build_corpus_graph(client, registry, cfg, doc_graph,
                                      search_fn, checkpointer)
    return corpus_graph, doc_graph, registry, client


def make_checkpointer(path: str):
    """Runs are long; a crash must not cost the whole pass."""
    return SqliteSaver.from_conn_string(path)
