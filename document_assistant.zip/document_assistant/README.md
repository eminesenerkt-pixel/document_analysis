# BSEB Compliance Review Workflow

An agentic LangGraph workflow that reviews a bank's internal information-systems
documents against the BSEB regulation (*Bankaların Bilgi Sistemleri ve
Elektronik Bankacılık Hizmetleri Hakkında Yönetmelik*), article by article, and
produces findings and remediation text.

Runs once a year against a self-hosted Qwen3-235B-A22B behind an
OpenAI-compatible endpoint. Everything is open source.

![workflow](docs/workflow_graph.svg)

---

## The idea in one paragraph

RAG finds what a document **says**. Compliance is about what a document **does
not say**. So requirements are never retrieved by similarity — all 255 of them
sit in a register and are *pushed* at each document by a table lookup. The model
only ever answers one narrow question at a time: *does this text satisfy this
requirement, and where exactly?* Every positive verdict must carry a verbatim
quote, and that quote is checked by string match against the extracted blocks
before the finding is allowed to stand.

## Three rings

Not every article applies to every document, and "applies" has two different
meanings. A Remote Access procedure is responsible for remote access rules; it
is not responsible for key management, but it must not pretend key management
does not exist either.

| Ring | Selected when | Question asked | A gap means |
|---|---|---|---|
| **universal** | always (8 requirements, m.5) | document-control rules | a finding, decided by rules — no LLM |
| **core** | the requirement's home topic is one the document declares | *is this requirement met here?* | a finding |
| **border** | the requirement only touches a declared topic | *is there a valid reference to the owning document?* | a weak finding |

Collapsing core and border would blame every document for every subject it
mentions. Dropping border would let a dependency disappear silently.

Measured on this register: **72%** of the requirements relevant to a typical
Information Security document live outside the regulation's security chapter —
which is why the register's topic map, not the regulation's chapter structure,
drives selection.

---

## Pipeline

### Document graph — one Word file → verified findings

```
ingest → profile_document → select_topics → recall_guard → check_metadata
      → expand_requirements ⇉ evaluate_core / evaluate_border
      → verify_citations → challenge → route_for_review
```

| Node | Kind | What it does |
|---|---|---|
| `ingest` | code | raw OOXML extraction (`extract.py`) — nested tables, text boxes, footnotes, comments, tracked changes |
| `profile_document` | code | title, document code, version, owner, approver, confidentiality; bilingual detection |
| `select_topics` | LLM, T=0 | reads purpose & scope, picks codes from a **closed** catalogue of 54 |
| `recall_guard` | LLM, T=0 | second pass over near-miss topics — models under-select, and a dropped topic silently removes a whole subject area |
| `check_metadata` | code | m.5 document-control rules, deterministic (scores 22/22 on the golden set) |
| `expand_requirements` | code | topics → requirement ids → rings; applies conditional flags |
| `evaluate_core` | LLM, T=0 | document-level NLI: satisfied / partial / contradicted / not_mentioned / out_of_scope / needs_review + evidence spans |
| `evaluate_border` | LLM, T=0 | satisfied_by_ref / partial / not_mentioned + the referenced document's name |
| `verify_citations` | code | verbatim normalized string match; unverifiable quotes downgrade the verdict rather than delete it |
| `challenge` | LLM, T=0 | adversarial pass over negative verdicts only — the single most effective filter on false positives |
| `route_for_review` | code | splits off everything below the confidence threshold |

The fan-out is a LangGraph `Send` per candidate requirement; findings merge back
through an `operator.add` reducer.

### Corpus graph — all files → coverage, recommendations, report

```
review_documents → reverse_scan ⇢ evidence_agent → recommend → render_report
```

`reverse_scan` asks the question a per-document review structurally cannot:
*is every requirement covered somewhere?* Whatever comes out uncovered goes to
the **evidence agent** — the one genuinely agentic component, with a variable
number of search rounds, BM25 over the corpus, and the stopping decision left to
the model. It is safe to be agentic there because its output is a checkable
fact ("covered in document X, block Y" / "searched, not present"), not a
judgement. The evaluation core stays deterministic for the opposite reason.

---

## Is there RAG in this?

Not for the regulation, and that is the central design decision.

There is no vector store over the BSEB text, no embedding of articles, no
"retrieve the relevant articles for this document". All 255 requirements are
pushed at each document by a rule — `ana_konu` / `yan_konu` against the topics
the document declares. Retrieval would answer *which articles look similar to
this text?*, and an article the document never mentions has nothing to be
similar to. That is exactly the article you need to find. Retrieval recall of
90% sounds fine and means 25 unchecked articles that nobody can name.

There is retrieval in one place: **the evidence agent**, `search.py`, BM25 over
the extracted blocks of the whole corpus. Its job is the opposite one — a
requirement is already known to be missing from the document that should own it,
and the question is whether some *other* document covers it. That is a
find-what-exists problem, which is what search is good at. Even there the output
is a quote with a document and block id, not a summary.

BM25 rather than embeddings because regulatory Turkish is exact-match heavy —
"uçtan uca güvenli iletişim", "bilmesi gereken kadar", "ikincil sistem". A
`VectorSearch` hook is stubbed for when a Turkish embedding model is worth
adding; keep BM25 in the mix either way.

So: **requirements are pushed, evidence is retrieved.** Never the reverse.

## Why a workflow and not an agent

A compliance report has to be defensible article by article. Edges are fixed,
the model never chooses which requirement to check, and the same input gives the
same output. A ReAct loop cannot give that, and the failure mode it produces —
quietly never checking article 23 — is invisible in the output.

## Accuracy measures, since this runs once a year

- temperature 0 on every judgement call
- self-consistency voting (3 samples) on Kritik/Yüksek risk requirements;
  partial agreement caps confidence
- citation verification with three distinct failure modes: unknown block id /
  quote belongs to a different block / quote not found at all
- adversarial challenge pass before a negative verdict is reported
- the document is placed **first** in every prompt so the server's prefix cache
  covers it across the ~255 requirement calls made against it
- SQLite checkpointing — a crash does not cost the whole pass

---

## Layout

```
compliance_workflow/
  .env.example       template; copy to .env (git-ignored)
  config.py          dotenv loader, endpoint, paths, policy
  state.py           typed state, Verdict/Ring literals, reducers
  llm.py             OpenAI-compatible client, structured output, voting
  registry.py        the 255-requirement register, ring assignment
  extract.py         raw OOXML extraction (100% coverage on the torture test)
  verify.py          verbatim citation verification
  search.py          BM25 over extracted blocks
  nodes/             ingest, profile, metadata_rules, evaluate, corpus
  graph.py           graph assembly
  main.py            CLI
  render_graph.py    the diagram above
  data/              bseb_register.xlsx, bank_profile.json
  documents/         input .docx
  output/            extract/, report/, checkpoints.sqlite
```

## See it for yourself — `trace`

Before reading any of the below, run this. It walks **one** document through
the **real** code and prints every step: the register rows, which of the 255
were selected and why, the exact prompt sent to the model, the answer, the
citation check, the challenge, and the recommendation prompt.

```bash
python -m compliance_workflow.main trace \
    --document documents/DOC-02_Uzaktan_Erisim_Guvenligi_Uygulama_Esasi.docx \
    --req REQ-11.4
```

It works without an endpoint — the model answers are stubbed, but every prompt,
every selection rule and every control is the real one. Add
`--topics a,b,c` to force the scoping when there is no model to choose it.

The nine sections it prints map 1:1 onto the diagram above:

| | | |
|---|---|---|
| 0 | the BSEB list | 255 rows, one shown in full |
| 1 | ingest | Word → blocks |
| 2 | profile | metadata by rules, topics from the closed catalogue |
| 3 | universal ring | m.5 decided by rules, no model |
| 4 | scoping | 255 → N candidates, ring and sample count per requirement |
| 5 | one control in full | system prompt + document + requirement + answer |
| 6 | verification | verbatim citation check |
| 7 | challenge | the model argues against its own finding |
| 8 | recommendation | the prompt and its constraints |
| 9 | reverse scan | what happens after every document |

## The register — where the regulation lives

`data/bseb_register.xlsx` **is** the regulation, in the only form the workflow
reads. Nothing parses the BSEB PDF at runtime; the PDF was converted once, by
hand, into 255 atomic requirements. That conversion is the asset — it is
reviewable, diffable and signable, which a PDF in a vector store is not.

| Sheet | Rows | What it holds |
|---|---|---|
| `Register` | 255 | one atomic requirement per row, m.4–m.45 |
| `Konu Sözlüğü` | 54 | the closed topic catalogue the model selects from |
| `Koşul Kodları` | 15 | conditional requirements and the bank-profile question each depends on |

Columns the workflow reads: `ID`, `Madde`, `Gereksinim`, `Ham metin (dayanak
cümle)`, `Risk seviyesi`, plus the enrichment columns `ana_konu`, `yan_konu`,
`yukumluluk_sekli`, `kosul_kodu`, `evrensel`, `kontrol_sorusu`, `alt_unsurlar`.
The rest are carried for the human reader.

When the regulation is amended, you edit this file — no code changes. Keep it
under version control; the diff of a register between two annual runs is itself
an audit artifact. Put it anywhere you like and point `REGISTER_XLSX` at it.

## Configuration

Copy `.env.example` to `.env` and fill it in. `.env` is git-ignored and is read
automatically from the package directory; real environment variables win over
it, so a scheduler can still inject `LLM_API_KEY` without touching the file.

```bash
cp .env.example .env
```

```ini
LLM_BASE_URL=https://llm.internal/v1
LLM_API_KEY=...
LLM_MODEL=Qwen3-235B-A22B
TRACKED_CHANGES=accepted
REVIEW_THRESHOLD=0.6
SAMPLES_HIGH_RISK=3
```

`data/bank_profile.json` answers the 15 conditional requirements — does the bank
use cloud, does it run its own ATM fleet, is there remote identity verification.
It ships **unanswered on purpose**: nothing here should assume facts about your
bank. An unanswered condition is not silently dropped; the requirement is routed
to human review and recorded in `warnings`. `check` prints how many are still
open.

This is kept out of `.env` deliberately — there are fifteen of them, none are
secret, and they are an auditable statement about the bank that someone has to
sign off.

## Run

```bash
pip install langgraph langgraph-checkpoint-sqlite httpx openpyxl

python -m compliance_workflow.main check                       # pre-flight
python -m compliance_workflow.main extract --documents ./documents
python -m compliance_workflow.main run     --documents ./documents
python -m compliance_workflow.main graph                       # diagram + mermaid
```

`check` prints which `.env` was loaded, the register size, how many conditions
are answered, whether both graphs compile, and whether the endpoint answers.

Paths resolve against the package directory, so the commands work from any
working directory. Override with `WORKFLOW_ROOT`, `REGISTER_XLSX`,
`BANK_PROFILE_JSON`, `DOCUMENTS_DIR`, `OUTPUT_DIR`, or the CLI flags
`--register` / `--documents` / `--out`.

`--tracked-changes accepted|original|all` decides which version of an edited
document is reviewed. Default `accepted`.

## Output

`output/report/findings_<run_id>.json`:

```jsonc
{
  "documents": [{
    "document_id": "...",
    "profile":  { "title": "...", "declared_topics": [...], "approver": "..." },
    "findings": [{
      "req_id": "REQ-9.1", "ring": "core", "verdict": "partial",
      "confidence": 0.82,
      "evidence": [{"block_id": "b0041", "quote": "...", "verified": true}],
      "missing_elements": ["..."],
      "rationale": "...",
      "recommendation": "{finding_statement, risk, recommendation, severity}"
    }],
    "warnings": [...]
  }],
  "covered_requirements": { "REQ-9.1": ["DOC-06"] },
  "orphan_requirements":  ["REQ-31.4"],
  "missing_document_types": ["ikincil_merkez"]
}
```

`orphan_requirements` and `missing_document_types` are the part auditors care
about most: requirements no document in the corpus covers.

## Before the first real run

1. `cp .env.example .env` and set `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL`.
2. Fill in `data/bank_profile.json` — all 15 conditions ship unanswered.
3. `python -m compliance_workflow.main check` until every line is green.

## Limits

- Scope is BSEB only. No ISO 27001, no COBIT — by design.
- A document longer than `max_document_tokens` needs chunking; the hook is in
  `PolicyConfig` but the chunked path is not wired yet.
- `search.py` is BM25 only. `VectorSearch` is stubbed for when a Turkish
  embedding model is available; keep BM25 in the mix either way — regulatory
  Turkish is exact-match heavy.
- Findings are advisory. `pending_review` exists because the last call is a
  human's.
