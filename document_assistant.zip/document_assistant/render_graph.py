# -*- coding: utf-8 -*-
"""İş akışının GERÇEK karar mantığını çizer (Türkçe, somut BSEB örnekleriyle).

Kodun İÇİNDE alınan gerçek kararları (diamond/karar kutusu olarak) ve her
kararın register'daki GERÇEK bir satırla (REQ-14.7, REQ-5.3, REQ-8.2,
REQ-29.11) nasıl sonuçlandığını gösterir — "halka" ya da "koşul" gibi
soyut kelimelerde bırakmadan.

Dört "lane" (1: hangi kural sorulur, 1B: bağımsız ikinci kontrol —
belge → BSEB, 2: bir kural nasıl değerlendirilir, 3: korpus taraması)
hem TEK bir birleşik diyagram (`write()` → workflow_graph.svg, tam
ayrıntı, referans için) hem de SUNUMA uygun, her biri kendi başına bir
slayta sığan AYRI dosyalar olarak üretilir (`write_stages()` →
docs/asamalar/*.svg) — büyük, çok parçalı tek bir diyagram bir
PowerPoint slaydına sığmaz; dört odaklı diyagram sığar.

Lane 1B, Lane 1'in konu sınıflandırmasından TAMAMEN bağımsızdır:
check_translation'dan sonra Lane 1 ile PARALEL başlar (graph.py'deki
`check_translation -> reverse_check -> END` dalı), belgenin tam
metnini 255 maddenin TAMAMIYLA tek seferde karşılaştırır ve bulgularını
ayrı bir listeye (`reverse_findings`) yazar — Lane 1'in kaçırdığı,
konu olarak hiç seçilmemiş bir maddeye aykırı bir cümleyi de yakalar.
"""
from __future__ import annotations
from html import escape
from pathlib import Path

MARGIN = 50
PITCH = 235
NODE_W, NODE_H = 190, 62

STYLE = {
    "kod":    ("#E3F2FD", "#1565C0"),
    "llm":    ("#F3E5F5", "#7B1FA2"),
    "agent":  ("#FFF3E0", "#E65100"),
    "giris":  ("#ECEFF1", "#546E7A"),
    "karar":  ("#E8F5E9", "#2E7D32"),
    "iyi":    ("#DCEDC8", "#33691E"),
    "kotu":   ("#FFEBEE", "#C62828"),
    "ornek":  ("#FFF8E1", "#F9A825"),
}

LEGEND_ITEMS = [
    ("kod", "deterministik kod"), ("llm", "model çağrısı"), ("agent", "otonom döngü"),
    ("giris", "giriş / çıkış"), ("karar", "karar (diamond)"),
    ("iyi", "olumlu sonuç"), ("kotu", "olumsuz / insan"), ("ornek", "register'dan gerçek örnek"),
]

FONT = ("-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, "
        "'Helvetica Neue', Arial, sans-serif")


class Box:
    def __init__(self, cx, cy, w=NODE_W, h=NODE_H):
        self.cx, self.cy, self.w, self.h = cx, cy, w, h
    @property
    def left(self): return self.cx - self.w / 2
    @property
    def right(self): return self.cx + self.w / 2
    @property
    def top(self): return self.cy - self.h / 2
    @property
    def bottom(self): return self.cy + self.h / 2
    def edge(self, side):
        return {"top": (self.cx, self.top), "bottom": (self.cx, self.bottom),
                "left": (self.left, self.cy), "right": (self.right, self.cy)}[side]


class Diamond:
    """Karar kutusu. Yatay akışta: sol köşe = giriş, sağ köşe = 'evet'/devam,
    alt köşe = 'hayır'/alternatif dal, üst köşe = (nadiren) geri bildirim."""
    def __init__(self, cx, cy, hw=105, hh=58):
        self.cx, self.cy, self.hw, self.hh = cx, cy, hw, hh
    def edge(self, side):
        return {"top": (self.cx, self.cy - self.hh), "bottom": (self.cx, self.cy + self.hh),
                "left": (self.cx - self.hw, self.cy), "right": (self.cx + self.hw, self.cy)}[side]
    def svg(self, text, size=11.5):
        p = (f"{self.cx:.0f},{self.cy-self.hh:.0f} {self.cx+self.hw:.0f},{self.cy:.0f} "
            f"{self.cx:.0f},{self.cy+self.hh:.0f} {self.cx-self.hw:.0f},{self.cy:.0f}")
        fill, stroke = STYLE["karar"]
        out = [f'<polygon points="{p}" fill="{fill}" stroke="{stroke}" stroke-width="1.8"/>']
        lines = _wrap(text, 20)
        y0 = self.cy - (len(lines) - 1) * 7
        for i, line in enumerate(lines):
            out.append(f'<text x="{self.cx:.0f}" y="{y0 + i*14:.0f}" text-anchor="middle" '
                       f'font-family="{FONT}" font-size="{size}" font-weight="600" '
                       f'fill="#1a1a1a">{escape(line)}</text>')
        return "".join(out)


def node(box: Box, label: str, kind: str, sub: str = "") -> str:
    fill, stroke = STYLE[kind]
    label, sub = escape(label), escape(sub)
    rx = box.h / 2 if kind == "giris" else 9
    out = [f'<rect x="{box.left:.0f}" y="{box.top:.0f}" width="{box.w:.0f}" '
           f'height="{box.h:.0f}" rx="{rx:.0f}" fill="{fill}" stroke="{stroke}" '
           f'stroke-width="1.8"/>']
    if sub:
        out.append(f'<text x="{box.cx:.0f}" y="{box.cy - 5:.0f}" text-anchor="middle" '
                   f'font-family="{FONT}" font-size="13" font-weight="700" '
                   f'fill="#1a1a1a">{label}</text>')
        for i, line in enumerate(_wrap(sub, 24)):
            out.append(f'<text x="{box.cx:.0f}" y="{box.cy + 12 + i*13:.0f}" text-anchor="middle" '
                       f'font-family="{FONT}" font-size="10.5" fill="#5f6368">{line}</text>')
    else:
        out.append(f'<text x="{box.cx:.0f}" y="{box.cy + 5:.0f}" text-anchor="middle" '
                   f'font-family="{FONT}" font-size="13" font-weight="700" '
                   f'fill="#1a1a1a">{label}</text>')
    return "".join(out)


def example(cx: float, cy: float, title: str, body: str, w: float = 220) -> str:
    """Sarı 'sticky note' — register'dan GERÇEK bir satırla o kararın ne
    anlama geldiğini gösterir. 'Halka deyip geçme' isteğinin karşılığı burada."""
    lines = _wrap(body, 30)
    h = 34 + len(lines) * 13
    fill, stroke = STYLE["ornek"]
    out = [f'<rect x="{cx - w/2:.0f}" y="{cy - h/2:.0f}" width="{w:.0f}" height="{h:.0f}" '
           f'rx="6" fill="{fill}" stroke="{stroke}" stroke-width="1.4" stroke-dasharray="4 3"/>']
    out.append(f'<text x="{cx:.0f}" y="{cy - h/2 + 16:.0f}" text-anchor="middle" '
               f'font-family="{FONT}" font-size="10.5" font-weight="700" '
               f'fill="#8a6d00">{escape(title)}</text>')
    y0 = cy - h/2 + 30
    for i, line in enumerate(lines):
        out.append(f'<text x="{cx:.0f}" y="{y0 + i*13:.0f}" text-anchor="middle" '
                   f'font-family="{FONT}" font-size="10" fill="#5f4900">{escape(line)}</text>')
    return "".join(out)


def arrow(p1, p2, label="", dashed=False, curve=0, color="#5f6368") -> str:
    x1, y1 = p1; x2, y2 = p2
    dash = ' stroke-dasharray="6 4"' if dashed else ""
    if curve:
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2 + curve
        d = f"M {x1:.0f} {y1:.0f} Q {mx:.0f} {my:.0f} {x2:.0f} {y2:.0f}"
    else:
        d = f"M {x1:.0f} {y1:.0f} L {x2:.0f} {y2:.0f}"
    out = [f'<path d="{d}" fill="none" stroke="{color}" stroke-width="1.7"'
           f'{dash} marker-end="url(#ok)"/>']
    if label:
        label = escape(label)
        lx = (x1 + x2) / 2
        ly = (y1 + y2) / 2 + (curve * 0.55 if curve else 0)
        tw = len(label) * 6.0 + 10
        out.append(f'<rect x="{lx - tw/2:.0f}" y="{ly - 9:.0f}" width="{tw:.0f}" '
                   f'height="18" rx="4" fill="#ffffff" opacity="0.97"/>')
        out.append(f'<text x="{lx:.0f}" y="{ly + 4:.0f}" text-anchor="middle" '
                   f'font-family="{FONT}" font-size="11" fill="#3c4043">{label}</text>')
    return "".join(out)


def panel(x, y, w, h, title, subtitle) -> str:
    title, subtitle = escape(title), escape(subtitle)
    return (
        f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="#FAFBFC" '
        f'stroke="#DADCE0" stroke-width="1.5"/>'
        f'<text x="{x + 20}" y="{y + 28}" font-family="{FONT}" font-size="16" '
        f'font-weight="700" fill="#1a1a1a">{title}</text>'
        f'<text x="{x + 20}" y="{y + 47}" font-family="{FONT}" font-size="12" '
        f'fill="#5f6368">{subtitle}</text>'
    )


def _wrap(text: str, width: int) -> list[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width:
            lines.append(cur); cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return lines


def col(i: float) -> float:
    return MARGIN + 40 + i * PITCH + NODE_W / 2


def _legend(x0: float, y: float, items=LEGEND_ITEMS) -> str:
    out = []
    x = x0
    for kind, label in items:
        fill, stroke = STYLE[kind]
        out.append(f'<rect x="{x}" y="{y - 12:.0f}" width="20" height="14" rx="3" '
                   f'fill="{fill}" stroke="{stroke}" stroke-width="1.6"/>')
        out.append(f'<text x="{x + 28}" y="{y:.0f}" font-family="{FONT}" font-size="12" '
                   f'fill="#3c4043">{escape(label)}</text>')
        x += len(label) * 6.6 + 56
    return "".join(out)


def _notes_panel(x0: float, y: float, w: float, title: str, text: str, wrap_width: int) -> tuple[str, float]:
    lines = _wrap(text, wrap_width)
    h = 40 + len(lines) * 17 + 10
    out = [f'<rect x="{x0}" y="{y:.0f}" width="{w:.0f}" height="{h:.0f}" '
           f'rx="12" fill="#FAFBFC" stroke="#DADCE0" stroke-width="1.5"/>']
    out.append(f'<text x="{x0+22}" y="{y+30:.0f}" font-family="{FONT}" font-size="14" '
               f'font-weight="700" fill="#1a1a1a">{escape(title)}</text>')
    ty = y + 52
    for line in lines:
        out.append(f'<text x="{x0+22}" y="{ty:.0f}" font-family="{FONT}" font-size="12" '
                   f'fill="#3c4043">{escape(line)}</text>')
        ty += 17
    return "".join(out), y + h


def _svg_wrap(width: float, height: float, title: str, subtitle: str, body: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:.0f}" height="{height:.0f}" '
        f'viewBox="0 0 {width:.0f} {height:.0f}">'
        '<defs><marker id="ok" viewBox="0 0 10 10" refX="9" refY="5" '
        'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
        '<path d="M 0 0 L 10 5 L 0 10 z" fill="#5f6368"/></marker></defs>'
        f'<rect width="{width:.0f}" height="{height:.0f}" fill="#ffffff"/>'
        f'<text x="{MARGIN}" y="40" font-family="{FONT}" font-size="24" '
        f'font-weight="700" fill="#1a1a1a">{escape(title)}</text>'
        f'<text x="{MARGIN}" y="64" font-family="{FONT}" font-size="13" fill="#5f6368">'
        f'{escape(subtitle)}</text>'
        f'{body}</svg>'
    )


# ============================================================================
# LANE 1 — HANGİ KURAL BU BELGEYE SORULUR? (halka + koşul kararı)
# ============================================================================
def _lane1(p_y: float) -> tuple[str, float, float]:
    s: list[str] = []
    main_y = p_y + 280

    baslangic = Box(col(0), main_y, w=76, h=52)
    ingest = Box(col(1), main_y)
    d_ingest_ok = Diamond(col(2), main_y, hw=88, hh=54)
    cev_kontrol = Box(col(3), main_y, w=190)
    profil = Box(col(4), main_y)
    konu_sec = Box(col(5), main_y)
    konu_kontrol = Box(col(6), main_y)
    d_evrensel = Diamond(col(7), main_y)
    d_ana_konu = Diamond(col(8), main_y)
    d_yan_konu = Diamond(col(9), main_y)
    d_kosul_var = Diamond(col(10), main_y)
    d_kosul_cevapli = Diamond(col(11), main_y)
    d_kosul_true = Diamond(col(12), main_y)
    devam1 = Box(col(13), main_y, w=150, h=52)

    W1 = col(13) + 150 / 2 + MARGIN
    p1_h = 1080

    s.append(panel(MARGIN, p_y, W1 - MARGIN, p1_h, "1 · Hangi kural bu belgeye sorulur?",
                   "255 kuralın HER BİRİ için bu karar zinciri işletilir — register.py::candidates() + applies(), model karışmaz"))

    s.append(node(baslangic, "BAŞLA", "giris"))
    s.append(node(ingest, "ingest", "kod", "OOXML → bloklar"))
    s.append(d_ingest_ok.svg("ayrıştırma başarılı mı?"))
    s.append(node(cev_kontrol, "check_translation", "llm", "TR/EN sürüm karşılaştırma"))
    s.append(node(profil, "profile_document", "kod", "metadata, sınıf, dil"))
    s.append(node(konu_sec, "select_topics", "llm", "kapalı 54 konu listesi"))
    s.append(node(konu_kontrol, "recall_guard", "llm", "yakın-ıskalananı sorar"))
    s.append(d_evrensel.svg("evrensel = EVET mi?"))
    s.append(d_ana_konu.svg("ana_konu, beyan edilen konularda mı?"))
    s.append(d_yan_konu.svg("yan_konu, bir konuya değiyor mu?"))
    s.append(d_kosul_var.svg("kosul_kodu dolu mu?"))
    s.append(d_kosul_cevapli.svg("banka profilinde cevaplı mı?"))
    s.append(d_kosul_true.svg("koşul sağlanıyor mu?"))
    s.append(node(devam1, "Değerlendirilir", "iyi", "2. lane'e girer"))

    s.append(arrow(baslangic.edge("right"), ingest.edge("left")))
    s.append(arrow(ingest.edge("right"), d_ingest_ok.edge("left")))
    bitis_hata = Box(d_ingest_ok.cx, main_y - 190, w=140, h=44)
    s.append(node(bitis_hata, "BİTİŞ (hata)", "giris"))
    s.append(arrow(d_ingest_ok.edge("top"), bitis_hata.edge("bottom"), "hayır", dashed=True))
    s.append(arrow(d_ingest_ok.edge("right"), cev_kontrol.edge("left"), "evet"))
    s.append(arrow(cev_kontrol.edge("right"), profil.edge("left")))
    for a, b in [(profil, konu_sec), (konu_sec, konu_kontrol)]:
        s.append(arrow(a.edge("right"), b.edge("left")))

    paralel_dal = Box(cev_kontrol.cx, main_y + 190, w=180, h=56)
    s.append(node(paralel_dal, "→ 1B. Kontrol", "agent", "paralel dal, ayrı END'e gider"))
    s.append(arrow(cev_kontrol.edge("bottom"), paralel_dal.edge("top"), "aynı anda", dashed=True))
    s.append(arrow(konu_kontrol.edge("right"), d_evrensel.edge("left")))

    kural_motoru = Box(d_evrensel.cx, main_y + 190, w=210, h=58)
    s.append(node(kural_motoru, "check_metadata", "kod", "kural motoru — LLM YOK"))
    s.append(arrow(d_evrensel.edge("bottom"), kural_motoru.edge("top"), "evet"))
    s.append(example(kural_motoru.cx, kural_motoru.cy + 78, "Örnek — REQ-5.3 (evrensel)",
                     "\"BS politikaları YK; prosedür/süreç dokümanları YK ya da yetki devredilen yöneticiler tarafından onaylanır.\" Model hiç sorulmaz, onaylayan alanı regex ile okunur."))
    s.append(arrow(d_evrensel.edge("right"), d_ana_konu.edge("left"), "hayır"))

    core_box = Box(d_ana_konu.cx, main_y + 190, w=190, h=52)
    s.append(node(core_box, "CORE halkası", "iyi", "burada karşılanmış mı?"))
    s.append(arrow(d_ana_konu.edge("bottom"), core_box.edge("top"), "evet"))
    s.append(example(core_box.cx, core_box.cy + 74, "Örnek — REQ-14.7 (core)",
                     "ana_konu = uzaktan_erisim. Belge \"Uzaktan Erişim Güvenliği Uygulama Esası\" bu konuyu beyan etti → CORE. Boşluk = doğrudan bulgu."))
    s.append(arrow(d_ana_konu.edge("right"), d_yan_konu.edge("left"), "hayır"))

    border_box = Box(d_yan_konu.cx, main_y + 190, w=190, h=52)
    s.append(node(border_box, "BORDER halkası", "iyi", "referans var mı?"))
    s.append(arrow(d_yan_konu.edge("bottom"), border_box.edge("top"), "evet"))
    s.append(example(border_box.cx, border_box.cy + 74, "Örnek — REQ-8.2 (border)",
                     "ana_konu = bg_yonetim_sistemi (başka belgenin işi) ama yan_konu = dokuman_yonetimi. Bu belge o konuyu beyan ettiyse: \"referans var mı?\" sorulur."))
    kapsam_disi = Box(d_yan_konu.cx + 260, main_y + 340, w=180, h=52)
    s.append(node(kapsam_disi, "KAPSAM DIŞI", "kotu", "bu belgeye hiç sorulmaz"))
    s.append(arrow(d_yan_konu.edge("right"), kapsam_disi.edge("top"), "hayır", curve=60))

    s.append(arrow(core_box.edge("top"), d_kosul_var.edge("bottom"), "", curve=40))
    s.append(arrow(border_box.edge("top"), d_kosul_var.edge("bottom"), "", curve=20))
    s.append(arrow(d_evrensel.edge("bottom"), d_kosul_var.edge("bottom"), "", curve=-10))

    s.append(arrow(d_kosul_var.edge("right"), d_kosul_cevapli.edge("left")))
    s.append(arrow(d_kosul_cevapli.edge("right"), d_kosul_true.edge("left")))
    s.append(arrow(d_kosul_true.edge("right"), devam1.edge("left"), "evet / koşulsuz"))

    kosul_y = main_y + 440
    uyari_box = Box(d_kosul_cevapli.cx, kosul_y, w=190, h=58)
    s.append(node(uyari_box, "\"cevapsız\" uyarısı", "kotu", "yine de değerlendirilir"))
    s.append(arrow(d_kosul_cevapli.edge("bottom"), uyari_box.edge("top"), "hayır"))
    s.append(arrow(uyari_box.edge("right"), devam1.edge("bottom"), "yine de devam", curve=90))

    atla_box = Box(d_kosul_true.cx, kosul_y, w=170, h=52)
    s.append(node(atla_box, "ATLA", "kotu", "bu gereksinim listeden çıkar"))
    s.append(arrow(d_kosul_true.edge("bottom"), atla_box.edge("top"), "hayır"))
    s.append(example(d_kosul_var.cx, kosul_y + 100, "Örnek — REQ-29.11 (koşullu)",
                     "kosul_kodu = BULUT_KULLANIMI. \"Banka bulut hizmeti kullanıyor mu?\" data/bank_profile.json'da cevapsızsa → uyarı + yine de sorulur; \"hayır\" ise → ATLA.", w=260))
    s.append(f'<text x="{(d_kosul_var.cx+d_kosul_cevapli.cx)/2:.0f}" y="{kosul_y-60:.0f}" text-anchor="middle" font-family="{FONT}" '
             f'font-size="11" fill="#5f6368" font-style="italic">Koşul kontrolü CORE/BORDER\'a giren her gereksinime AYRICA uygulanır</text>')

    return "".join(s), W1, p_y + p1_h


# ============================================================================
# LANE 1B — BAĞIMSIZ İKİNCİ KONTROL: BELGE → BSEB (Lane 1 ile PARALEL çalışır)
# ============================================================================
def _lane_reverse(p_y: float, panel_w: float | None = None, extra_top: float = 0) -> tuple[str, float, float]:
    s: list[str] = []
    main_y = p_y + 190

    giris = Box(col(0), main_y, w=100, h=56)
    rev = Box(col(1.3), main_y, w=240)
    d_aykiri = Diamond(col(2.9), main_y, hw=105)
    d_alinti = Diamond(col(4.3), main_y - 40, hw=100)
    bulgu_yok = Box(col(4.3), main_y + 170, w=180, h=52)
    celiskili = Box(col(5.7), main_y - 130, w=190, h=56)
    ihtiyat = Box(col(5.7), main_y + 60, w=190, h=56)
    ekle = Box(col(7.1), main_y - 40, w=210, h=56)
    bitis = Box(col(8.5), main_y, w=100, h=52)

    W = col(8.5) + 100 / 2 + MARGIN
    if panel_w is None:
        panel_w = W
    p_h = 620
    s.append(panel(MARGIN, p_y - extra_top, panel_w - MARGIN, p_h + extra_top,
                   "1B · Bağımsız ikinci kontrol — belge → BSEB",
                   "Lane 1'in konu sınıflandırmasından TAMAMEN bağımsız: check_translation'dan sonra PARALEL başlar, kendi END'ine gider, bulgular reverse_findings'e yazılır"))

    s.append(node(giris, "GİRİŞ", "giris", "check_translation'dan, paralel"))
    s.append(node(rev, "reverse_check", "llm", "belge TAM metni + 255 maddenin TAMAMI → TEK LLM çağrısı"))
    s.append(d_aykiri.svg("BSEB'e aykırı bir ifade var mı?"))
    s.append(d_alinti.svg("alıntı blokta birebir var mı?"))
    s.append(node(bulgu_yok, "bulgu yok", "iyi", "2. kontrol: temiz"))
    s.append(node(celiskili, "contradicted", "kotu", "find_quote doğruladı, güven 0.75"))
    s.append(node(ihtiyat, "needs_review", "kotu", "alıntı bulunamadı, güven 0.3"))
    s.append(node(ekle, "reverse_findings'e eklenir", "iyi", "recommend() aynı akışla öneri yazar"))
    s.append(node(bitis, "BİTİŞ", "giris"))

    s.append(arrow(giris.edge("right"), rev.edge("left")))
    s.append(arrow(rev.edge("right"), d_aykiri.edge("left")))
    s.append(arrow(d_aykiri.edge("bottom"), bulgu_yok.edge("left"), "hayır", curve=40))
    s.append(arrow(bulgu_yok.edge("right"), bitis.edge("bottom"), "", curve=60))
    s.append(arrow(d_aykiri.edge("right"), d_alinti.edge("left"), "evet", curve=-20))
    s.append(arrow(d_alinti.edge("top"), celiskili.edge("left"), "evet", curve=-30))
    s.append(arrow(d_alinti.edge("bottom"), ihtiyat.edge("left"), "hayır", curve=30))
    s.append(arrow(celiskili.edge("right"), ekle.edge("top"), "", curve=-30))
    s.append(arrow(ihtiyat.edge("right"), ekle.edge("bottom"), "", curve=30))
    s.append(arrow(ekle.edge("right"), bitis.edge("top"), "", curve=-20))

    s.append(example(rev.cx, main_y - 150, "Neden gerekli? — Lane 1'in kaçırdığını burada yakalar",
                     "Belge 'sınırsız_erisim' konusunu hiç beyan etmese bile: metin 'acil durumda uzaktan erişim onay beklemeden açılabilir' derse, bu ifade REQ-14.7'ye ('onay olmadan yapılmaz') doğrudan aykırıdır. Madde-bazlı kontrol bunu asla sormaz çünkü konu hiç seçilmemiştir.", w=280))
    s.append(example(d_aykiri.cx, main_y + 300, "Bilinen bedel",
                     "255 maddenin TAMAMI özetlenip TEK bir LLM çağrısına gömülür — konu ön-filtresi yok, bu yüzden Lane 1'e göre daha yavaş/pahalı bir çağrıdır; karşılığında konu sınıflandırma hatasına bağımlı değildir.", w=280))

    return "".join(s), W, p_y + p_h


# ============================================================================
# LANE 2 — BİR KURAL NASIL DEĞERLENDİRİLİR?
# ============================================================================
def _lane2(p_y: float, panel_w: float | None = None, extra_top: float = 0) -> tuple[str, float, float]:
    s: list[str] = []
    main2_y = p_y + 160

    girisA = Box(col(0), main2_y, w=76, h=52)
    d_risk = Diamond(col(1), main2_y, hw=95)
    llm_degerlendir = Box(col(2.4), main2_y, w=230)
    d_olumlu_kanit = Diamond(col(3.9), main2_y, hw=105)
    d_alinti = Diamond(col(5.1), main2_y, hw=100)
    d_olumsuz = Diamond(col(6.5), main2_y, hw=100)
    llm_itiraz = Box(col(7.9), main2_y, w=200)
    d_curutuldu = Diamond(col(9.1), main2_y, hw=95)
    d_pending = Diamond(col(10.4), main2_y, hw=100)
    final_rapor = Box(col(11.7), main2_y, w=170, h=52)

    W2 = col(11.7) + 170 / 2 + MARGIN
    if panel_w is None:
        panel_w = W2
    p2_h = 460
    s.append(panel(MARGIN, p_y - extra_top, panel_w - MARGIN, p2_h + extra_top,
                   "2 · Bir kural nasıl değerlendirilir?",
                   "her aday gereksinim, önceki lane'den 'DEĞERLENDİRMEYE GİRER' diyerek buraya gelir"))

    s.append(node(girisA, "GİRİŞ", "giris"))
    s.append(d_risk.svg("risk = Kritik/Yüksek mi?"))
    s.append(node(llm_degerlendir, "evaluate_core / evaluate_border", "llm", "hüküm + kanıt + eksik unsurlar"))
    s.append(d_olumlu_kanit.svg("hüküm olumlu VE kanıt var mı?"))
    s.append(d_alinti.svg("alıntı blokta birebir var mı?"))
    s.append(d_olumsuz.svg("hüküm olumsuz mu?"))
    s.append(node(llm_itiraz, "challenge", "llm", "modele kendi bulgusu çürütülür"))
    s.append(d_curutuldu.svg("çürütüldü mü?"))
    s.append(d_pending.svg("needs_review VEYA güven<0.6 mı?"))
    s.append(node(final_rapor, "SON RAPORA", "iyi"))

    s.append(arrow(girisA.edge("right"), d_risk.edge("left")))
    tek_ornek = Box(d_risk.cx, main2_y + 150, w=190, h=52)
    s.append(node(tek_ornek, "1x sor", "kod", "sıcaklık 0"))
    s.append(arrow(d_risk.edge("bottom"), tek_ornek.edge("top"), "hayır"))
    uc_ornek = Box(d_risk.cx, main2_y - 150, w=210, h=58)
    s.append(node(uc_ornek, "3x örnekle", "kod", "T=0.3, çoğunluk oyu kazanır"))
    s.append(arrow(d_risk.edge("top"), uc_ornek.edge("bottom"), "evet"))
    s.append(example(uc_ornek.cx, uc_ornek.cy - 78, "Örnek — REQ-14.7 (risk=Yüksek)",
                     "\"Uzaktan erişim BG sorumlusu onayı olmadan yapılmaz...\" Kritik/Yüksek risk → aynı soru 3 kez sorulur, 3'ü de aynı hükmü verirse güven tam, 2/3 ise düşürülür."))
    s.append(arrow(tek_ornek.edge("right"), llm_degerlendir.edge("left"), "", curve=40))
    s.append(arrow(uc_ornek.edge("right"), llm_degerlendir.edge("left"), "", curve=-40))

    s.append(arrow(llm_degerlendir.edge("right"), d_olumlu_kanit.edge("left")))
    s.append(arrow(d_olumlu_kanit.edge("right"), d_alinti.edge("left"), "evet"))
    needs_rev1 = Box(d_alinti.cx, main2_y + 150, w=200, h=58)
    s.append(node(needs_rev1, "needs_review'e düşür", "kotu", "güven ≤ 0.3, silinmez"))
    s.append(arrow(d_alinti.edge("bottom"), needs_rev1.edge("top"), "hayır"))
    s.append(arrow(d_olumlu_kanit.edge("bottom"), d_olumsuz.edge("bottom"), "hayır", curve=90))
    s.append(arrow(d_alinti.edge("right"), d_olumsuz.edge("left"), "evet — hüküm kalır", curve=-40))
    s.append(arrow(needs_rev1.edge("right"), d_olumsuz.edge("bottom"), "", curve=50))

    s.append(arrow(d_olumsuz.edge("right"), llm_itiraz.edge("left"), "evet"))
    s.append(arrow(llm_itiraz.edge("right"), d_curutuldu.edge("left")))
    s.append(arrow(d_curutuldu.edge("right"), d_pending.edge("left"), "evet → needs_review", curve=-30))
    hukum_kalir = Box(d_curutuldu.cx, main2_y + 150, w=180, h=52)
    s.append(node(hukum_kalir, "hüküm kalır", "iyi", "challenged=true"))
    s.append(arrow(d_curutuldu.edge("bottom"), hukum_kalir.edge("top"), "hayır"))
    s.append(arrow(hukum_kalir.edge("right"), d_pending.edge("bottom"), "", curve=50))
    s.append(arrow(d_olumsuz.edge("bottom"), d_pending.edge("top"), "hayır — doğrudan geç", curve=100))
    s.append(example(llm_itiraz.cx, main2_y - 150, "En etkili yanlış-pozitif filtresi",
                     "Sadece not_mentioned/contradicted/partial çürütülmeye çalışılır. Bir iş birimine haksız \"eksik\" demek, gerçek bir eksiği kaçırmaktan (insan yakalar) daha pahalıdır."))

    s.append(arrow(d_pending.edge("right"), final_rapor.edge("left"), "hayır"))
    pending_box = Box(d_pending.cx, main2_y + 150, w=190, h=52)
    s.append(node(pending_box, "pending_review", "kotu", "insan incelemesi"))
    s.append(arrow(d_pending.edge("bottom"), pending_box.edge("top"), "evet"))

    return "".join(s), W2, p_y + p2_h


# ============================================================================
# LANE 3 — TÜM BELGELER BİTTİKTEN SONRA (kapsam taraması, kanıt ajanı)
# ============================================================================
def _lane3(p_y: float, panel_w: float | None = None, extra_top: float = 0) -> tuple[str, float, float]:
    s: list[str] = []
    main3_y = p_y + 130

    girisB = Box(col(0), main3_y, w=76, h=52)
    incele = Box(col(1), main3_y, w=220)
    tersTara = Box(col(2.2), main3_y, w=220)
    d_yetim = Diamond(col(3.5), main3_y, hw=100)
    sorgu = Box(col(4.9), main3_y - 90, w=190)
    ara = Box(col(6.1), main3_y - 90, w=190)
    d_bulundu = Diamond(col(7.4), main3_y - 90, hw=95)
    d_tur = Diamond(col(7.4), main3_y - 220, hw=95)
    oner = Box(col(8.8), main3_y, w=200)
    rapor = Box(col(10.0), main3_y, w=190)
    bitisB = Box(col(11.1), main3_y, w=76, h=52)

    W3 = col(11.1) + 76 / 2 + MARGIN
    if panel_w is None:
        panel_w = W3
    p3_h = 400
    s.append(panel(MARGIN, p_y - extra_top, panel_w - MARGIN, p3_h + extra_top,
                   "3 · Kapsam taraması (korpus grafı)",
                   "'lane 1+2' HER belge için bitince, bir kez çalışır — hiçbir belgede karşılanmayan var mı?"))

    s.append(node(girisB, "BAŞLA", "giris"))
    s.append(node(incele, "review_documents", "kod", "her dosya için 1+2. lane"))
    s.append(node(tersTara, "reverse_scan", "kod", "core/universal'da satisfied var mı?"))
    s.append(d_yetim.svg("yetim gereksinim var mı?"))
    s.append(node(sorgu, "sorgu üret", "agent", "model karar verir"))
    s.append(node(ara, "BM25 ara", "kod", "korpus genelinde"))
    s.append(d_bulundu.svg("kanıt bulundu mu?"))
    s.append(d_tur.svg("4. tura ulaşıldı mı?"))
    s.append(node(oner, "recommend", "llm", "düzeltme metni yazar"))
    s.append(node(rapor, "render_report", "kod", "findings JSON"))
    s.append(node(bitisB, "BİTİŞ", "giris"))

    for a, b in [(girisB, incele), (incele, tersTara)]:
        s.append(arrow(a.edge("right"), b.edge("left")))
    s.append(arrow(tersTara.edge("right"), d_yetim.edge("left")))
    s.append(arrow(d_yetim.edge("top"), sorgu.edge("left"), "evet", curve=-20))
    s.append(arrow(sorgu.edge("right"), ara.edge("left")))
    s.append(arrow(ara.edge("right"), d_bulundu.edge("left")))
    kapsanmis = Box(d_bulundu.cx + 170, main3_y - 90, w=170, h=48)
    s.append(node(kapsanmis, "kapsanmış işaretle", "iyi"))
    s.append(arrow(d_bulundu.edge("right"), kapsanmis.edge("left"), "evet"))
    s.append(arrow(d_bulundu.edge("top"), d_tur.edge("bottom"), "hayır"))
    s.append(arrow(d_tur.edge("left"), sorgu.edge("top"), "hayır — yeniden sorgula", curve=-60))
    gercek_bosluk = Box(d_tur.cx, main3_y - 320, w=190, h=52)
    s.append(node(gercek_bosluk, "gerçek boşluk", "kotu", "missing_document_types"))
    s.append(arrow(d_tur.edge("top"), gercek_bosluk.edge("bottom"), "evet — 4 tur doldu"))
    s.append(example(sorgu.cx, main3_y - 190, "Kanıt ajanı — projedeki TEK otonom bileşen",
                     "Çıktısı bir yargı değil, doğrulanabilir olgu: \"X belgesinde bulundu\" ya da \"arandı, yok\". Bu yüzden döngü/durma kararını modele bırakmak güvenli."))
    s.append(arrow(d_yetim.edge("right"), oner.edge("left"), "hayır — direkt geç", curve=30))
    s.append(arrow(kapsanmis.edge("bottom"), oner.edge("top"), "", curve=40))
    s.append(arrow(gercek_bosluk.edge("right"), oner.edge("top"), "", curve=-90))
    s.append(arrow(oner.edge("right"), rapor.edge("left")))
    s.append(arrow(rapor.edge("right"), bitisB.edge("left")))

    return "".join(s), W3, p_y + p3_h


# ============================================================================
# Birleşik (tam ayrıntı, referans) diyagram
# ============================================================================
def build_svg() -> str:
    p1_y = 90
    lane1_svg, W1, p1_bottom = _lane1(p1_y)
    prev_y = p1_bottom + 30
    lane1b_svg, _W1b, prev_bottom = _lane_reverse(prev_y, W1, extra_top=200)
    p2_y = prev_bottom + 30
    lane2_svg, _W2, p2_bottom = _lane2(p2_y, W1)
    p3_y = p2_bottom + 30
    lane3_svg, _W3, p3_bottom = _lane3(p3_y, W1)

    notes_y = p3_bottom + 26
    note_text = ("Model hiçbir zaman 'hangi maddeye bakayım' diye seçim yapmaz — bu seçim (1. lane) tamamen "
                "kod/tablo sorgusuyla olur. Model sadece 'seçilen bu maddeyi karşılıyor mu?' (2. lane) sorusuna "
                "yapılandırılmış biçimde cevap verir, ve her cevabı ayrıca (alıntı doğrulama + itiraz ile) sınanır. "
                "Lane 1B bunun TAMAMEN dışında, paralel ve bağımsız ikinci bir denetimdir: belgenin tam metnini "
                "konu ayrımı yapmadan 255 maddenin tamamına karşı tarar.")
    notes_svg, notes_bottom = _notes_panel(MARGIN, notes_y, W1 - 2 * MARGIN, "Bir cümlede tasarım",
                                          note_text, 160)
    ly = notes_bottom + 32
    H = ly + 24

    body = lane1_svg + lane1b_svg + lane2_svg + lane3_svg + notes_svg + _legend(MARGIN, ly)
    return _svg_wrap(W1, H, "BSEB Uygunluk Taraması — Karar Mantığı",
                     "Her karar kutusu (◇), kodun gerçekten sorduğu bir soru; her sarı not, register'dan gerçek bir satır.",
                     body)


# ============================================================================
# Sunuma uygun, tek başına slayta sığan AYRI diyagramlar
# ============================================================================
def build_stage_svg(n: int) -> str:
    # Lane 2/3'te bazı sarı notlar main_y'nin ÜSTÜNDE konumlanır (main_y-150
    # gibi); birleşik diyagramda üstlerinde önceki lane'in yüksekliği kadar
    # boşluk vardır, ama tek başına (p_y=90) bu boşluk yetmez, not tuvalin
    # üst kenarından taşar. Bağımsız dosyalarda bu yüzden daha fazla üst
    # boşluk bırakılır.
    # Lane 2/3'te bazı sarı notlar main_y'nin ÜSTÜNDE konumlanır (main_y-320
    # kadar yükseğe çıkan da var); birleşik diyagramda üstlerinde önceki
    # lane'in yüksekliği kadar boşluk vardır, ama tek başına bu boşluk
    # yoktur — hem p_y hem panelin kendi üst kenarı (extra_top ile) buna
    # göre ayrı ayrı hesaplanır ki not ne tuvalin üstünden taşsın ne de
    # panel çerçevesini yırtıp geçsin.
    if n == 1:
        p_y = 90
        lane_svg, w, bottom = _lane1(p_y)
        title = "Aşama 1 · Hangi kural bu belgeye sorulur?"
        subtitle = "Konu eşleşmesi, halka ataması (evrensel/ana konu/sınır) ve koşullu maddeler — model karışmaz, tablo sorgusudur."
        note = ("register.py::candidates() 255 kuralın HER BİRİNİ, belgenin beyan ettiği konu listesiyle "
                "karşılaştırır. Bir kuralın modele sorulup sorulmayacağı — ve nasıl bir soru olarak sorulacağı "
                "(core mu, border mı) — tamamen bu tablo eşleşmesiyle belirlenir.")
    elif n == 2:
        p_y = 280
        lane_svg, w, bottom = _lane_reverse(p_y, extra_top=190)
        title = "Aşama 1B · Bağımsız ikinci kontrol — belge → BSEB"
        subtitle = "Aşama 1'in konu sınıflandırmasından TAMAMEN bağımsız, paralel bir tarama — hiçbir konu ön-filtresi yok."
        note = ("check_translation'dan sonra Aşama 1 ile AYNI ANDA başlar; belgenin tam metnini 255 maddenin "
                "TAMAMIYLA tek bir LLM çağrısında karşılaştırır. Bulduğu her aykırılık önce find_quote ile "
                "belgede birebir doğrulanır — doğrulanamayan alıntı silinmez, needs_review'e düşer. Aşama 1'in "
                "'bu belge hangi konuları beyan etti' filtresinden geçmeyen, dolayısıyla hiç sorulmayacak bir "
                "maddeye aykırı bir cümleyi yakalayan TEK katman budur.")
    elif n == 3:
        p_y = 260
        lane_svg, w, bottom = _lane2(p_y, extra_top=170)
        title = "Aşama 2 · Bir kural nasıl değerlendirilir?"
        subtitle = "LLM yargısı, öz-tutarlılık oylaması, atıf doğrulama ve itiraz — dört bağımsız kontrol katmanı."
        note = ("Yüksek riskli maddeler aynı soruyla 3 kez sorulur (öz-tutarlılık oylaması); her olumlu/olumsuz "
                "hüküm, alıntının belgede birebir var olup olmadığıyla doğrulanır; olumsuz/kısmi her hüküm, "
                "modelin kendi bulgusunu çürütmeye çalıştığı ayrı bir turdan geçer.")
    else:
        p_y = 340
        lane_svg, w, bottom = _lane3(p_y, extra_top=250)
        title = "Aşama 3 · Korpus taraması (tüm belgeler bittikten sonra)"
        subtitle = "Kapsam boşluğu tespiti ve projedeki TEK otonom bileşen: kanıt arama ajanı."
        note = ("Bir gereksinim hiçbir belgede 'satisfied' çıkmadıysa, önce gerçekten bir boşluk mu yoksa "
                "başka bir belgede mi karşılanıyor diye otonom bir arama ajanı (evidence_agent) devreye girer — "
                "kendi sorgusunu yazar, sonucu değerlendirir, en fazla 4 tur döner. Çıktısı bir yargı değil, "
                "doğrulanabilir bir olgudur, bu yüzden döngü kararını modele bırakmak güvenlidir.")

    notes_svg, notes_bottom = _notes_panel(MARGIN, bottom + 26, w - 2 * MARGIN, "Bu aşamada olan biten", note, 150)
    ly = notes_bottom + 32
    H = ly + 24
    return _svg_wrap(w, H, title, subtitle, lane_svg + notes_svg + _legend(MARGIN, ly))


def write(out_dir: str = ".") -> Path:
    out = Path(out_dir) / "workflow_graph.svg"
    out.write_text(build_svg(), encoding="utf-8")
    return out


STAGE_FILENAMES = {
    1: "asama_1_kural_secimi",
    2: "asama_1b_ikinci_kontrol",
    3: "asama_2_degerlendirme",
    4: "asama_3_korpus_taramasi",
}


def write_stages(out_dir: str = ".") -> list[Path]:
    out_paths = []
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    for n, name in STAGE_FILENAMES.items():
        out = Path(out_dir) / f"{name}.svg"
        out.write_text(build_stage_svg(n), encoding="utf-8")
        out_paths.append(out)
    return out_paths


if __name__ == "__main__":
    print(write())
    for p in write_stages("docs/asamalar"):
        print(p)
