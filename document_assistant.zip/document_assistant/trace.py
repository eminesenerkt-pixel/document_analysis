# -*- coding: utf-8 -*-
"""`trace` — show exactly what happens to one document, step by step.

This runs the real code paths, not a description of them. Every LLM call is
printed in full: the system prompt, the document prefix, the requirement
suffix, and the JSON that comes back. Without an endpoint it uses a stub so
the shape of every step is still visible.

    python -m compliance_workflow.main trace --document documents/DOC-02....docx
    python -m compliance_workflow.main trace --document ... --req REQ-11.6
"""
from __future__ import annotations
import json
import textwrap

from .config import Config
from .registry import Registry, load_registry
from .state import DocumentState

RULE = "=" * 78
THIN = "-" * 78


def _h(title: str) -> None:
    print(f"\n{RULE}\n{title}\n{RULE}")


def _box(label: str, body: str, limit: int = 1400) -> None:
    print(f"\n{THIN}\n{label}\n{THIN}")
    body = body if len(body) <= limit else body[:limit] + f"\n... [{len(body)} chars total]"
    print(textwrap.indent(body, "  "))


class _Stub:
    """Deterministic stand-in so the trace runs without an endpoint."""
    def __init__(self, *_a, **_k):
        self.stub = True

    def complete_json(self, system, prefix, suffix, schema, temperature=0.0):
        props = schema.get("properties", {})
        if "topics" in props:
            return {"topics": [], "title_matches_scope": True, "conflict_note": ""}
        if "add" in props:
            return {"add": []}
        if "refuted" in props:
            return {"refuted": False, "counter_evidence": "",
                    "reason": "(stub) no endpoint configured"}
        if "recommendation" in props:
            return {"finding_statement": "(stub)", "risk": "(stub)",
                    "recommendation": "(stub)", "severity": "medium"}
        return {k: "" for k in props}

    def complete_json_voted(self, system, prefix, suffix, schema,
                            vote_key="verdict", samples=1):
        enum = schema["properties"]["verdict"].get("enum", ["not_mentioned"])
        return {"verdict": enum[-3] if len(enum) > 3 else enum[0],
                "evidence": [], "missing_elements": [],
                "referenced_document": "", "rationale": "(stub) no endpoint configured",
                "confidence": 0.0}, samples


def run(cfg: Config, document: str, only_req: str = "", topics: str = "") -> int:
    from .llm import LLMClient
    from .nodes import evaluate as ev
    from .nodes import ingest as ing
    from .nodes import metadata_rules as mr
    from .nodes import profile as pf

    registry = load_registry(cfg.paths.register_xlsx,
                             cfg.paths.register_sheet, cfg.paths.topics_sheet)

    # Use the real client when an endpoint answers; fall back to the stub.
    client = LLMClient(cfg.llm)
    try:
        import httpx
        httpx.get(cfg.llm.base_url.rstrip("/") + "/models", timeout=5,
                 headers=cfg.llm.headers, verify=cfg.llm.verify)
        live = True
    except Exception:                                           # noqa: BLE001
        client, live = _Stub(), False

    print(f"\nendpoint : {cfg.llm.base_url} "
          f"({'live — real model answers below' if live else 'unreachable — STUB answers below'})")
    print(f"register : {cfg.paths.register_xlsx}")
    print(f"document : {document}")

    # ---------------------------------------------------------- 0  the list
    _h("0  THE BSEB LIST — what the whole run is driven by")
    print(f"\n{len(registry.requirements)} atomic requirements, "
          f"{len(registry.topics)} topic codes, "
          f"{len(registry.universal)} universal.\n")
    print(f"{'REQ':<12}{'m.':<7}{'risk':<9}{'ana_konu':<34}requirement")
    print(THIN)
    for r in registry.requirements[:6]:
        print(f"{r['req_id']:<12}{r['article']:<7}{r['risk_level']:<9}"
              f"{r['primary_topic']:<34}{r['text'][:70]}")
    print(f"{'...':<12}({len(registry.requirements) - 6} more rows)")

    _box("one row in full — this is what the model is asked about, one at a time",
         "\n".join(f"{k:<18}{v}" for k, v in registry.requirements[10].items()))

    # ---------------------------------------------------------- 1  ingest
    _h("1  INGEST — Word file to blocks (code, no model)")
    state: DocumentState = ing.ingest({"path": document, "findings": [],
                                       "pending_review": []}, cfg=cfg)
    if state.get("error"):
        print("FAILED:", state["error"])
        return 1
    print(f"\n{len(state['blocks'])} blocks, {len(state['markdown'])} chars of markdown")
    print(f"\n{'block id':<12}{'type':<12}{'source':<10}text")
    print(THIN)
    for b in state["blocks"][:8]:
        print(f"{b['id']:<12}{b['type']:<12}{b['source']:<10}{b['text'][:52]}")

    # ---------------------------------------------------------- 2  profile
    _h("2  PROFILE — metadata by rules, topics by model")
    state.update(pf.profile_document(state, client=client, registry=registry, cfg=cfg))
    p = state["profile"]
    for k in ("title", "document_class", "document_code", "version",
              "effective_date", "owner", "approver", "confidentiality", "languages"):
        print(f"  {k:<18}{p[k] or '—'}")

    print(f"\n  The topic catalogue is CLOSED — {len(registry.topics)} codes, "
          "the model may not invent one:")
    for t in registry.topics[:5]:
        print(f"    {t.code:<36}{t.definition[:44]}")
    print(f"    ... ({len(registry.topics) - 5} more)")

    if topics:
        picked = [t.strip() for t in topics.split(",") if t.strip() in registry.topic_codes]
        state["profile"]["declared_topics"] = picked
        state["profile"]["topic_rationale"] = {c: "(given on the command line)" for c in picked}
        state["profile"]["title_scope_conflict"] = False
        state["profile"]["conflict_note"] = ""
        print(f"\n  topics forced from --topics: {', '.join(picked)}")
    else:
        print("\n  CALL 1 -> select_topics")
        _box("system prompt", pf.TOPIC_SYSTEM)
        _box("user: catalogue + the document's purpose/scope/headings",
             "TOPIC CATALOGUE (choose only from these codes)\n"
             + registry.topic_catalogue()[:300] + "\n  ...\n\nDOCUMENT\n"
             f"Title: {p['title']}\n"
             f"Headings: {' | '.join(p.get('_headings', []))[:200]}\n"
             "Opening sections: " + " ".join(p.get("_lead", []))[:400])
        state.update(pf.select_topics(state, client=client, registry=registry, cfg=cfg))
        state.update(pf.recall_guard(state, client=client, registry=registry, cfg=cfg))
        print("  answer  ->", state["profile"]["declared_topics"] or "[] (stub)")

    declared = state["profile"]["declared_topics"]

    # ------------------------------------------------- 3  the universal ring
    _h("3  UNIVERSAL RING — m.5 document control, decided by RULES (no model)")
    state.update(mr.check_metadata(state, cfg=cfg))
    print(f"\n{'REQ':<12}{'verdict':<16}{'conf':<7}why")
    print(THIN)
    for f in state["findings"]:
        print(f"{f['req_id']:<12}{f['verdict']:<16}{f['confidence']:<7.2f}{f['rationale'][:44]}")
    print("\n  These five are formal facts — is there a document code, was it approved")
    print("  at board level, is the yearly review unconditional. A model would add")
    print("  cost and a hallucination surface for no gain.")

    # ------------------------------------------------ 4  WHICH and HOW DEEP
    _h("4  SCOPING — which of the 255, in which ring, at what depth")
    if not declared:
        print("\n  No topics declared (stub run). Re-run with --topics to see the fan-out,")
        print("  e.g.  --topics uzaktan_erisim,kimlik_dogrulama_yetkilendirme")
        return 0

    state.update(pf.expand_requirements(state, registry=registry, cfg=cfg))
    cands = state["candidates"]
    rings = {"universal": 0, "core": 0, "border": 0}
    for c in cands:
        rings[c["ring"]] += 1
    skipped = len(registry.requirements) - len(cands)
    print(f"\n  declared topics : {', '.join(declared)}")
    print(f"  255 requirements -> {len(cands)} candidates "
          f"(core {rings['core']}, border {rings['border']}, universal {rings['universal']}; "
          f"{skipped} out of scope)")
    print("\n  Selection is a TABLE LOOKUP, not a search. The rule, in one line each:")
    print("    universal  evrensel == EVET                   -> every document")
    print("    core       ana_konu  in declared topics       -> 'is it met here?'")
    print("    border     yan_konu  hits a declared topic    -> 'is there a reference?'")

    decided = {f["req_id"] for f in state["findings"]}
    sends = ev.fan_out(state, registry=registry, cfg=cfg)
    print(f"\n  THE LOOP: fan_out() returns {len(sends)} LangGraph Send() objects — "
          "one branch,")
    print("  one model call, per requirement. That is the loop; LangGraph runs the")
    print("  branches and merges the findings back through an operator.add reducer.")

    print(f"\n{'REQ':<12}{'ring':<10}{'risk':<9}{'samples':<9}control question")
    print(THIN)
    shown = 0
    for c in cands:
        if c["req_id"] in decided:
            continue
        r = registry.by_id[c["req_id"]]
        n = (cfg.llm.samples_high_risk if r["risk_level"] in cfg.policy.high_risk_levels
             else cfg.llm.samples_default)
        print(f"{r['req_id']:<12}{c['ring']:<10}{r['risk_level']:<9}{n:<9}"
              f"{r['control_question'][:40]}")
        shown += 1
        if shown >= 12:
            print(f"{'...':<12}({len(sends) - 12} more branches)")
            break
    print("\n  'ne derece bakılacak' = the samples column. Kritik/Yüksek requirements")
    print(f"  are answered {cfg.llm.samples_high_risk}x at temperature "
          f"{cfg.llm.self_consistency_temperature} and the majority verdict wins;")
    print("  partial agreement caps the confidence. Everything else is answered once")
    print("  at temperature 0.")

    # ------------------------------------------------------ 5  one real call
    target = None
    for c in cands:
        if c["req_id"] in decided:
            continue
        if not only_req or c["req_id"] == only_req:
            target = c
            break
    if target is None:
        print(f"\n{only_req} is not a candidate for this document.")
        return 0

    req = registry.by_id[target["req_id"]]
    _h(f"5  ONE CONTROL IN FULL — {req['req_id']} ({target['ring']} ring)")

    system = ev.CORE_SYSTEM if target["ring"] != "border" else ev.BORDER_SYSTEM
    schema = ev.CORE_SCHEMA if target["ring"] != "border" else ev.BORDER_SCHEMA
    _box("system prompt — the verdict vocabulary and the evidence rule", system)
    _box("user, part 1: THE DOCUMENT (placed first so the server's prefix cache "
         "covers it across every requirement call)",
         "DOCUMENT\n--------\n" + state["markdown"], limit=900)
    _box("user, part 2: THE REQUIREMENT (the only part that changes per call)",
         ev._requirement_block(req, target["ring"]))

    n = (cfg.llm.samples_high_risk if req["risk_level"] in cfg.policy.high_risk_levels
         else cfg.llm.samples_default)
    task = {"document_id": state["document_id"], "markdown": state["markdown"],
            "blocks": state["blocks"], "requirement": req,
            "ring": target["ring"], "samples": n}
    node = ev.evaluate_border if target["ring"] == "border" else ev.evaluate_core
    result = node(task, client=client, cfg=cfg)
    finding = result["findings"][0]
    _box(f"model answer (schema-constrained, {n} sample(s), "
         f"{finding['samples_agreed']} agreed)",
         json.dumps(finding, ensure_ascii=False, indent=2))

    # ------------------------------------------------------- 6  verification
    _h("6  VERIFICATION — the control on the control")
    before = dict(finding)
    state["findings"] = [finding]
    state.update(ev.verify_citations(state, cfg=cfg))
    after = state["findings"][0]
    print("\n  Every quote is matched VERBATIM against the block it claims to come")
    print("  from. Three distinct failures: unknown block id / quote belongs to a")
    print("  different block / quote not found at all.")
    for e in after["evidence"] or [{"block_id": "—", "quote": "(none returned)",
                                    "verified": None, "reason": "—"}]:
        print(f"\n    block   {e['block_id']}")
        print(f"    quote   {str(e['quote'])[:60]}")
        print(f"    result  {'VERIFIED' if e.get('verified') else 'REJECTED — ' + str(e.get('reason'))}")
    if after["verdict"] != before["verdict"]:
        print(f"\n  verdict downgraded: {before['verdict']} -> {after['verdict']}")
    else:
        print(f"\n  verdict stands: {after['verdict']}")

    # --------------------------------------------------------- 7  challenge
    _h("7  CHALLENGE — a second model call that argues AGAINST the finding")
    if after["verdict"] in ("not_mentioned", "contradicted", "partial"):
        _box("system prompt", ev.CHALLENGE_SYSTEM)
        state.update(ev.challenge(state, client=client, registry=registry, cfg=cfg))
        ch = state["findings"][0]
        print(f"\n  refuted : {'yes -> downgraded to needs_review' if ch['challenged'] and ch['verdict'] == 'needs_review' else 'no -> the finding stands'}")
        print(f"  verdict : {ch['verdict']}  (confidence {ch['confidence']:.2f})")
    else:
        print("\n  Skipped — only negative verdicts are challenged. A false finding sent")
        print("  to a business unit costs more than a missed one, which a reviewer catches.")

    # ----------------------------------------------------- 8  recommendation
    _h("8  RECOMMENDATION — how the remediation text is written")
    from .nodes import corpus as cn
    _box("system prompt — the constraints that keep it inside BSEB", cn.RECOMMEND_SYSTEM)
    f = state["findings"][0]
    _box("user — the finding, plus the regulation wording it must stay inside",
         f"FINDING\n-------\n"
         f"document: {state['document_id']}\n"
         f"requirement: {req['text']}\n"
         f"regulation wording: {req['source_sentence']}\n"
         f"obligation form: {req['obligation_form']}\n"
         f"risk level in register: {req['risk_level']}\n"
         f"verdict: {f['verdict']}\n"
         f"missing elements: {', '.join(f['missing_elements']) or '—'}\n"
         f"topic family: {cn._family(req['primary_topic'])}")
    print("\n  Note the second constraint in the system prompt: where BSEB delegates")
    print("  ('the bank shall define X'), the recommendation says X must be defined,")
    print("  who defines it and how often it is reviewed — never what X should be.")
    print("  That is the line between a compliance finding and a consultant's opinion.")

    # ------------------------------------------------------------- 9  corpus
    _h("9  AFTER EVERY DOCUMENT — the reverse scan")
    print("\n  The per-document pass answers 'is this document compliant?'.")
    print("  reverse_scan answers the question the regulator actually asks:")
    print("  'is every one of the 255 covered SOMEWHERE?'")
    print("\n  Requirements nobody covered go to the evidence agent — the one place")
    print("  with a real loop of its own: it searches the corpus (BM25), reformulates,")
    print(f"  and decides when to stop, up to {cfg.policy.evidence_search_rounds} rounds.")
    print("  Whatever survives that is a genuine gap: a missing document.")
    print("\n  Output: output/report/findings_<run_id>.json")
    return 0
