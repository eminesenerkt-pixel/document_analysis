# -*- coding: utf-8 -*-
"""Requirement registry.

The register is the backbone of the system: 255 atomic requirements, each with
its own topic, obligation form, control question and risk level. Candidate
selection is a table lookup against it, never a similarity search — a
compliance review must be able to answer "why was this article checked?" with
a rule, not an embedding distance.
"""
from __future__ import annotations
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import openpyxl

from .state import Candidate, Requirement, Ring

_FORM_MAP = {
    "eylem": "action",
    "delegasyon": "delegation",
    "yasak": "prohibition",
    "yetki": "authority",
    "kosullu_eylem": "conditional",
}


@dataclass
class Topic:
    code: str
    theme: str
    definition: str
    articles: str


class Registry:
    def __init__(self, requirements: list[Requirement], topics: list[Topic]):
        self.requirements = requirements
        self.by_id = {r["req_id"]: r for r in requirements}
        self.topics = topics
        self.topic_codes = {t.code for t in topics}
        self.universal = [r for r in requirements if r["universal"]]

    # ------------------------------------------------------------ selection
    def candidates(self, declared_topics: list[str]) -> list[Candidate]:
        """Ring assignment.

        universal : applies to every document, never selected by the model
        core      : the requirement's home topic is one this document declares
        border    : the requirement only touches a declared topic — the
                    question becomes "is there a valid reference?"
        """
        declared = set(declared_topics) & self.topic_codes
        out: list[Candidate] = []
        for r in self.requirements:
            if r["universal"]:
                out.append({"req_id": r["req_id"], "ring": "universal"})
            elif r["primary_topic"] in declared:
                out.append({"req_id": r["req_id"], "ring": "core"})
            elif set(r["secondary_topics"]) & declared:
                out.append({"req_id": r["req_id"], "ring": "border"})
        return out

    def applies(self, req: Requirement, condition_flags: dict[str, bool]) -> bool | None:
        """Conditional requirements need a bank-profile answer.
        None means unknown -> route to human review rather than guess."""
        code = req["condition_code"]
        if not code:
            return True
        return condition_flags.get(code)

    def topic_catalogue(self) -> str:
        """The closed list handed to the topic-selection node."""
        return "\n".join(f"{t.code}\n    {t.definition}" for t in self.topics)


# --------------------------------------------------------------------- load
@lru_cache(maxsize=4)
def load_registry(xlsx_path: str,
                  register_sheet: str = "Register",
                  topics_sheet: str = "Konu Sözlüğü") -> Registry:
    wb = openpyxl.load_workbook(Path(xlsx_path), data_only=True, read_only=True)

    rows = list(wb[register_sheet].iter_rows(values_only=True))
    head = {name: i for i, name in enumerate(rows[0])}

    def cell(row, name, default=""):
        i = head.get(name)
        return (row[i] if i is not None and row[i] is not None else default)

    requirements: list[Requirement] = []
    for row in rows[1:]:
        if not row or not row[0]:
            continue
        secondary = [s.strip() for s in str(cell(row, "yan_konu")).split("|") if s.strip()]
        sub = [s.strip() for s in str(cell(row, "alt_unsurlar")).split("|") if s.strip()]
        requirements.append({
            "req_id":           str(row[0]),
            "article":          str(cell(row, "Madde")),
            "text":             str(cell(row, "Gereksinim")),
            "source_sentence":  str(cell(row, "Ham metin (dayanak cümle)")),
            "control_question": str(cell(row, "kontrol_sorusu")),
            "primary_topic":    str(cell(row, "ana_konu")),
            "secondary_topics": secondary,
            "obligation_form":  _FORM_MAP.get(str(cell(row, "yukumluluk_sekli")), "action"),
            "condition_code":   str(cell(row, "kosul_kodu")),
            "universal":        str(cell(row, "evrensel")).upper() == "EVET",
            "risk_level":       str(cell(row, "Risk seviyesi")),
            "sub_elements":     sub,
        })

    topics: list[Topic] = []
    if topics_sheet in wb.sheetnames:
        trows = list(wb[topics_sheet].iter_rows(values_only=True))
        for t in trows[1:]:
            if t and t[0]:
                topics.append(Topic(str(t[0]), str(t[1] or ""),
                                    str(t[2] or ""), str(t[3] or "")))
    wb.close()
    return Registry(requirements, topics)
