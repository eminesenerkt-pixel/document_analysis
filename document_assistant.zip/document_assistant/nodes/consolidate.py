# -*- coding: utf-8 -*-
"""Node: consolidate — gereksinim bazlı bulguları, belge BÖLÜMÜ bazlı tek
bir değişiklik talebine birleştirir.

Değerlendirme gereksinim gereksinim kalır (bkz. nodes/evaluate.py): "şu
madde neden uygun değil?" sorusuna madde bazında cevap verebilmek ancak
böyle mümkün. Ama okuyana gösterilen hâli bu olmamalı — aynı paragraf beş
gereksinimin kanıtıysa beş kartta beş kez görünüyor, birbirinden habersiz
yazılan beş öneri de aynı cümleyle başlıyordu.

Burada:
  1. Her olumsuz bulgu, kanıt paragrafının bağlı olduğu belge bölümüne
     (en yakın başlığa) bağlanır. Kanıtı olmayan "Belirtilmemiş"ler konu
     başına "belgede yer almayan" gruplarına, künye kurallarının bulguları
     tek bir künye grubuna gider.
  2. 2. Kontrol'ün bulduğu bir aykırılık 1. Kontrol'de aynı madde için
     zaten varsa ayrıca yazılmaz; o bulgu "iki kontrol de buldu" olarak
     işaretlenir.
  3. Grup başına TEK model çağrısı: iç özet + ekibe gidecek değişiklik
     maddeleri + bölüme yapıştırılabilecek önerilen metin.
  4. Kod kontrolü: gruptaki her bulgu en az bir değişiklik maddesinde
     karşılık bulmalı; bulmayan "kapsanmadı" olarak ayrıca listelenir —
     birleştirme sırasında hiçbir madde sessizce kaybolmaz.

Öncelik modelden alınmaz: gruptaki maddelerin register'daki risk
seviyesinin en yükseğidir — aynı girdi her koşuda aynı önceliği verir.
"""
from __future__ import annotations
import re

from ..config import Config
from ..llm import LLMClient
from ..registry import Registry
from ..state import CorpusState
from ..verify import tr_lower

NEGATIVE = ("not_mentioned", "contradicted", "partial")

RISK_TO_SEVERITY = {"kritik": "critical", "yüksek": "high", "orta": "medium", "düşük": "low"}
SEVERITY_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3}

METADATA_TITLE = "Belge künyesi ve doküman kontrol bilgileri"

# Ekibe giden metinde düzenleme/iç kod izi kalmamalı.
_LEAK = re.compile(r"\bbseb\b|yönetmeli[kğ]|bankaların bilgi sistemleri|\breq-[\w.]+", re.I)
_REQ_ID = re.compile(r"\(?\s*\bREQ-[\w.]+\s*\)?", re.I)

SECTION_TEXT_LIMIT = 5000


# ------------------------------------------------------------------ bölümler
def build_sections(blocks: list[dict]) -> list[dict]:
    """Gövde bloklarını başlıklara göre bölümlere ayırır. İlk başlıktan
    önceki her şey (başlık, künye tablosu) "Belge girişi ve künye" olur.
    Üst/alt bilgi alınmaz — kanıt olarak da kabul edilmiyorlar."""
    sections: list[dict] = []
    current = {"title": "Belge girişi ve künye", "block_ids": [], "parts": []}

    def close():
        if current["block_ids"]:
            sections.append({"id": f"s{len(sections):02d}", "title": current["title"],
                             "block_ids": current["block_ids"],
                             "text": "\n\n".join(current["parts"])})

    for b in blocks:
        if b.get("source") in ("header", "footer"):
            continue
        if b["type"] == "heading":
            close()
            current = {"title": b["text"], "block_ids": [b["id"]], "parts": [f"## {b['text']}"]}
            continue
        current["block_ids"].append(b["id"])
        current["parts"].append(b["text"])
    close()
    return sections


# ------------------------------------------------------------------- gruplama
def _item(f: dict, ref: str, index: int, registry: Registry) -> dict:
    req = registry.by_id.get(f["req_id"], {})
    quote = next((e["quote"] for e in f.get("evidence", [])
                  if e.get("quote") and e.get("block_id") != "metadata"), "")
    return {
        "ref": ref, "index": index,                 # doc[ref][index] -> asıl bulgu
        "req_id": f["req_id"],
        "article": req.get("article", ""),
        "requirement_text": req.get("text", ""),
        "risk_level": req.get("risk_level", ""),
        "primary_topic": req.get("primary_topic", ""),
        "verdict": f["verdict"],
        "missing_elements": f.get("missing_elements", []),
        "rationale": f.get("rationale", ""),
        "quote": quote,
        "both_checks": False,
    }


def _anchor(f: dict, block_to_section: dict[str, str]) -> str | None:
    for e in f.get("evidence", []):
        if e.get("block_id") == "metadata":
            return "metadata"
    for verified_first in (True, False):
        for e in f.get("evidence", []):
            if bool(e.get("verified")) == verified_first and e.get("block_id") in block_to_section:
                return block_to_section[e["block_id"]]
    return None


def group_findings(doc: dict, registry: Registry) -> tuple[list[dict], list[dict]]:
    """(değişiklik grupları, insan incelemesi bekleyenler). Model çağrısı yok."""
    sections = doc.get("sections", [])
    block_to_section = {bid: s["id"] for s in sections for bid in s["block_ids"]}
    section_by_id = {s["id"]: s for s in sections}
    theme = {t.code: (t.theme or t.code) for t in registry.topics}

    groups: dict[str, dict] = {}
    review: list[dict] = []

    def add(key: str, kind: str, title: str, item: dict, section_id: str = ""):
        g = groups.setdefault(key, {"id": key, "kind": kind, "title": title,
                                    "section_id": section_id, "items": []})
        g["items"].append(item)

    normal_negative: dict[str, dict] = {}
    for i, f in enumerate(doc.get("findings", [])):
        if f["verdict"] == "needs_review":
            review.append(_item(f, "findings", i, registry))
            continue
        if f["verdict"] not in NEGATIVE:
            continue
        item = _item(f, "findings", i, registry)
        normal_negative[f["req_id"]] = item
        anchor = _anchor(f, block_to_section)
        if anchor == "metadata":
            add("metadata", "metadata", METADATA_TITLE, item)
        elif anchor:
            add(anchor, "section", section_by_id[anchor]["title"], item, anchor)
        else:
            # Tema başına (konu kodu değil): birkaç kod aynı temayı paylaşabiliyor,
            # aynı başlıklı iki ayrı "eklenmeli" grubu ekibe tekrar gibi görünür.
            title = theme.get(item["primary_topic"], item["primary_topic"]) or "Diğer konular"
            add(f"absent:{tr_lower(title)}", "absent", title, item)

    for i, f in enumerate(doc.get("reverse_findings", [])):
        if f["verdict"] == "needs_review":
            review.append(_item(f, "reverse_findings", i, registry))
            continue
        if f["verdict"] != "contradicted":
            continue
        if f["req_id"] in normal_negative:
            normal_negative[f["req_id"]]["both_checks"] = True
            continue
        item = _item(f, "reverse_findings", i, registry)
        anchor = _anchor(f, block_to_section)
        if anchor and anchor != "metadata":
            add(anchor, "section", section_by_id[anchor]["title"], item, anchor)
        else:
            add("reverse:other", "section", "Belgenin diğer bölümleri", item)

    out = list(groups.values())
    for g in out:
        g["severity"] = _severity(g["items"])
    order = {s["id"]: n for n, s in enumerate(sections)}
    out.sort(key=lambda g: (SEVERITY_RANK[g["severity"]],
                            {"section": 0, "absent": 1, "metadata": 2}[g["kind"]],
                            order.get(g["section_id"], 999)))
    return out, review


def _severity(items: list[dict]) -> str:
    levels = [RISK_TO_SEVERITY.get(tr_lower(i["risk_level"]).strip(), "medium") for i in items]
    if any(i["verdict"] == "contradicted" for i in items):
        levels.append("high")
    return min(levels, key=SEVERITY_RANK.get) if levels else "medium"


# ------------------------------------------------------------- birleştirme
CONSOLIDATE_SYSTEM = """You merge several audit findings about ONE part of a bank's internal
policy/procedure document into a single, non-repetitive change request.

The findings were produced one regulatory requirement at a time, so several of them usually
describe the same gap in slightly different words. Merge those: every distinct change appears
exactly once.

Write three things, all in Turkish:
  internal_summary  one short paragraph for the compliance team: what is wrong in this part of
                    the document and why. You may describe what the regulation requires, in
                    plain words.
  change_requests   the concrete changes the document owner must make, as short imperative
                    items ("... eklenmeli", "... düzeltilmeli", "... kaldırılmalı"). One item per
                    distinct change. For each, list in `covers` the numbers of the findings it
                    resolves; every finding number must appear in at least one item.
  proposed_text     text the owner can paste into the document as it stands: the revised
                    paragraph(s) of this section, or — when the subject is missing from the
                    document entirely — a new section with a suggested heading. Empty only when
                    the only change is a deletion.

The change requests and proposed text go to the document owner team, who do not work with
the regulation. They must NEVER mention the regulation, BSEB, article numbers, requirement ids,
"uyum", "denetim" or "bulgu" — say only what the document should say.

Ground every change in the findings given. Do not import technical standards, product names or
numeric thresholds that are not in them. Where a finding says the bank must define something,
ask for it to be defined, by whom and how often it is reviewed — do not prescribe its value."""

CONSOLIDATE_SCHEMA = {
    "type": "object",
    "properties": {
        "internal_summary": {"type": "string"},
        "change_requests": {"type": "array", "items": {
            "type": "object",
            "properties": {"text": {"type": "string"},
                           "covers": {"type": "array", "items": {"type": "integer"}}},
            "required": ["text", "covers"],
        }},
        "proposed_text": {"type": "string"},
    },
    "required": ["internal_summary", "change_requests", "proposed_text"],
}

_VERDICT_EN = {"not_mentioned": "missing from the document", "partial": "partially covered",
               "contradicted": "the document says something contrary"}


def _prompt(doc: dict, group: dict, section_text: str) -> str:
    lines = [f"DOCUMENT: {doc.get('profile', {}).get('title') or doc['document_id']}"]
    if group["kind"] == "section":
        lines += [f"PART: section \"{group['title']}\"", "", "CURRENT TEXT OF THIS SECTION",
                  "----------------------------", section_text[:SECTION_TEXT_LIMIT] or "(empty)"]
    elif group["kind"] == "absent":
        lines += [f"PART: subject \"{group['title']}\" — not covered anywhere in the document"]
    else:
        lines += ["PART: document control information (code, classification, owner, "
                  "approval, review cycle, revision history)"]
    lines += ["", "FINDINGS", "--------"]
    for n, it in enumerate(group["items"], 1):
        lines.append(f"{n}. requirement: {it['requirement_text']}")
        lines.append(f"   status: {_VERDICT_EN.get(it['verdict'], it['verdict'])}")
        if it["missing_elements"]:
            lines.append(f"   missing: {', '.join(it['missing_elements'])}")
        if it["quote"]:
            lines.append(f"   document says: \"{it['quote']}\"")
        if it["rationale"]:
            lines.append(f"   note: {it['rationale']}")
    return "\n".join(lines)


def _leaks(out: dict) -> bool:
    texts = [c.get("text", "") for c in out.get("change_requests", [])] + [out.get("proposed_text", "")]
    return any(_LEAK.search(t) for t in texts)


def _scrub(text: str) -> str:
    return re.sub(r"\s{2,}", " ", _REQ_ID.sub("", text)).strip()


def _fallback(group: dict, exc: Exception) -> dict:
    """Model yoksa da ekip bir şey alır: her bulgu kendi maddesi olarak."""
    changes = []
    for n, it in enumerate(group["items"], 1):
        text = it["requirement_text"]
        if it["missing_elements"]:
            text += " (eksik: " + ", ".join(it["missing_elements"]) + ")"
        changes.append({"text": text, "covers": [n]})
    return {"internal_summary": "", "change_requests": changes, "proposed_text": "",
            "error": f"Otomatik birleştirme yapılamadı ({type(exc).__name__}); "
                     "maddeler ayrı ayrı listelendi."}


def _call(client: LLMClient, cfg: Config, suffix: str, stream) -> dict:
    if stream:
        return client.complete_json_stream(CONSOLIDATE_SYSTEM, "", suffix, CONSOLIDATE_SCHEMA,
                                           temperature=cfg.llm.temperature_draft, on_delta=stream)
    return client.complete_json(CONSOLIDATE_SYSTEM, "", suffix, CONSOLIDATE_SCHEMA,
                                temperature=cfg.llm.temperature_draft)


def consolidate_group(doc: dict, group: dict, client: LLMClient, cfg: Config,
                      progress=None, stream=None) -> dict:
    section = next((s for s in doc.get("sections", []) if s["id"] == group["section_id"]), None)
    suffix = _prompt(doc, group, section["text"] if section else "")
    if progress:
        progress(f"  {doc['document_id']} / {group['title']}: "
                 f"{len(group['items'])} bulgu birleştiriliyor...")
    try:
        out = _call(client, cfg, suffix, stream)
        if _leaks(out):
            out = _call(client, cfg, suffix + "\n\nREMINDER: your previous answer mentioned the "
                        "regulation or a requirement id in the text for the owner team. Rewrite "
                        "without any such reference.", stream)
    except Exception as exc:                                    # noqa: BLE001
        if progress:
            progress(f"    -> {group['title']}: birleştirilemedi ({type(exc).__name__}), "
                     "maddeler ayrı ayrı listelendi.")
        out = _fallback(group, exc)

    n_items = len(group["items"])
    changes, covered = [], set()
    for c in out.get("change_requests", []):
        text = _scrub(str(c.get("text", "")))
        if not text:
            continue
        nums = [n for n in c.get("covers", []) if isinstance(n, int) and 1 <= n <= n_items]
        covered.update(nums)
        changes.append({"text": text, "covers": nums})

    uncovered = [n for n in range(1, n_items + 1) if n not in covered]
    for n in uncovered:
        # Kaybolmasın: modelin atladığı bulgu ekibe yine gider, kendi maddesi olarak.
        it = group["items"][n - 1]
        text = it["requirement_text"]
        if it["missing_elements"]:
            text += " (eksik: " + ", ".join(it["missing_elements"]) + ")"
        changes.append({"text": text, "covers": [n], "added": True})

    return {**group,
            "internal_summary": str(out.get("internal_summary", "")).strip(),
            "change_requests": changes,
            "proposed_text": _scrub(str(out.get("proposed_text", ""))),
            "uncovered": [group["items"][n - 1]["req_id"] for n in uncovered],
            "error": out.get("error", "")}


def consolidate(state: CorpusState, client: LLMClient, registry: Registry,
                cfg: Config, progress=None, stream=None) -> CorpusState:
    documents = []
    for doc in state["documents"]:
        groups, review = group_findings(doc, registry)
        merged = [consolidate_group(doc, g, client, cfg, progress, stream) for g in groups]
        documents.append({**doc, "change_groups": merged, "review_items": review})
    return {"documents": documents}
