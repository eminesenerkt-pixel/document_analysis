# -*- coding: utf-8 -*-
"""Nodes: fan_out, evaluate_core, evaluate_border, verify_citation, challenge.

The evaluation task is document-level natural language inference: given a
document and a requirement, decide entailment / contradiction / not-mentioned
and point at the evidence. The ring decides which question is asked:

  core    "is this requirement met here?"          -> missing means a finding
  border  "is there a valid reference elsewhere?"  -> missing means a weak finding

Collapsing the two would blame every document for every subject it touches.
"""
from __future__ import annotations

from langgraph.types import Send

from ..config import Config
from ..labels import ring_tr, verdict_tr
from ..llm import LLMClient
from ..registry import Registry
from ..state import DocumentState, EvaluationTask, Evidence, Finding
from ..verify import verify_quote
from .metadata_rules import RULE_BACKED

# ------------------------------------------------------------------ fan-out
def fan_out(state: DocumentState, registry: Registry, cfg: Config) -> list[Send] | str:
    """One branch per candidate requirement. Universal-ring requirements that
    the rule engine already decided are skipped.

    With nothing left to evaluate, an empty Send list would end the graph
    right here — the rule-based findings would then never reach
    verify_citations / challenge / route_for_review. Go straight to
    verify_citations instead."""
    decided = {f["req_id"] for f in state.get("findings", [])}
    sends: list[Send] = []
    for cand in state["candidates"]:
        if cand["req_id"] in decided:
            continue
        req = registry.by_id[cand["req_id"]]
        samples = (cfg.llm.samples_high_risk
                   if req["risk_level"] in cfg.policy.high_risk_levels
                   else cfg.llm.samples_default)
        task: EvaluationTask = {
            "document_id": state["document_id"],
            "markdown": state["markdown"],
            "blocks": state["blocks"],
            "requirement": req,
            "ring": cand["ring"],
            "samples": samples,
        }
        target = "evaluate_border" if cand["ring"] == "border" else "evaluate_core"
        sends.append(Send(target, task))
    return sends or "verify_citations"


# ------------------------------------------------------------------ schemas
CORE_SCHEMA = {
    "type": "object",
    "properties": {
        "verdict": {"type": "string",
                    "enum": ["satisfied", "partial", "contradicted",
                             "not_mentioned", "out_of_scope", "needs_review"]},
        "evidence": {"type": "array", "items": {
            "type": "object",
            "properties": {"block_id": {"type": "string"}, "quote": {"type": "string"}},
            "required": ["block_id", "quote"]}},
        "missing_elements": {"type": "array", "items": {"type": "string"}},
        "rationale": {"type": "string"},
        "confidence": {"type": "number"},
    },
    "required": ["verdict", "evidence", "missing_elements", "rationale", "confidence"],
}

BORDER_SCHEMA = {
    "type": "object",
    "properties": {
        "verdict": {"type": "string",
                    "enum": ["satisfied_by_ref", "partial", "not_mentioned",
                             "out_of_scope", "needs_review"]},
        "referenced_document": {"type": "string"},
        "evidence": {"type": "array", "items": {
            "type": "object",
            "properties": {"block_id": {"type": "string"}, "quote": {"type": "string"}},
            "required": ["block_id", "quote"]}},
        "rationale": {"type": "string"},
        "confidence": {"type": "number"},
    },
    "required": ["verdict", "referenced_document", "evidence", "rationale", "confidence"],
}

CORE_SYSTEM = """You audit a bank's internal document against one regulatory requirement.

Decide one verdict:
  satisfied      the document meets the requirement in full
  partial        the subject is addressed but one or more required elements are missing
  contradicted   the document states something contrary to the requirement
  not_mentioned  the requirement is absent from the document
  out_of_scope   the requirement's subject does not fall within this document's scope
  needs_review   you cannot decide from the text alone

`contradicted` is easy to under-report because the offending sentence still reads as fluent
and on-topic — you have to check what it actually asserts, not just that it addresses the
right subject. Watch specifically for:
  - a NEGATION FLIPPED against the requirement (e.g. "may be used without approval" where the
    requirement demands approval) — grammatically identical to a compliant sentence except for
    one negation or one swapped word.
  - a specific, measurable commitment (a frequency, a deadline, a threshold, a retention
    period) QUIETLY WEAKENED into vaguer wording that no longer actually satisfies it — e.g.
    "at least once a year" softened to "from time to time", a fixed number replaced by
    "as needed" or a shorter period substituted for the one the rule sets.
  - a wrong number, threshold or named responsible party.
Read every sentence in the evidence for its literal meaning before deciding — do not let
topical relevance alone read as compliance.

Rules you must follow:
  * Quote evidence VERBATIM from the document and give the block id it came from.
    A paraphrase is not evidence and will be rejected.
  * Never rely on knowledge outside the document and the requirement given.
  * If the requirement lists several elements, name every element the document
    does not cover in missing_elements.
  * An obligation of the form "the bank shall define X" is met only when X is
    actually defined in writing, not when X is merely mentioned.
  * Prefer out_of_scope over a forced verdict when the subject genuinely does
    not belong to this document.
  * Write `rationale` and every entry in `missing_elements` in Turkish. The
    `evidence` quotes stay exactly as written in the document, in whatever
    language that is."""

BORDER_SYSTEM = """You audit whether a document properly defers a requirement to another document.

This requirement's home is a different document. You are not asking whether it
is met here; you are asking whether this document acknowledges the dependency.

Decide one verdict:
  satisfied_by_ref  the document names the other document (code or title) for this subject
  partial           the subject is relied on but no document is named
  not_mentioned     the dependency is neither addressed nor referenced
  out_of_scope      the requirement does not touch this document at all
  needs_review      you cannot decide from the text alone

Quote evidence VERBATIM with its block id. Name the referenced document exactly
as the text writes it. Write `rationale` in Turkish."""


def _requirement_block(req, ring: str) -> str:
    lines = [
        "REQUIREMENT",
        "-----------",
        f"id: {req['req_id']}    article: {req['article']}    ring: {ring}",
        f"obligation form: {req['obligation_form']}",
        f"requirement: {req['text']}",
        f"regulation wording: {req['source_sentence']}",
        f"control question: {req['control_question']}",
    ]
    if req["sub_elements"]:
        lines.append("required elements: " + " | ".join(req["sub_elements"]))
    return "\n".join(lines)


def _run(task: EvaluationTask, client: LLMClient, cfg: Config,
         system: str, schema: dict) -> tuple[dict, int]:
    prefix = "DOCUMENT\n--------\n" + task["markdown"]      # cached across calls
    suffix = _requirement_block(task["requirement"], task["ring"])
    return client.complete_json_voted(system, prefix, suffix, schema,
                                      vote_key="verdict", samples=task["samples"])


def _failed_finding(task: EvaluationTask, exc: Exception) -> Finding:
    """One branch's LLM call failed (gateway error after retries, malformed
    JSON). Raising here would abort the whole fan-out and lose every other
    requirement's result for this document; a needs_review finding keeps
    the rest and tells the reviewer exactly which one could not be decided."""
    return {
        "document_id": task["document_id"],
        "req_id": task["requirement"]["req_id"],
        "ring": task["ring"],
        "verdict": "needs_review",
        "confidence": 0.0,
        "evidence": [],
        "missing_elements": [],
        "referenced_document": "",
        "rationale": f"Model çağrısı başarısız oldu, karar verilemedi: {type(exc).__name__}: {exc}"[:500],
        "samples_agreed": 0,
        "challenged": False,
        "recommendation": "",
    }


def _confidence(out: dict, agreed: int, samples: int) -> float:
    """Model's own confidence, capped when self-consistency samples split.
    Compared against THIS task's sample count — the old check
    (`1 < agreed < samples_high_risk`) skipped agreed == 1, i.e. the case
    where every sample disagreed, which is the least reliable one."""
    try:
        conf = float(out.get("confidence") or 0.0)
    except (TypeError, ValueError):
        conf = 0.0
    if samples > 1 and agreed < samples:
        conf = min(conf, 0.55)
    return conf


def _collect_evidence(raw: list[dict], blocks) -> list[Evidence]:
    out: list[Evidence] = []
    for item in raw[:4]:
        ok, reason = verify_quote(blocks, item.get("block_id", ""), item.get("quote", ""))
        out.append({"block_id": item.get("block_id", ""), "quote": item.get("quote", ""),
                    "verified": ok, "reason": reason})
    return out


def evaluate_core(task: EvaluationTask, client: LLMClient,
                  cfg: Config, progress=None) -> DocumentState:
    req_id = task["requirement"]["req_id"]
    if progress:
        progress(f"  {req_id} ({ring_tr(task['ring'])}, {task['samples']} örnek) "
                 "değerlendiriliyor...")
    try:
        out, agreed = _run(task, client, cfg, CORE_SYSTEM, CORE_SCHEMA)
    except Exception as exc:                                    # noqa: BLE001
        if progress:
            progress(f"    -> {req_id}: model çağrısı başarısız, insan incelemesine bırakıldı ({exc})")
        return {"findings": [_failed_finding(task, exc)]}
    finding: Finding = {
        "document_id": task["document_id"],
        "req_id": req_id,
        "ring": task["ring"],
        "verdict": out.get("verdict", "needs_review"),
        "confidence": _confidence(out, agreed, task["samples"]),
        "evidence": _collect_evidence(out.get("evidence", []), task["blocks"]),
        "missing_elements": out.get("missing_elements", []),
        "referenced_document": "",
        "rationale": out.get("rationale", ""),
        "samples_agreed": agreed,
        "challenged": False,
        "recommendation": "",
    }
    if progress:
        progress(f"    -> {req_id}: {verdict_tr(finding['verdict'])} "
                 f"(uyum {agreed}/{task['samples']}, güven {finding['confidence']:.2f})")
    return {"findings": [finding]}


def evaluate_border(task: EvaluationTask, client: LLMClient,
                    cfg: Config, progress=None) -> DocumentState:
    req_id = task["requirement"]["req_id"]
    if progress:
        progress(f"  {req_id} ({ring_tr('border')}, {task['samples']} örnek) "
                 "değerlendiriliyor...")
    try:
        out, agreed = _run(task, client, cfg, BORDER_SYSTEM, BORDER_SCHEMA)
    except Exception as exc:                                    # noqa: BLE001
        if progress:
            progress(f"    -> {req_id}: model çağrısı başarısız, insan incelemesine bırakıldı ({exc})")
        return {"findings": [_failed_finding(task, exc)]}
    finding: Finding = {
        "document_id": task["document_id"],
        "req_id": req_id,
        "ring": "border",
        "verdict": out.get("verdict", "needs_review"),
        "confidence": _confidence(out, agreed, task["samples"]),
        "evidence": _collect_evidence(out.get("evidence", []), task["blocks"]),
        "missing_elements": [],
        "referenced_document": out.get("referenced_document", ""),
        "rationale": out.get("rationale", ""),
        "samples_agreed": agreed,
        "challenged": False,
        "recommendation": "",
    }
    if progress:
        progress(f"    -> {req_id}: {verdict_tr(finding['verdict'])} "
                 f"(uyum {agreed}/{task['samples']}, güven {finding['confidence']:.2f})")
    return {"findings": [finding]}


# --------------------------------------------------------------- verification
def verify_citations(state: DocumentState, cfg: Config) -> DocumentState:
    """Downgrade findings whose evidence does not survive verbatim matching.

    A positive verdict resting on an unverifiable quote — or on NO quote at
    all — is downgraded rather than deleted, so the reviewer sees that
    something was claimed and why it was not accepted. (Self-consistency
    disagreement is capped where the samples are known, in _confidence.)"""
    checked: list[Finding] = []
    for f in state["findings"]:
        needs_evidence = f["verdict"] in ("satisfied", "partial", "contradicted",
                                          "satisfied_by_ref")
        if needs_evidence and not f["evidence"]:
            f = {**f,
                 "verdict": "needs_review",
                 "confidence": min(f["confidence"], 0.3),
                 "rationale": f["rationale"] + "  [karar için belgeden alıntı verilmedi]"}
        elif needs_evidence and not any(e["verified"] for e in f["evidence"]):
            f = {**f,
                 "verdict": "needs_review",
                 "confidence": min(f["confidence"], 0.3),
                 "rationale": f["rationale"] +
                              "  [alıntı belgede doğrulanamadı]"}
        checked.append(f)
    return {"findings": checked}


# ----------------------------------------------------------------- challenge
CHALLENGE_SYSTEM = """You argue against a proposed audit finding.

You are given a document and a finding claimed about it. Try to refute the
finding using the document's own text. If the finding survives your attempt,
say so plainly.

Precision matters more than recall in this report: a false finding sent to a
business unit costs more than a missed one, which a human reviewer will catch.

Write `counter_evidence` and `reason` in Turkish."""

CHALLENGE_SCHEMA = {
    "type": "object",
    "properties": {
        "refuted": {"type": "boolean"},
        "counter_evidence": {"type": "string"},
        "reason": {"type": "string"},
    },
    "required": ["refuted", "counter_evidence", "reason"],
}


def challenge(state: DocumentState, client: LLMClient,
              registry: Registry, cfg: Config, progress=None) -> DocumentState:
    """Adversarial pass over negative verdicts only. Cheap because the report
    carries far fewer findings than the candidate set, and it is the single
    most effective filter on false positives."""
    kept: list[Finding] = []
    for f in state["findings"]:
        if f["verdict"] not in ("not_mentioned", "contradicted", "partial"):
            kept.append(f)
            continue
        # Decided by check_metadata's rules, not by a model — a model must
        # not overturn a rule-based verdict (universal ring: "no LLM").
        if f["ring"] == "universal" and f["req_id"] in RULE_BACKED:
            kept.append(f)
            continue

        if progress:
            progress(f"  {f['req_id']}: itiraz turu başlıyor...")
        req = registry.by_id[f["req_id"]]
        prefix = "DOCUMENT\n--------\n" + state["markdown"]
        if f["ring"] == "border":
            # A border finding does not claim the requirement is unmet here —
            # it claims the document relies on the subject without pointing
            # to the document that owns it. Asking "is the requirement met?"
            # would refute it for the wrong reason.
            claim = (
                "claim: this document relies on the requirement's subject but does "
                "not properly reference the other document that owns it\n"
                f"verdict: {f['verdict']}\n"
                f"rationale: {f['rationale']}\n\n"
                "Refute this finding ONLY if the document does name or refer to "
                "another document (by code or title) for this subject; otherwise "
                "state that it stands."
            )
        else:
            claim = (
                f"verdict: {f['verdict']}\n"
                f"missing: {', '.join(f['missing_elements']) or '—'}\n"
                f"rationale: {f['rationale']}\n\n"
                "Refute this finding from the document's text, or state that it stands."
            )
        suffix = ("PROPOSED FINDING\n----------------\n"
                  f"requirement: {req['text']}\n" + claim)
        try:
            out = client.complete_json(CHALLENGE_SYSTEM, prefix, suffix, CHALLENGE_SCHEMA,
                                       temperature=cfg.llm.temperature_judge)
        except Exception as exc:                                # noqa: BLE001
            # The finding stays as it was (not challenged) — losing the whole
            # document over one failed refutation attempt is worse.
            if progress:
                progress(f"    -> {f['req_id']}: itiraz çağrısı başarısız, bulgu olduğu gibi bırakıldı.")
            kept.append({**f, "rationale": f["rationale"] +
                         f"  [itiraz turu yapılamadı: {type(exc).__name__}]"})
            continue
        if out.get("refuted"):
            if progress:
                progress(f"    -> {f['req_id']}: itiraz kabul edildi, "
                         f"'{verdict_tr('needs_review')}' durumuna çekildi.")
            kept.append({**f,
                         "verdict": "needs_review",
                         "confidence": min(f["confidence"], 0.4),
                         "challenged": True,
                         "rationale": f["rationale"] +
                                      "  [itiraz: " + out.get("reason", "") + "]"})
        else:
            if progress:
                progress(f"    -> {f['req_id']}: bulgu ayakta kaldı.")
            kept.append({**f, "challenged": True})
    return {"findings": kept}


def route_for_review(state: DocumentState, cfg: Config) -> DocumentState:
    """Split off everything a human must look at."""
    pending = [f for f in state["findings"]
               if f["verdict"] == "needs_review"
               or f["confidence"] < cfg.policy.review_threshold]
    return {"pending_review": pending}
