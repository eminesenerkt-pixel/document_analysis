# -*- coding: utf-8 -*-
"""Corpus-level nodes: reverse_scan, evidence_agent, recommend, render_report.

Per-document review answers "is this document compliant?". The corpus pass
answers the question the regulator actually asks: "is every requirement
covered somewhere?" Only the second one finds missing documents, and only the
second one can tell an uncovered requirement from one that simply lives
elsewhere.
"""
from __future__ import annotations
import json
from pathlib import Path

from ..config import Config
from ..llm import LLMClient
from ..registry import Registry
from ..state import CorpusState, Finding
from ..verify import normalize

COVERED = {"satisfied", "satisfied_by_ref"}


# ----------------------------------------------------------- reverse scan
def reverse_scan(state: CorpusState, registry: Registry,
                 cfg: Config) -> CorpusState:
    covered: dict[str, list[str]] = {}
    for doc in state["documents"]:
        for f in doc.get("findings", []):
            if f["verdict"] in COVERED and f["ring"] in ("core", "universal"):
                covered.setdefault(f["req_id"], []).append(doc["document_id"])

    orphans = [r["req_id"] for r in registry.requirements
               if not r["universal"]
               and registry.applies(r, cfg.policy.condition_flags) is not False
               and r["req_id"] not in covered]

    missing_types = sorted({registry.by_id[rid]["primary_topic"] for rid in orphans})

    return {"covered_requirements": covered,
            "orphan_requirements": orphans,
            "missing_document_types": missing_types}


# ---------------------------------------------------------- evidence agent
SEARCH_SYSTEM = """You look for a regulatory requirement across a set of documents.

A requirement was not found in the document that should own it. Before it is
reported as a gap, establish whether another document covers it.

Work in rounds. Each round you may issue one search query over the corpus and
read the snippets that come back. Reformulate if the first wording fails —
regulatory language and internal wording rarely match on the first try.

Stop as soon as you can answer, and always state which documents you looked at.

When you conclude with found=true, `document_id` must be the id shown in
brackets in the search log, and `quote` must be copied VERBATIM from one of
that document's snippets. A claim that cannot be matched to a returned
snippet is discarded.

Issue `query` in the language the corpus is written in (Turkish, unless the
documents themselves are in another language). Write `reason` in Turkish."""

SEARCH_SCHEMA = {
    "type": "object",
    "properties": {
        "action": {"type": "string", "enum": ["search", "conclude"]},
        "query": {"type": "string"},
        "found": {"type": "boolean"},
        "document_id": {"type": "string"},
        "quote": {"type": "string"},
        "searched": {"type": "array", "items": {"type": "string"}},
        "reason": {"type": "string"},
    },
    "required": ["action", "query", "found", "document_id", "quote", "searched", "reason"],
}


def evidence_agent(state: CorpusState, client: LLMClient, registry: Registry,
                   cfg: Config, search, progress=None) -> CorpusState:
    """The one genuinely agentic component: variable number of steps, tool use,
    and the stopping decision belongs to the model.

    It is safe to be agentic here because the output is a fact — "covered in
    document X, page Y" or "searched the corpus, not present" — which a human
    can check. The evaluation core stays deterministic for the opposite reason.
    """
    resolved: dict[str, list[str]] = dict(state["covered_requirements"])
    still_orphan: list[str] = []

    for req_id in state["orphan_requirements"]:
        req = registry.by_id[req_id]
        transcript: list[str] = []
        seen_hits: list[dict] = []          # full snippets, for verifying the answer
        answer = None
        if progress:
            progress(f"  {req_id}: bu gereksinim için korpusta kanıt aranıyor...")

        for round_no in range(cfg.policy.evidence_search_rounds):
            suffix = (
                f"REQUIREMENT\n-----------\n{req['text']}\n"
                f"regulation wording: {req['source_sentence']}\n\n"
                "SEARCH LOG\n----------\n" + ("\n".join(transcript) or "(empty)") +
                "\n\nIssue the next search, or conclude."
            )
            try:
                out = client.complete_json(SEARCH_SYSTEM, "", suffix, SEARCH_SCHEMA,
                                           temperature=cfg.llm.temperature_extract)
            except Exception as exc:                            # noqa: BLE001
                if progress:
                    progress(f"    -> {req_id}: model hatası ({type(exc).__name__}), "
                             "arama durduruldu; gereksinim karşılıksız sayılıyor.")
                break
            if out.get("action") == "conclude":
                answer = out
                if progress:
                    verdict = "bulundu" if out.get("found") else "korpusta yok"
                    progress(f"    -> {req_id}: tur {round_no + 1}'de karar verdi — {verdict}.")
                break
            hits = search(out.get("query", ""), k=5)
            if progress:
                progress(f"    tur {round_no + 1}: \"{out.get('query', '')}\" "
                         f"({len(hits)} sonuç)")
            transcript.append(f"query: {out.get('query','')}")
            for h in hits:
                seen_hits.append(h)
                transcript.append(f"  [{h['document_id']}] {h['text'][:200]}")
        else:
            if progress:
                progress(f"    -> {req_id}: {cfg.policy.evidence_search_rounds} tur "
                         "sonunda kanıt bulunamadı, gereksinim karşılıksız kalıyor.")

        if answer and answer.get("found") and _answer_verified(answer, seen_hits):
            resolved.setdefault(req_id, []).append(answer["document_id"])
        else:
            if answer and answer.get("found") and progress:
                progress(f"    -> {req_id}: model 'bulundu' dedi ama alıntı arama "
                         "sonuçlarında doğrulanamadı; karşılıksız sayılıyor.")
            still_orphan.append(req_id)

    return {"covered_requirements": resolved, "orphan_requirements": still_orphan}


def _answer_verified(answer: dict, hits: list[dict]) -> bool:
    """Same rule as everywhere else in the pipeline: a claim of coverage
    must rest on a verbatim quote. The quote has to appear in a snippet the
    search actually returned, from the document the model names — so a
    model that concludes "found" without searching, names a document that
    does not exist, or paraphrases, does not get to close the gap."""
    doc_id = answer.get("document_id", "")
    needle = normalize(answer.get("quote", ""))
    if not doc_id or not needle:
        return False
    return any(h["document_id"] == doc_id and needle in normalize(h["text"])
               for h in hits)


# -------------------------------------------------------------- recommend
RECOMMEND_SYSTEM = """You write the remediation text for a confirmed audit finding.

Constraints:
  * Ground every sentence in the regulation wording you are given. Do not
    import technical standards, product names or numeric thresholds from
    outside it.
  * Where the regulation delegates ("the bank shall define X"), recommend that
    X be defined and say who defines it and how often it is reviewed. Do not
    prescribe the value of X.
  * Write text that can be pasted into the document as it stands — the
    document is in Turkish, so `finding_statement`, `risk` and
    `recommendation` must all be written in Turkish.
  * Imperative, specific, measurable. No hedging."""

RECOMMEND_SCHEMA = {
    "type": "object",
    "properties": {
        "finding_statement": {"type": "string"},
        "risk": {"type": "string"},
        "recommendation": {"type": "string"},
        "severity": {"type": "string", "enum": ["critical", "high", "medium", "low"]},
    },
    "required": ["finding_statement", "risk", "recommendation", "severity"],
}

TOPIC_FAMILY = {
    "security_technical": {"sifreleme_anahtar_yonetimi", "ag_mimari_segmentasyon",
                           "veri_sizintisi_onleme", "guvenlik_konfigurasyonu",
                           "zafiyet_yama_yonetimi", "uzaktan_erisim"},
    "process_governance": {"dokuman_yonetimi", "yonetisim_bs_strateji",
                           "bs_organizasyon_gorev_tanimi", "bs_risk_yonetimi"},
    "continuity":         {"sureklilik_birincil_ikincil", "yedekleme_erisilebilirlik",
                           "sureklilik_plani_tatbikat", "ikincil_merkez"},
    "customer_channel":   {"ebank_kimlik_dogrulama", "ebank_islem_guvenligi",
                           "musteri_bilgilendirme", "kanal_atm"},
    "audit_control":      {"bs_ic_kontrol", "bs_ic_denetim", "bulgu_takibi"},
}


def _family(topic: str) -> str:
    for name, codes in TOPIC_FAMILY.items():
        if topic in codes:
            return name
    return "general"


def _write_one_recommendation(f: Finding, doc: dict, registry: Registry, client: LLMClient,
                              cfg: Config, progress, stream) -> Finding:
    req = registry.by_id[f["req_id"]]
    suffix = (
        f"FINDING\n-------\n"
        f"document: {doc['document_id']} ({doc['profile']['title']})\n"
        f"requirement: {req['text']}\n"
        f"regulation wording: {req['source_sentence']}\n"
        f"obligation form: {req['obligation_form']}\n"
        f"risk level in register: {req['risk_level']}\n"
        f"verdict: {f['verdict']}\n"
        f"missing elements: {', '.join(f['missing_elements']) or '—'}\n"
        f"evidence: {f['evidence'][0]['quote'] if f['evidence'] else '—'}\n"
        f"topic family: {_family(req['primary_topic'])}"
    )
    if progress:
        progress(f"  {doc['document_id']} / {f['req_id']}: öneri yazılıyor...")
    try:
        if stream:
            out = client.complete_json_stream(RECOMMEND_SYSTEM, "", suffix, RECOMMEND_SCHEMA,
                                              temperature=cfg.llm.temperature_draft,
                                              on_delta=stream)
        else:
            out = client.complete_json(RECOMMEND_SYSTEM, "", suffix, RECOMMEND_SCHEMA,
                                       temperature=cfg.llm.temperature_draft)
    except Exception as exc:                                    # noqa: BLE001
        # The finding itself stands; only its remediation text is missing.
        if progress:
            progress(f"    -> {f['req_id']}: öneri yazılamadı ({type(exc).__name__}), atlandı.")
        return f
    return {**f, "recommendation": json.dumps(out, ensure_ascii=False)}


def recommend(state: CorpusState, client: LLMClient, registry: Registry,
              cfg: Config, progress=None, stream=None) -> CorpusState:
    """Write recommendations only for findings that survived verification and
    the adversarial pass — both the normal (madde→belge) findings AND the
    independent reverse_check (belge→BSEB) findings get one, each processed
    the same way but kept in their own list (see state.py:DocumentRecord).

    `stream`, given, receives the model's own text as it is generated (one
    finding at a time — this loop is sequential, never fanned out, so there
    is exactly one writer and no interleaving to worry about). `progress`
    marks where one finding's text starts and ends."""
    documents = []
    for doc in state["documents"]:
        findings: list[Finding] = []
        for f in doc.get("findings", []):
            if f["verdict"] not in ("not_mentioned", "contradicted", "partial"):
                findings.append(f)
            else:
                findings.append(_write_one_recommendation(f, doc, registry, client, cfg,
                                                          progress, stream))

        reverse_findings: list[Finding] = []
        for f in doc.get("reverse_findings", []):
            if f["verdict"] != "contradicted":
                reverse_findings.append(f)
            else:
                reverse_findings.append(_write_one_recommendation(f, doc, registry, client, cfg,
                                                                  progress, stream))

        documents.append({**doc, "findings": findings, "reverse_findings": reverse_findings})
    return {"documents": documents}


# ----------------------------------------------------------------- report
def render_report(state: CorpusState, registry: Registry,
                  cfg: Config) -> CorpusState:
    """Deterministic rendering. Nothing is decided here."""
    out_dir = Path(cfg.paths.report_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"findings_{state['run_id']}.json"
    path.write_text(json.dumps({
        "run_id": state["run_id"],
        "documents": state["documents"],
        "covered_requirements": state["covered_requirements"],
        "orphan_requirements": state["orphan_requirements"],
        "missing_document_types": state["missing_document_types"],
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"report_path": str(path)}
