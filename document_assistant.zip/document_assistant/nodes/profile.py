# -*- coding: utf-8 -*-
"""Nodes: profile_document, select_topics, recall_guard, expand_requirements.

Division of labour, deliberately:

  LLM  reads the purpose/scope statement and picks topic codes from a CLOSED list
  code maps those codes to requirement ids and assigns rings

Letting the model pick requirement ids directly would be unreproducible and
would under-select — measured on this register, roughly half of the articles
relevant to a given subject live outside that subject's own regulation chapter.
"""
from __future__ import annotations
import re

from ..config import Config
from ..llm import LLMClient
from ..registry import Registry
from ..state import DocumentState
from ..verify import tr_lower

# --------------------------------------------------------------- metadata labels
FIELD_LABELS = {
    "document_code":   ["doküman no", "dokuman no", "doküman kodu", "belge no",
                        "belge kodu", "referans no"],
    "version":         ["revize no", "sürüm", "surum", "versiyon", "revizyon no"],
    "revision_date":   ["revizyon tarihi", "revize tarihi"],
    "effective_date":  ["yürürlük tarihi", "yururluk tarihi", "geçerlilik tarihi",
                        "yayın tarihi"],
    "confidentiality": ["gizlilik derecesi", "gizlilik seviyesi", "güvenlik sınıfı",
                        "sınıflandırma"],
    "owner":           ["belge sahibi", "doküman sahibi", "süreç sahibi",
                        "hazırlayan"],
    "approver":        ["onaylayan", "onay makamı"],
    # Bazı şablonlarda "onaylayan" (BSEB governance onayı, REQ-5.3'ün
    # sorduğu) ile "yürürlük onayı" (doküman/kalite yönetiminin resmi
    # yayın onayı) AYRI kişilerdir — aynı alana yazılırsa ikincisi
    # birincisini sessizce ezer ya da (found kilidi yüzünden) kaybolur.
    "enactment_approver": ["yürürlük onayı", "yürürlük onay"],
}

CLASS_PATTERNS = [
    (r"politikas[ıi]\b|\bpolitika\b", "policy"),
    (r"prosedür|prosedur|uygulama esas|talimat|yönerge|yonerge|kılavuz|kilavuz|standart|plan",
     "procedure"),
]


def _classify(title: str) -> str:
    low = tr_lower(title)
    for pattern, cls in CLASS_PATTERNS:
        if re.search(pattern, low):
            return cls
    return "unknown"


def _scan_labels(fragments: list[str]) -> dict[str, str]:
    """Pull labelled fields out of header, footer and key-value tables.

    Two distinct shapes need catching, and neither subsumes the other:
      * a two-column table row, already split into one fragment per row,
        e.g. "Onaylayan | Bilgi Güvenliği Müdürü" — no colon anywhere.
      * inline prose with the label and value on one line joined by a
        colon, e.g. a header rendered as "... Gizlilik Derecesi: —".
    Both run on every fragment rather than one being a fallback for the
    other: a 2-column row's few-many-words split by "|"/double-space can
    coincidentally also contain a colon elsewhere (or not), and a header
    line that happens to split into exactly two pipe-separated halves is
    not a label/value pair just because of that shape.
    """
    found: dict[str, str] = {}
    for frag in fragments:
        parts = re.split(r"\s*\|\s*|\s{2,}", frag)

        if len(parts) == 2:
            label, value = tr_lower(parts[0].strip()), parts[1].strip()
            if value:
                for field, aliases in FIELD_LABELS.items():
                    if field not in found and any(label.startswith(a) for a in aliases):
                        found[field] = value

        for part in parts:
            m = re.match(r"^\s*([^:]{3,40}?)\s*:\s*(.+)$", part)
            if not m:
                continue
            label, value = tr_lower(m.group(1).strip()), m.group(2).strip()
            for field, aliases in FIELD_LABELS.items():
                if field not in found and any(label.startswith(a) for a in aliases):
                    found[field] = value
    return found


def _matching_field(label: str) -> str | None:
    for field, aliases in FIELD_LABELS.items():
        if any(label.startswith(a) for a in aliases):
            return field
    return None


def _scan_table_headers(blocks) -> dict[str, str]:
    """Pull labelled fields out of a THIRD table shape `_scan_labels` cannot
    see: a header row naming several roles at once, with the actual names
    in a separate data row underneath —

        Hazırlayan          | Onaylayan     | Yürürlük Onayı
        Fatih Abidin Silan  | Onurhan Yılmaz | Fatih Muhammed Ünal

    `_scan_labels` only ever looks at ONE fragment (one rendered line) at a
    time, so a header cell and its value one row below are, to it, two
    unrelated lines — neither is a "Label | Value" pair on its own. This
    walks the table's RAW `rows` (not the flattened markdown text used
    elsewhere) so a header cell can be paired with the same-column cell of
    the row below it.

    Must not fire on a KÜNYE-style table (many rows, each its own "Label |
    Value" pair — already `_scan_labels`'s job): there, row 0 is itself a
    real label+value pair, e.g. ["Doküman No", "POL.001"] — only the FIRST
    cell is label-shaped, the second is a value that will not match any
    alias. A genuine header row is label-shaped in EVERY cell. Requiring
    all (>=2) cells to match is what tells the two shapes apart.
    """
    found: dict[str, str] = {}
    for b in blocks:
        if b["type"] != "table" or len(b.get("rows", [])) < 2:
            continue
        header, data = b["rows"][0], b["rows"][1]
        cells = [tr_lower(c.strip()) for c in header if c.strip()]
        if len(cells) < 2 or any(_matching_field(c) is None for c in cells):
            continue                                     # not a header row
        for i, cell in enumerate(header):
            field = _matching_field(tr_lower(cell.strip()))
            if field and field not in found and i < len(data) and data[i].strip():
                found[field] = data[i].strip()
    return found


def _detect_languages(markdown: str) -> list[str]:
    """Bank documents often carry a Turkish and an English version in one
    file. Both must be flagged: evaluating only one half silently halves
    coverage."""
    langs = []
    if re.search(r"\b(ve|için|olarak|ilişkin|sağlan)\b", markdown, re.I):
        langs.append("tr")
    if re.search(r"\b(the|shall|must|responsibilities|purpose|scope)\b", markdown):
        langs.append("en")
    if re.search(r"english version of the document|english version", markdown, re.I):
        if "en" not in langs:
            langs.append("en")
    return langs or ["tr"]


_TR_WORDS = re.compile(r"\b(ve|için|olarak|ilişkin|sağlan|gereklidir|yönetim|kurulu|"
                       r"belge|olan|edilir|üzere|ile|bu)\b", re.I)
_EN_WORDS = re.compile(r"\b(the|shall|must|responsibilities|purpose|scope|policy|"
                       r"document|this|shall be|is|are)\b", re.I)


def _block_lang(text: str) -> str:
    tr_hits, en_hits = len(_TR_WORDS.findall(text)), len(_EN_WORDS.findall(text))
    if tr_hits == en_hits:
        return "neutral"
    return "tr" if tr_hits > en_hits else "en"


def split_bilingual(blocks: list[dict]) -> tuple[list[dict], list[dict]] | None:
    """A document that states its content in Turkish in full, then repeats
    the same content in English (title included), splits cleanly at one
    point: an unbroken Turkish run followed by an unbroken English run, both
    non-trivial. Interleaved bilingual tables would not match this and
    correctly return None — nothing to compare block by block there."""
    content = [b for b in blocks if b["type"] in ("paragraph", "heading")
              and b["source"] == "body" and b["text"].strip()]
    if len(content) < 4:
        return None
    langs = [_block_lang(b["text"]) for b in content]

    split_at = None
    for i in range(1, len(langs)):
        head = [l for l in langs[:i] if l != "neutral"]
        tail = [l for l in langs[i:] if l != "neutral"]
        if (len(head) >= 2 and len(tail) >= 2
                and all(l == "tr" for l in head) and all(l == "en" for l in tail)):
            split_at = i
            break
    if split_at is None:
        return None

    tr_ids = {content[j]["id"] for j in range(split_at)}
    en_ids = {content[j]["id"] for j in range(split_at, len(content))}
    tr_blocks = [b for b in blocks if b["id"] in tr_ids]
    en_blocks = [b for b in blocks if b["id"] in en_ids]
    return tr_blocks, en_blocks


TRANSLATION_SYSTEM = """You compare a Turkish policy/procedure document with its own English
translation, given below (Turkish first, then English).

Find every place where the English version changes what the Turkish original
actually requires: a different number, deadline, condition, obligation
strength ("shall" vs "may"/"should"), or scope. Do not flag wording
differences that carry the same obligation.

Write every field in Turkish. Quote the Turkish original and the matching
English text so a reviewer can compare them side by side."""

TRANSLATION_SCHEMA = {
    "type": "object",
    "properties": {
        "matches": {"type": "boolean"},
        "discrepancies": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "turkish": {"type": "string"},
                "english": {"type": "string"},
                "issue": {"type": "string"},
            },
            "required": ["turkish", "english", "issue"],
        }},
    },
    "required": ["matches", "discrepancies"],
}


def check_translation(state: DocumentState, client: LLMClient,
                      cfg: Config, progress=None) -> DocumentState:
    """Only runs when the document is a clean Turkish-then-English split
    (split_bilingual finds one); a no-op otherwise, so it costs nothing on
    the far more common single-language document."""
    split = split_bilingual(state["blocks"])
    if split is None:
        return {}
    tr_blocks, en_blocks = split
    if progress:
        progress("  çeviri kontrolü: Türkçe ve İngilizce sürüm karşılaştırılıyor...")

    tr_text = "\n\n".join(b["text"] for b in tr_blocks)
    en_text = "\n\n".join(b["text"] for b in en_blocks)
    suffix = f"TÜRKÇE\n------\n{tr_text}\n\nENGLISH\n-------\n{en_text}"
    warnings = list(state.get("warnings", []))
    try:
        out = client.complete_json(TRANSLATION_SYSTEM, "", suffix, TRANSLATION_SCHEMA,
                                   temperature=cfg.llm.temperature_extract)
    except Exception as exc:                                    # noqa: BLE001
        warnings.append(f"Çeviri kontrolü yapılamadı (model hatası: {type(exc).__name__}); "
                        "Türkçe/İngilizce sürüm elle karşılaştırılmalı.")
        if progress:
            progress("    -> çeviri kontrolü: model hatası, atlandı")
        return {"warnings": warnings}

    for d in out.get("discrepancies", []):
        warnings.append(f"Çeviri farkı — TR: “{d.get('turkish', '')}” · "
                        f"EN: “{d.get('english', '')}” — {d.get('issue', '')}")
    if progress:
        n = len(out.get("discrepancies", []))
        progress(f"    -> çeviri kontrolü: {'uyumlu' if not n else f'{n} fark bulundu'}")
    return {"warnings": warnings}


# ------------------------------------------------------------------- node 1
def profile_document(state: DocumentState, client: LLMClient,
                     registry: Registry, cfg: Config, progress=None) -> DocumentState:
    if progress:
        progress("  künye/onay bilgileri çıkarılıyor (kural tabanlı, tamamen otomatik)...")
    blocks = state["blocks"]
    title = next((b["text"] for b in blocks if b["source"] == "body"), "")

    fragments = [b["text"] for b in blocks if b["source"] in ("header", "footer")]
    for b in blocks:
        if b["type"] == "table":
            fragments.extend(b["text"].split("\n"))
    # _scan_table_headers'ın bulduğu alanlar önceliklidir: hücreler zaten
    # ayrık olduğundan (bir satırın metni başka bir satırınkiyle
    # karışamaz), _scan_labels'ın satır-içi regex'inden daha güvenilirdir.
    meta = {**_scan_labels(fragments), **_scan_table_headers(blocks)}

    # Purpose + scope + headings: the evidence the topic selector reads.
    lead = [b["text"] for b in blocks if b["source"] == "body"][:30]
    headings = [b["text"] for b in blocks if b["type"] == "heading"][:25]

    return {
        "profile": {
            "title": title,
            "document_class": _classify(title or state["document_id"]),
            "document_code":   meta.get("document_code", ""),
            "version":         meta.get("version", ""),
            "effective_date":  meta.get("effective_date", ""),
            "revision_date":   meta.get("revision_date", ""),
            "confidentiality": meta.get("confidentiality", ""),
            "owner":           meta.get("owner", ""),
            "approver":        meta.get("approver", ""),
            "enactment_approver": meta.get("enactment_approver", ""),
            "languages": _detect_languages(state["markdown"]),
            "declared_topics": [],
            "topic_rationale": {},
            "title_scope_conflict": False,
            "conflict_note": "",
            "_lead": lead,
            "_headings": headings,
        }
    }


# ------------------------------------------------------------------- node 2
TOPIC_SYSTEM = (
    "You classify the subject matter of a bank's internal information-systems "
    "document against a fixed catalogue of regulatory topics.\n"
    "Select only topics the document itself declares it governs — read its "
    "purpose and scope statement, not every subject it mentions in passing.\n"
    "A document that merely refers to another document's subject does NOT "
    "declare that subject.\n"
    "Answer in the requested JSON shape and never invent a topic code. "
    "Write `evidence` and `conflict_note` in Turkish."
)

TOPIC_SCHEMA = {
    "type": "object",
    "properties": {
        "topics": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "code": {"type": "string"},
                "evidence": {"type": "string"},
            },
            "required": ["code", "evidence"],
        }},
        "title_matches_scope": {"type": "boolean"},
        "conflict_note": {"type": "string"},
    },
    "required": ["topics", "title_matches_scope", "conflict_note"],
}


def select_topics(state: DocumentState, client: LLMClient,
                  registry: Registry, cfg: Config, progress=None) -> DocumentState:
    profile = dict(state["profile"])
    if progress:
        progress("  konu sınıflandırması yapılıyor...")

    prefix = (
        "TOPIC CATALOGUE (choose only from these codes)\n"
        "----------------------------------------------\n"
        + registry.topic_catalogue()
    )
    suffix = (
        "DOCUMENT\n--------\n"
        f"Title: {profile['title']}\n"
        f"Headings: {' | '.join(profile.get('_headings', []))}\n\n"
        "Opening sections:\n" + "\n".join(profile.get("_lead", [])) + "\n\n"
        "Return the topic codes this document declares it governs. For each, "
        "quote the sentence that shows it. Then state whether the title matches "
        "the declared scope; if it does not, say what the mismatch is."
    )

    try:
        out = client.complete_json(TOPIC_SYSTEM, prefix, suffix, TOPIC_SCHEMA,
                                   temperature=cfg.llm.temperature_extract)
    except Exception as exc:                                    # noqa: BLE001
        # Without topics only the universal ring is evaluated. Said loudly
        # (_topic_error -> warning in expand_requirements) so an empty
        # core/border set is never mistaken for "nothing applies".
        if progress:
            progress(f"  konu sınıflandırması başarısız ({type(exc).__name__}); "
                     "yalnızca evrensel maddeler değerlendirilecek.")
        profile["declared_topics"] = []
        profile["topic_rationale"] = {}
        profile["_topic_error"] = (f"Konu sınıflandırması model hatası nedeniyle yapılamadı "
                                   f"({type(exc).__name__}); yalnızca evrensel maddeler "
                                   "değerlendirildi, belge yeniden taranmalı.")
        return {"profile": profile}

    picked, rationale = [], {}
    for item in out.get("topics", []):
        code = item.get("code", "")
        if code in registry.topic_codes:
            picked.append(code)
            rationale[code] = item.get("evidence", "")

    profile["declared_topics"] = picked
    profile["topic_rationale"] = rationale
    profile["title_scope_conflict"] = not out.get("title_matches_scope", True)
    profile["conflict_note"] = out.get("conflict_note", "")
    if progress:
        progress(f"  seçilen konular: {', '.join(picked) or '(yok)'}")
    return {"profile": profile}


# ------------------------------------------------------------------- node 3
GUARD_SYSTEM = (
    "You audit a topic-selection decision. For each topic that was NOT "
    "selected, decide whether it genuinely falls outside the document's "
    "declared scope. Models under-select; your job is to catch what was "
    "wrongly left out, not to add topics the document merely mentions. "
    "Write `reason` in Turkish."
)

GUARD_SCHEMA = {
    "type": "object",
    "properties": {
        "add": {"type": "array", "items": {
            "type": "object",
            "properties": {"code": {"type": "string"}, "reason": {"type": "string"}},
            "required": ["code", "reason"],
        }}
    },
    "required": ["add"],
}


def recall_guard(state: DocumentState, client: LLMClient,
                 registry: Registry, cfg: Config, progress=None) -> DocumentState:
    """Second pass over the near-miss topics. One extra call, and it is the
    cheapest insurance against the failure mode that matters here: a whole
    subject area silently dropping out of the candidate set."""
    profile = dict(state["profile"])
    selected = set(profile["declared_topics"])
    text = tr_lower(" ".join(profile.get("_lead", []) + profile.get("_headings", [])))

    near_miss = []
    for topic in registry.topics:
        if topic.code in selected:
            continue
        words = [w for w in re.split(r"[^a-zçğıöşü]+", topic.code) if len(w) > 4]
        if any(w in text for w in words):
            near_miss.append(topic)
    near_miss = near_miss[:8]
    if not near_miss:
        if progress:
            progress("  ek konu kontrolü: sınırda konu yok, atlanıyor.")
        return {"profile": profile}
    if progress:
        progress(f"  ek konu kontrolü: {len(near_miss)} sınırda konu inceleniyor...")

    prefix = "DOCUMENT SCOPE\n--------------\n" + "\n".join(profile.get("_lead", []))
    suffix = (
        "Already selected: " + ", ".join(sorted(selected)) + "\n\n"
        "Not selected, but close to the wording of this document:\n"
        + "\n".join(f"{t.code}\n    {t.definition}" for t in near_miss)
        + "\n\nList only the codes that were wrongly left out. Return an empty "
          "list if the exclusions are all correct."
    )

    try:
        out = client.complete_json(GUARD_SYSTEM, prefix, suffix, GUARD_SCHEMA,
                                   temperature=cfg.llm.temperature_extract)
    except Exception as exc:                                    # noqa: BLE001
        if progress:
            progress(f"  ek konu kontrolü: model hatası ({type(exc).__name__}), atlandı.")
        return {"profile": profile}
    added = []
    for item in out.get("add", []):
        code = item.get("code", "")
        if code in registry.topic_codes and code not in selected:
            selected.add(code)
            profile["topic_rationale"][code] = "[ek konu kontrolü] " + item.get("reason", "")
            added.append(code)

    profile["declared_topics"] = sorted(selected)
    if progress:
        progress(f"  ek konu kontrolü: eklenen konular: {', '.join(added) or '(yok)'}")
    return {"profile": profile}


# ------------------------------------------------------------------- node 4
def expand_requirements(state: DocumentState, registry: Registry,
                        cfg: Config) -> DocumentState:
    """Topics to requirement ids and rings. Pure table lookup, no model."""
    candidates = registry.candidates(state["profile"]["declared_topics"])

    kept: list = []
    unresolved: list[str] = []
    for cand in candidates:
        req = registry.by_id[cand["req_id"]]
        applies = registry.applies(req, cfg.policy.condition_flags)
        if applies is False:
            continue                                   # condition does not hold
        if applies is None:
            unresolved.append(f"{req['req_id']} (koşul: {req['condition_code']})")
        kept.append(cand)

    warnings = list(state.get("warnings", []))
    if unresolved:
        warnings.append(
            "Banka profili yanıtı olmayan koşullu gereksinimler, insan incelemesine "
            "yönlendirildi: " + ", ".join(unresolved[:10]))

    if state["profile"].get("_topic_error"):
        warnings.append(state["profile"]["_topic_error"])

    if state["profile"]["title_scope_conflict"]:
        warnings.append(
            "Başlık ile belirtilen kapsam çelişiyor: " + state["profile"]["conflict_note"])

    if len(state["profile"]["languages"]) > 1:
        warnings.append(
            "Çok dilli belge (" + ", ".join(state["profile"]["languages"]) +
            "); her iki sürüm de tek metin olarak değerlendiriliyor.")

    return {"candidates": kept, "warnings": warnings}
