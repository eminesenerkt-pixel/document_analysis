# -*- coding: utf-8 -*-
"""Node: check_metadata — the universal ring, decided by rules.

Five of the eight document-control requirements are purely formal: is there a
document code, was it approved at the right level, is the yearly review
unconditional. Asking a model would add cost and a hallucination surface for
no gain. The three semantic ones stay with the LLM evaluator.
"""
from __future__ import annotations
import re

from ..config import Config
from ..directory import lookup_person
from ..state import DocumentState, Finding
from ..verify import tr_lower

BOARD = r"yönetim kurulu|yonetim kurulu|\byk\b|denetim komitesi|board of directors"
DELEGATION = (r"yetki dev|devredil|yetkilendiril|karar[ıi]? ile|"
              r"yönetim kurulu'?nun .{0,40}karar|delegat")

ANNUAL = r"y[ıi]lda en az bir|en az y[ıi]lda bir|y[ıi]ll[ıi]k olarak|her y[ıi]l|at least once a year"
CONDITIONAL = (r"gerekmesi durumunda|gerekli görülmesi|ihtiyaç duyulmas|"
               r"aksi h[âa]llerde|uygun görülürse|if needed|where necessary")
ADVISORY = r"önerilir|onerilir|tavsiye edilir|is recommended"
LONGER = r"iki y[ıi]lda bir|üç y[ıi]lda bir|2 y[ıi]lda|every two years"

RULE_BACKED = {"REQ-5.2.b", "REQ-5.3", "REQ-5.4.b", "REQ-5.5.a", "REQ-5.5.b"}


def _finding(document_id: str, req_id: str, verdict: str, confidence: float,
             rationale: str, missing: list[str] | None = None,
             evidence_text: str = "") -> Finding:
    return {
        "document_id": document_id, "req_id": req_id, "ring": "universal",
        "verdict": verdict, "confidence": confidence,
        "evidence": ([{"block_id": "metadata", "quote": evidence_text,
                       "verified": True, "reason": "kural tabanlı"}]
                     if evidence_text else []),
        "missing_elements": missing or [], "referenced_document": "",
        "rationale": rationale, "samples_agreed": 1, "challenged": False,
        "recommendation": "",
    }


def _review_statement(blocks) -> str:
    for b in blocks:
        if b["type"] == "table" and re.search(r"revizyon tarihi|revision date|gözden geçir",
                                              b["text"], re.I):
            return b["text"]
    for b in blocks:
        if re.search(r"gözden geçir|reviewed at least", b["text"], re.I):
            return b["text"]
    return ""


def _revision_table(blocks):
    """A real revision history has at least three columns and separate
    version and date columns. The 'document owner | next revision date' table
    matches both words in one cell and must not be mistaken for it."""
    for b in blocks:
        if b["type"] != "table" or "\n" not in b["text"]:
            continue
        rows = [r.split(" | ") for r in b["text"].split("\n") if r.strip() != ""]
        rows = [r for r in rows if not all(c.strip() in ("---", "") for c in r)]
        if not rows or len(rows[0]) < 3:
            continue
        head = [tr_lower(c) for c in rows[0]]
        v = next((i for i, c in enumerate(head)
                  if re.search(r"sürüm|surum|versiyon|rev\.? ?no|version", c)), None)
        d = next((i for i, c in enumerate(head) if re.search(r"tarih|date", c)), None)
        if v is None or d is None or v == d:
            continue
        return rows[0], rows[1:]
    return None, None


def check_metadata(state: DocumentState, cfg: Config, progress=None) -> DocumentState:
    profile = state["profile"]
    blocks = state["blocks"]
    doc_id = state["document_id"]
    out: list[Finding] = []
    if progress:
        progress("  evrensel halka (5 kural, tamamen otomatik) kontrol ediliyor...")

    # -- REQ-5.2.b  document code and confidentiality label
    missing = [name for name, value in
               (("doküman kodu", profile["document_code"]),
                ("gizlilik derecesi", profile["confidentiality"]))
               if not value or value.strip() in ("-", "—")]
    out.append(_finding(
        doc_id, "REQ-5.2.b",
        "satisfied" if not missing else ("not_mentioned" if len(missing) == 2 else "partial"),
        0.95,
        "İki alan da mevcut." if not missing else f"Eksik: {', '.join(missing)}.",
        missing,
        f"kod={profile['document_code'] or '—'}, "
        f"gizlilik={profile['confidentiality'] or '—'}"))

    # -- REQ-5.3  approval authority must match document class
    approver = tr_lower(profile["approver"] or "")
    context = tr_lower(" ".join(b["text"] for b in blocks[:20]))
    by_board = bool(re.search(BOARD, approver))
    delegated = bool(re.search(DELEGATION, approver + " " + context))

    if not approver.strip() or approver.strip() in ("-", "—"):
        v, c, why = "not_mentioned", 0.95, "Onay makamı belirtilmemiş."
    elif profile["document_class"] == "policy":
        v, c, why = (("satisfied", 0.9, "Politika, yönetim kurulu tarafından onaylanmış.")
                     if by_board else
                     ("contradicted", 0.85,
                      "Politika sınıfındaki belge, yönetim kurulu seviyesinin altında onaylanmış."))
    elif profile["document_class"] == "procedure":
        v, c, why = (("satisfied", 0.85,
                      "Prosedür, yönetim kurulu tarafından ya da belirtilen bir yetki devriyle onaylanmış.")
                     if (by_board or delegated) else
                     ("partial", 0.75,
                      "Yetki devri belirtilmeden yönetim kurulu seviyesinin altında onaylanmış."))
    else:
        v, c, why = "needs_review", 0.3, "Belge sınıfı başlıktan okunamadı."
    class_tr = {"policy": "politika", "procedure": "prosedür"}.get(
        profile["document_class"], "belirsiz")
    out.append(_finding(doc_id, "REQ-5.3", v, c, why, evidence_text=
                        f"sınıf={class_tr}, onaylayan={profile['approver'] or '—'}"))

    # -- REQ-5.4.b  document owner
    out.append(_finding(
        doc_id, "REQ-5.4.b",
        "satisfied" if profile["owner"] else "not_mentioned", 0.9,
        "Doküman sahibi belirtilmiş." if profile["owner"] else "Doküman sahibi belirtilmemiş.",
        [] if profile["owner"] else ["doküman sahibi"],
        f"sahip={profile['owner'] or '—'}"))

    # -- REQ-5.5.a  yearly review, stated unconditionally
    stmt = _review_statement(blocks)
    low = tr_lower(stmt)
    sentences = [s for s in re.split(r"(?<=[.!?])\s+", stmt)
                 if re.search(r"gözden geçir|reviewed", s, re.I)]
    scoped = " ".join(sentences) if sentences else stmt

    if not stmt:
        v, c, why = "not_mentioned", 0.85, "Gözden geçirme ifadesi bulunamadı."
    elif re.search(LONGER, low) or re.search(ADVISORY, low):
        v, c, why = ("partial", 0.85,
                     "Gözden geçirme süresi bir yıldan uzun, ya da bir öneri olarak ifade edilmiş.")
    elif re.search(ANNUAL, low):
        # A condition attached to 'revise' does not weaken 'review'.
        clauses = re.split(r"\bve\b|\band\b|[;,]", tr_lower(scoped))
        bound = any(re.search(CONDITIONAL, cl) and re.search(r"gözden geçir|reviewed", cl)
                    for cl in clauses)
        v, c, why = (("partial", 0.7, "Yıllık gözden geçirme koşula bağlanmış.")
                     if bound else
                     ("satisfied", 0.9, "Yıllık gözden geçirme koşulsuz olarak belirtilmiş."))
    elif re.search(CONDITIONAL, low):
        v, c, why = "contradicted", 0.8, "Gözden geçirme sadece koşula bağlı; yıllık asgari yok."
    else:
        v, c, why = "needs_review", 0.3, "Gözden geçirme ifadesi belirsiz."
    out.append(_finding(doc_id, "REQ-5.5.a", v, c, why, evidence_text=scoped[:240]))

    # -- REQ-5.5.b  revision history with approver and dates
    head, body = _revision_table(blocks)
    if head is None:
        out.append(_finding(doc_id, "REQ-5.5.b", "not_mentioned", 0.9,
                            "Revizyon geçmişi tablosu bulunamadı.",
                            ["önceki sürüm", "onaylayan", "revizyon tarihi"]))
    else:
        gaps = []
        joined = tr_lower(" ".join(head))
        if not re.search(r"onayla|approv", joined):
            gaps.append("onaylayan sütunu")
        for i, name in enumerate(head):
            values = [r[i].strip() for r in body if i < len(r)]
            if values and all(x in ("", "-", "—", "n/a") for x in values):
                gaps.append(f"{name} (sütun var, değerler boş)")
        if len(body) < 2:
            gaps.append("önceki sürüm kaydı yok")
        out.append(_finding(
            doc_id, "REQ-5.5.b",
            "satisfied" if not gaps else "partial", 0.85,
            "Revizyon geçmişi eksiksiz." if not gaps else f"Eksikler: {', '.join(gaps)}.",
            gaps, f"{' | '.join(head)} ({len(body)} kayıt)"))

    warnings = list(state.get("warnings", [])) + _directory_warnings(profile, cfg)
    return {"findings": out, "warnings": warnings}


def _directory_warnings(profile: dict, cfg: Config) -> list[str]:
    """Cross-check approver/owner against the corporate directory (AD).

    Off (cfg.ldap.enabled=False) by default — see config.py:LDAPConfig.
    A miss or a disabled account is flagged for a human to look at; it is
    never turned into a verdict of its own; a name match only means an
    active account by that name exists, not that they personally signed
    this document.
    """
    if not cfg.ldap.enabled:
        return []

    out: list[str] = []
    for role, name in (("approver", profile.get("approver", "")),
                       ("owner", profile.get("owner", "")),
                       ("yürürlük onayı", profile.get("enactment_approver", ""))):
        name = (name or "").strip()
        if not name or name in ("-", "—"):
            continue
        result = lookup_person(name, cfg.ldap)
        if result is None:
            out.append(f"AD sorgusu yapılamadı ({role}: {name}) — "
                       "bağlantı/servis hesabı kontrol edilmeli.")
        elif not result["found"]:
            out.append(f"'{name}' ({role}) kurumsal dizinde (AD) bulunamadı — "
                       "gerçek/yetkili bir kişi mi elle doğrulanmalı.")
        elif result.get("multiple_matches"):
            out.append(f"'{name}' ({role}) AD'de birden fazla hesapla eşleşti — "
                       "hangisi olduğu elle doğrulanmalı.")
        elif result.get("account_enabled") is False:
            out.append(f"'{name}' ({role}) AD'de bulundu ama hesabı DEVRE DIŞI — "
                       "ayrılmış/pasif bir kişi mi kontrol edilmeli.")
    return out
