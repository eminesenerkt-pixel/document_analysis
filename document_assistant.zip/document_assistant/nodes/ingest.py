# -*- coding: utf-8 -*-
"""Node: ingest — Word file to blocks. No LLM."""
from __future__ import annotations
import hashlib
from pathlib import Path

from ..config import Config
from ..llm import estimate_tokens
from ..state import DocumentState
from ..extract import extract


def ingest(state: DocumentState, cfg: Config, progress=None) -> DocumentState:
    path = Path(state["path"])
    if progress:
        progress(f"  {path.name}: belge içeriği ayrıştırılıyor...")
    try:
        data = extract(path, tracked_changes=cfg.policy.tracked_changes)
    except Exception as exc:                                  # noqa: BLE001
        return {"error": f"belge ayrıştırma hatası: {type(exc).__name__}: {exc}",
                "blocks": [], "markdown": "", "warnings": []}

    markdown = data["markdown"]
    warnings = list(data["warnings"])

    if data["comments"]:
        warnings.append(
            f"{len(data['comments'])} adet Word yorumu var; gövde metninden ayrı "
            f"tutuldu ve listelendi.")

    tokens = estimate_tokens(markdown)
    if tokens > cfg.policy.max_document_tokens:
        warnings.append(
            f"belge büyük (tahmini {tokens} token); ikinci kontrol (belge → BSEB) "
            f"belgeyi parçalara bölerek tarar.")

    return {
        "document_id": path.stem,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest()[:16],
        "blocks": data["blocks"],
        "markdown": markdown,
        "warnings": warnings,
        "token_estimate": tokens,
        "retry_count": {},
        "error": "",
    }
