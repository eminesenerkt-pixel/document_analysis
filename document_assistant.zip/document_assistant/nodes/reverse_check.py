# -*- coding: utf-8 -*-
"""Node: reverse_check — belge → BSEB yönünde, BAĞIMSIZ bir ikinci kontrol.

Boru hattının geri kalanı (check_metadata + evaluate_core/border) hep TEK
yönde sorar: "bu BSEB maddesi burada karşılanıyor mu?" — ve bu soru sadece
select_topics'in bu belgeye uygun gördüğü konulardaki adaylar için sorulur.
Bir bölüm yanlış konuya sınıflandırılırsa, ya da hata o konunun dışında bir
yerdeyse, o hata iş akışına hiç girmez.

Bu düğüm soruyu TERSİNE ÇEVİRİR: konu sınıflandırmasına hiç bakmadan,
belgenin TÜM metnini BSEB'in TÜM maddeleriyle karşılaştırıp "bu ifade
BSEB'e aykırı mı?" diye sorar — hatanın türü ne olursa olsun. Bilinçli
olarak "requirements pushed, not retrieved" ilkesinin dışında: burada amaç
zaten konu eşleşmesini es geçip bağımsız bir güvenlik ağı kurmak.

İki kontrol birbirinin YERİNE değil, YANINA konur — sonuçları ayrı ayrı
gösterilir (bkz. state.py: DocumentState.reverse_findings), üst üste
yazılmaz.

Belge TEK bir çağrıda değil, PARÇA PARÇA taranır (bkz. _chunk_blocks):
belgenin tamamını 255 maddenin tamamıyla aynı anda tutmak, modelin dikkatini
küçük bir belgede bile dağıtabilecek bir çapraz-referans yüküdür — her
parçaya kendi çağrısında tam dikkat verilir. `max_document_tokens` alanının
vaat ettiği ama hiçbir yerde uygulanmamış "başlık bazlı bölümleme" fikri de
(bkz. nodes/ingest.py'deki uyarı metni) burada karşılığını buluyor.

register'IN KENDİSİ DE gruplara bölünür (bkz. _chunk_list): 255 satırlık
tam liste tek başına ~8000 token — bu kurumun gateway'inde (context penceresi
16384) bunu HER belge parçasıyla birlikte tekrar tekrar göndermek, thinking'e
(bkz. llm.py disable_thinking=False) neredeyse hiç yer bırakmıyordu. Her
(belge parçası × kural grubu) çifti kendi çağrısını alır — hiçbir kural
atlanmaz, sadece aynı anda görülen kural sayısı küçülür. Bedeli: çağrı sayısı
parça sayısı × grup sayısı kadar çarpımsal artar.
"""
from __future__ import annotations

from ..config import Config
from ..extract import to_markdown
from ..llm import LLMClient
from ..registry import Registry
from ..state import Block, DocumentState, Finding
from ..verify import find_quote, normalize

REVERSE_SYSTEM = """You review one excerpt of a bank policy/procedure document, checking it
against one batch of a much larger regulatory requirement register (the full register is
checked across many such batches — none of it is skipped by topic, only split for you to read
carefully) — this is the OPPOSITE direction from a normal compliance check. Instead of asking
"is requirement X satisfied somewhere in this document?", you ask: "does anything this excerpt
actually SAYS violate, contradict, or fall short of any requirement in THIS batch — regardless
of which subject area the document was classified under?"

This exists specifically to catch what a topic-based check would miss: a wrong number, a
contradictory internal statement, a paragraph in a section nobody thought to check against
this particular rule. You are not filtered to any pre-selected subset of the batch — read the
whole excerpt and weigh it against every requirement below. The error can be of ANY kind — do
not limit yourself to the patterns below, they only illustrate how easy it is to read past a
violation on a quick pass:
  - a NEGATION FLIPPED: the sentence states the opposite of what the rule requires (e.g. "may
    be used without approval" where the rule requires approval) — reads as on-topic and fluent,
    so it is easy to skim past without registering that the polarity is backwards.
  - a COMMITMENT QUIETLY WEAKENED: a specific, measurable obligation (a frequency, a deadline,
    a threshold) restated in vaguer terms that no longer actually satisfy it (e.g. "at least
    once a year" softened to "from time to time", or a fixed number replaced by "as needed").
  - a WRONG NUMBER OR PARTY: a threshold, percentage or named role that does not match what the
    rule requires.
Read every sentence for what it actually asserts, not just whether it is on-topic. The excerpt
is one slice of a larger document — do not flag the absence of something that could plausibly
be covered elsewhere in it; only flag text that is actively present and wrong.

Only report a genuine, specific textual conflict: quote the exact sentence, verbatim, exactly
as it appears in the document, and put the exact requirement id in the `req_id` field. Do not
report a requirement simply being unaddressed — that is a different, existing check. Only
report where the document ACTIVELY SAYS something that is wrong.

The reader of `reason` is a compliance reviewer, not a developer — they never see requirement
ids or codes, only the regulation's own article text. Never mention a requirement id (e.g.
"REQ-4.1.a") inside `reason`; describe what the regulation requires in plain words instead.
Write `reason` in Turkish."""

REVERSE_SCHEMA = {
    "type": "object",
    "properties": {
        "violations": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "req_id": {"type": "string"},
                "quote": {"type": "string"},
                "reason": {"type": "string"},
            },
            "required": ["req_id", "quote", "reason"],
        }},
    },
    "required": ["violations"],
}


def _condensed_register(requirements: list) -> str:
    return "\n".join(f"{r['req_id']} ({r['article']}): {r['text']}"
                     for r in requirements)


def _chunk_blocks(blocks: list[Block], target_chars: int) -> list[list[Block]]:
    """Greedy split, never inside a block. A document under `target_chars`
    stays a single chunk — this is a cross-referencing aid for the model,
    not a policy that every document must be split."""
    chunks: list[list[Block]] = []
    current: list[Block] = []
    current_len = 0
    for b in blocks:
        b_len = len(b.get("text", ""))
        if current and current_len + b_len > target_chars:
            chunks.append(current)
            current, current_len = [], 0
        current.append(b)
        current_len += b_len
    if current:
        chunks.append(current)
    return chunks


def _chunk_list(items: list, size: int) -> list[list]:
    return [items[i:i + size] for i in range(0, len(items), size)]


def _resolve_req_id(raw: str, registry: Registry) -> str | None:
    """The model is not constrained to an enum of real ids (255 of them,
    schema-enum size is a real risk on some gateways), so it can echo one
    back slightly off — a dropped sub-letter (REQ-4.1 for REQ-4.1.a), stray
    whitespace, wrong case. Silently discarding anything that doesn't match
    byte-for-byte would throw away a genuine catch and look, from the
    outside, exactly like the model finding nothing at all. Try a normalized
    and then a prefix match before giving up."""
    raw = (raw or "").strip()
    if raw in registry.by_id:
        return raw
    norm = raw.upper().replace(" ", "")
    for rid in registry.by_id:
        if rid.upper().replace(" ", "") == norm:
            return rid
    prefix_hits = [rid for rid in registry.by_id if rid.upper().startswith(norm)]
    if len(prefix_hits) == 1:
        return prefix_hits[0]
    return None


def reverse_check(state: DocumentState, client: LLMClient, registry: Registry,
                  cfg: Config, progress=None) -> DocumentState:
    body_blocks = [b for b in state["blocks"] if b["source"] not in ("header", "footer")]
    doc_chunks = _chunk_blocks(body_blocks, cfg.policy.reverse_check_chunk_chars)
    # A requirement whose bank-profile condition is answered "no" does not
    # apply to this bank at all — sending it would only invite false
    # "contradictions". Unanswered (None) conditions stay in.
    applicable = [r for r in registry.requirements
                  if registry.applies(r, cfg.policy.condition_flags) is not False]
    rule_batches = _chunk_list(applicable, cfg.policy.reverse_check_rules_per_batch)
    n_chunks, n_batches = len(doc_chunks), len(rule_batches)
    total_calls = n_chunks * n_batches

    if progress:
        if total_calls > 1:
            progress(f"  ikinci kontrol: belge → BSEB, {n_chunks} belge parçası × "
                     f"{n_batches} kural grubu = {total_calls} çağrı...")
        else:
            progress("  ikinci kontrol: belge → BSEB, tüm metin tüm maddelere karşı taranıyor...")

    findings: list[Finding] = []
    seen: set[tuple[str, str]] = set()          # (req_id, normalized quote)
    failed_calls = 0
    call_no = 0
    # Kural grubu DIŞ döngüde: aynı register grubu (prefix, sabit) art arda
    # birden çok belge parçasına (suffix, değişen) karşı kullanılır — hem
    # LLMClient.complete_json'ın belgelediği prefix-cache kuralına uyar, hem
    # de bu grup aynı koşuda BAŞKA belgeler için de birebir aynı kalır
    # (registry değişmez), yani cache kazancı tek belgeyle sınırlı kalmaz.
    for bi, rule_batch in enumerate(rule_batches):
        batch_label = f"grup {bi + 1}/{n_batches}" if n_batches > 1 else "TAMAMI"
        register_prefix = (f"BSEB MADDE LİSTESİ ({batch_label}, {len(rule_batch)} madde)\n"
                          + "-" * 40 + "\n" + _condensed_register(rule_batch))

        for ci, chunk_blocks in enumerate(doc_chunks):
            call_no += 1
            chunk_md = to_markdown(chunk_blocks, include_header_footer=False)
            doc_label = f"BELGE (parça {ci + 1}/{n_chunks})" if n_chunks > 1 else "BELGE"
            suffix = (f"{doc_label}\n-----\n{chunk_md}\n\n"
                     "Yukarıdaki maddelerden herhangi birine aykırı, bu belge parçasında "
                     "GERÇEKTEN yazan bir ifade var mı?")
            if progress and total_calls > 1:
                progress(f"    çağrı {call_no}/{total_calls} (kural {batch_label}, "
                         f"belge parça {ci + 1}/{n_chunks}) taranıyor...")
            # Bu, tek bir dar soruyu değil, bu parçayı bu kural grubunun
            # TAMAMINA karşı tartmayı istiyor — geri kalan boru hattındaki
            # "bu tek madde burada karşılanmış mı?" sorularından çok daha zor
            # bir çapraz referans görevi. Thinking'i burada özellikle
            # AÇIYORUZ (cfg'nin genel disable_thinking=True varsayılanının
            # aksine); register artık gruplara bölündüğü için bu, önceki
            # (bölünmemiş) haline göre çok daha rahat bir bütçeyle mümkün.
            try:
                out = client.complete_json(REVERSE_SYSTEM, register_prefix, suffix, REVERSE_SCHEMA,
                                           temperature=cfg.llm.temperature_judge,
                                           disable_thinking=False, max_tokens=6000)
            except Exception as exc:                            # noqa: BLE001
                failed_calls += 1
                if progress:
                    progress(f"      -> çağrı başarısız ({type(exc).__name__}), bu parça atlandı")
                continue

            raw_violations = out.get("violations", [])
            if progress and raw_violations:
                progress(f"      -> {len(raw_violations)} olası aykırılık bildirdi, "
                         "doğrulanıyor...")

            for v in raw_violations:
                raw_req_id = v.get("req_id", "")
                req_id = _resolve_req_id(raw_req_id, registry)
                if req_id is None:
                    if progress:
                        progress(f"      -> uyarı: model '{raw_req_id}' madde no bildirdi "
                                 "ama kayıtta eşleşen madde yok, bu bulgu atlandı")
                    continue
                quote = v.get("quote", "")
                key = (req_id, normalize(quote))
                if key in seen:
                    continue                    # same catch from another chunk/batch
                seen.add(key)
                ok, block_id = find_quote(state["blocks"], quote)
                findings.append({
                    "document_id": state["document_id"], "req_id": req_id, "ring": "reverse",
                    "verdict": "contradicted" if ok else "needs_review",
                    "confidence": 0.75 if ok else 0.3,
                    "evidence": [{"block_id": block_id, "quote": quote, "verified": ok,
                                 "reason": "birebir doğrulandı" if ok else "alıntı belgede bulunamadı"}],
                    "missing_elements": [], "referenced_document": "",
                    "rationale": v.get("reason", ""), "samples_agreed": 1,
                    "challenged": False, "recommendation": "",
                })
                if progress:
                    progress(f"      -> {req_id}: "
                             f"{'aykırılık bulundu' if ok else 'alıntı doğrulanamadı, needs_review'}")

    if progress and not findings:
        progress("    -> ikinci kontrol: aykırılık bulunamadı")

    out_state: DocumentState = {"reverse_findings": findings}
    if failed_calls:
        # Runs in parallel only with profile_document, which never writes
        # `warnings`, so this does not collide with another branch's update.
        out_state["warnings"] = list(state.get("warnings", [])) + [
            f"İkinci kontrol (belge → BSEB): {failed_calls}/{total_calls} model çağrısı "
            "başarısız oldu; bu kontrolün sonucu eksik olabilir."]
    return out_state
