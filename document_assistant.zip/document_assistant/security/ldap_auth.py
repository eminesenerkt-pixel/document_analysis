# -*- coding: utf-8 -*-
"""
app/security/ldap_auth.py
────────────────────────────────────────────────────────────────────
GÖREV: Kurumsal LDAP/AD'ye karşı kimlik doğrulamak.

`Agentic_AI_KT/backend/core/ldap_auth.py`'den uyarlanmıştır (KT'nin
FastAPI tabanlı kardeş projesi, orada LDAP + JWT ile canlıda çalışıyor).
Buradaki fark: Flask senkron çalışır, JWT üretmez — bu modül yalnızca
"kullanıcı adı+parola doğru mu, rolü ne?" sorusuna cevap verir; kimliğin
oturumda nasıl taşınacağı `access_control.py`/`guards.py`'nin işidir.

`ldap3` paketi yalnızca bu modül İÇİNDE, yalnızca `authenticate()`
ÇAĞRILDIĞINDA import edilir — `settings.ldap.enabled=False` olan (demo)
kurulumlarda paket kurulu olmasa bile uygulama açılır.

AKIŞ:
  1) Servis hesabıyla (LDAP_BIND_DN/PASSWORD) bağlan.
  2) LDAP_USER_SEARCH_FILTER ile kullanıcıyı ara, DN'ini bul.
  3) Bulunan DN'e kullanıcının KENDİ parolasıyla bağlanmayı dene —
     bu adım geçerse kimlik doğrulanmış demektir (parola hiç saklanmaz).
  4) `memberOf` grup listesini LDAP_ROLE_MAPPING ile role çevir.
────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import logging
import time
from typing import List, Optional

from config.settings import settings

logger = logging.getLogger(__name__)


def _map_role(member_of: List[str]) -> str:
    """LDAP grup DN'lerini uygulama rolüne çevirir (tam eşleşme → alt-dize → varsayılan)."""
    mapping = settings.ldap.role_mapping
    for group_dn in member_of:
        if group_dn in mapping:
            return mapping[group_dn]
    for group_dn in member_of:
        for ldap_group, app_role in mapping.items():
            if ldap_group.lower() in group_dn.lower():
                return app_role
    return settings.ldap.default_role


def _first(values) -> str:
    return values[0] if values else ""


def authenticate(username: str, password: str) -> Optional[dict]:
    """LDAP'a karşı doğrular. Başarılıysa `User` alanlarına uygun dict, değilse `None`.

    Dönen sözlük: {"username", "display_name", "role", "team"}.
    Sebep ne olursa olsun (kullanıcı yok, parola yanlış, sunucuya
    ulaşılamadı) `None` döner — çağıran taraf tek bir hata mesajı
    gösterir, LDAP'ın iç detaylarını kullanıcıya sızdırmaz.
    """
    try:
        from ldap3 import ALL, SUBTREE, Connection, Server
        from ldap3.core.exceptions import LDAPBindError, LDAPException, LDAPSocketOpenError
    except ImportError:
        logger.error("USE_LDAP_AUTH açık ama 'ldap3' paketi kurulu değil "
                     "(pip install ldap3).")
        return None

    username = (username or "").strip()
    if not username or not password:
        return None

    def build_server() -> "Server":
        return Server(settings.ldap.server_uri, get_info=ALL,
                      use_ssl=settings.ldap.use_ssl,
                      connect_timeout=settings.ldap.connect_timeout)

    # ── 1) servis hesabıyla bağlan (yeniden denemeli) ──────────────
    service_conn = None
    last_error: Exception | None = None
    for attempt in range(1, settings.ldap.max_retries + 1):
        try:
            service_conn = Connection(
                build_server(), user=settings.ldap.bind_dn,
                password=settings.ldap.bind_password, auto_bind=True,
                receive_timeout=settings.ldap.receive_timeout)
            break
        except (LDAPSocketOpenError, OSError) as error:
            last_error = error
            logger.warning("LDAP servis bağlantısı denemesi %s/%s başarısız: %s",
                           attempt, settings.ldap.max_retries, error)
            if attempt < settings.ldap.max_retries:
                time.sleep(settings.ldap.retry_delay)
        except LDAPException as error:
            logger.error("LDAP servis bağlantısı kurulamadı: %s", error)
            return None

    if service_conn is None:
        logger.error("LDAP servis bağlantısı %s denemeden sonra başarısız: %s",
                     settings.ldap.max_retries, last_error)
        return None

    # ── 2) kullanıcıyı ara ─────────────────────────────────────────
    try:
        search_filter = settings.ldap.user_search_filter.replace("{username}", username)
        service_conn.search(
            search_base=settings.ldap.user_search_base,
            search_filter=search_filter, search_scope=SUBTREE,
            attributes=settings.ldap.user_attributes)
        if not service_conn.entries:
            logger.warning("LDAP'ta kullanıcı bulunamadı: %s", username)
            return None
        entry = service_conn.entries[0]
        user_dn = entry.entry_dn
        user_attrs = entry.entry_attributes_as_dict
    finally:
        service_conn.unbind()

    # ── 3) kullanıcının kendi parolasıyla doğrula ──────────────────
    try:
        user_conn = Connection(build_server(), user=user_dn, password=password,
                               receive_timeout=settings.ldap.receive_timeout)
        if not user_conn.bind():
            logger.warning("LDAP parola doğrulaması başarısız: %s", username)
            return None
        user_conn.unbind()
    except LDAPBindError:
        logger.warning("LDAP parola doğrulaması başarısız: %s", username)
        return None
    except (LDAPSocketOpenError, OSError) as error:
        logger.error("LDAP doğrulama bağlantısı kurulamadı (%s): %s", user_dn, error)
        return None
    except LDAPException as error:
        logger.error("LDAP doğrulama hatası (%s): %s", user_dn, error)
        return None

    # ── 4) kullanıcı bilgisini + rolü çıkar ────────────────────────
    # KİMLİK ANAHTARI olarak GİRİLEN metin DEĞİL, LDAP'ın döndürdüğü
    # SABİT öznitelik kullanılır (öncelik: mail → sAMAccountName → uid).
    # NEDEN ÖNEMLİ: konuşma geçmişi bu değere göre klasörlenir
    # (core/conversations/store.py: data/conversations/<bu-değer>/...).
    # Kullanıcı bir gün "Ali.Kaya@kt.com", ertesi gün "ali.kaya@kt.com"
    # yazarsa LDAP ikisinde de aynı hesabı doğrular ama ham girdiyi
    # anahtar yapsaydık sistem bunları İKİ FARKLI kullanıcı sanır,
    # kişi dünkü konuşmalarını kaybetmiş gibi görürdü.
    stable_username = (_first(user_attrs.get("mail", []))
                       or _first(user_attrs.get("sAMAccountName", []))
                       or _first(user_attrs.get("uid", []))
                       or username).strip().lower()
    display_name = (_first(user_attrs.get("displayName", []))
                    or _first(user_attrs.get("cn", [])) or username)
    member_of = user_attrs.get("memberOf", [])
    role = _map_role(member_of)

    logger.info("LDAP kimlik doğrulama başarılı: %s (%s)", stable_username, role)
    return {"username": stable_username, "display_name": display_name,
            "role": role, "team": ""}
