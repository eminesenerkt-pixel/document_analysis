# -*- coding: utf-8 -*-
"""
app/security/guards.py
────────────────────────────────────────────────────────────────────
GÖREV: Rotaları koruyan dekoratörler.

  • login_required     → "giriş yapılmış mı?"
  • section_required   → "bu rol bu bölüme erişebilir mi?"

Ayrım önemli: sohbet geçmişini sıfırlamak gibi bazı uçlar bölüme değil,
yalnızca oturuma bağlıdır.

KİMLİK NASIL ÇÖZÜLÜR: oturum çerezinde SADECE kullanıcı adı değil, giriş
anında doğrulanmış KÜÇÜK bir profil (`User.to_session()`) tutulur; bu
sayede `current_user()` hiçbir sunucu-içi depoya (LDAP dizini, süreç-içi
önbellek) bakmadan, imzalı çerezden doğrudan kurulur. Bu kasıtlı bir
tasarım: uygulama birden fazla gunicorn worker süreciyle çalıştığında bile
kimlik durumsuz kalır — hangi worker isteği alırsa alsın aynı sonucu
üretir. Bedeli: rol/isim bilgisi bir sonraki girişe kadar güncel kalır
(LDAP grubunuz değişirse yeniden giriş yapmanız gerekir) — JWT ile aynı
kabul edilebilir ödünleşim.

API ile sayfa istekleri farklı davranır:
  • sayfa  → giriş ekranına / "yasak" sayfasına yönlendirilir
  • API    → 401/403 JSON döner (arayüz JS'i bunu anlar)

TEK DOĞRULUK KAYNAĞI: erişim matrisi burada değil,
`capabilities/base.py` içindeki bölüm kataloğundadır. Yeni bir bölüm
eklemek ya da bir rolün erişimini değiştirmek için orada tek satır
düzenlenir; burası hiç değişmez.
────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import hmac
from functools import wraps

from flask import g, jsonify, redirect, render_template, request, session, url_for

from capabilities.base import (LIVE_SECTIONS, PERMISSION_LABELS, SECTIONS,
                               can_access, has_permission, resolve_section)
from config.settings import settings
from .access_control import User

SESSION_USER_KEY = "username"


def current_user() -> User | None:
    """Oturumdaki kullanıcı (yoksa None). İstek başına bir kez çözülür."""
    if "user" not in g:
        # NOT: bu satır fotoğrafta görünmüyordu, yeniden kuruldu — kontrol edin.
        g.user = User.from_session(session.get(SESSION_USER_KEY))
    return g.user


def _wants_json() -> bool:
    """İstek API mi? Yanıt biçimini buna göre seçiyoruz."""
    return request.path.startswith("/api/") or request.is_json


def login_required(view):
    """Giriş yapılmamışsa içeri alma."""
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            if _wants_json():
                return jsonify({"error": "unauthenticated",
                                "message": "Oturum sona ermiş. Lütfen tekrar giriş yapın."}), 401
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)
    return wrapper


def section_required(section_key: str):
    """Bölüm bazlı erişim kontrolü.

    Kullanım:
        @section_required("team")
        def team_page(): ...
    """
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapper(*args, **kwargs):
            user = current_user()
            if not can_access(user.role, section_key):
                key = resolve_section(section_key)
                definition = SECTIONS.get(key)
                name = definition.name if definition else section_key
                # İki farklı sebep aynı 403'ü üretir — mesaj YANLIŞ olanı
                # söylemesin: rolün zaten erişimi olan bir bölüm için
                # "rolünüz yetkisiz" demek kullanıcıyı yanlış yere gönderir.
                if key not in LIVE_SECTIONS:
                    message = f"{name} bölümü henüz yayında değil."
                else:
                    message = f"{name} bölümü rolünüzün erişimi dışında."
                # NOT: 96-99. satırlar fotoğrafta görünmüyordu, yeniden kuruldu.
                if _wants_json():
                    return jsonify({"error": "forbidden",
                                    "section": key,
                                    "message": message}), 403
                return render_template("forbidden.html", user=user,
                                       section=definition, message=message), 403
            return view(*args, **kwargs)
        return wrapper
    return decorator


def permission_required(permission: str):
    """Eylem bazlı yetki kontrolü.

    Bölüm kontrolünden farkı: kullanıcı ekranı görebiliyor olabilir ama
    o ekrandaki BİR EYLEMİ yapamayabilir (örneğin kurum dışına posta
    göndermek). Arayüz düğmeyi gizler; burası kapıyı kapatır.

        @permission_required(PERM_ALERT_MAIL)
        def send_mail(): ...
    """
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapper(*args, **kwargs):
            user = current_user()
            if not has_permission(user.role, permission):
                label = PERMISSION_LABELS.get(permission, permission)
                message = (f"Bu işlem için yetkiniz yok: {label}. "
                           f"Rolünüz: {user.role}.")
                if _wants_json():
                    return jsonify({"error": "forbidden",
                                    "permission": permission,
                                    "message": message}), 403
                return render_template("forbidden.html", user=user,
                                       section=None, message=message), 403
            return view(*args, **kwargs)
        return wrapper
    return decorator


def service_token_required(view):
    """Makine-için-makine uçlarını korur — İNSAN OTURUMUYLA İLGİSİ YOKTUR.

    `login_required`/`section_required`'dan bilerek AYRI: otomasyon
    (ör. `tools/kesinti_izle.py`'nin HTTP karşılığı, kesinti alarmı) bir
    LDAP oturumuyla değil, `.env`'deki `AUTOMATION_API_TOKEN` ile
    doğrulanır. Bu sayede Radar bölümü `LIVE_SECTIONS`'ta insanlara kapalı
    kalırken (henüz tamamlanmadı) otomatik uyarı kontrolü yine çalışabilir
    — ikisi kasıtlı olarak BAĞIMSIZ anahtarlardır, biri diğerini açıp
    kapatmaz.

        @service_token_required
        def incident_scan(): ...

    Token boşsa (yapılandırılmamışsa) uç HER ZAMAN 401 döner — "boş token
    == herkes girsin" güvenlik açığına düşülmez.
    """
    @wraps(view)
    def wrapper(*args, **kwargs):
        expected = settings.automation.service_token
        provided = request.headers.get("X-Service-Token", "")
        if not expected or not hmac.compare_digest(provided, expected):
            return jsonify({"error": "unauthorized",
                            "message": "Geçersiz ya da eksik servis token'ı."}), 401
        return view(*args, **kwargs)
    return wrapper
