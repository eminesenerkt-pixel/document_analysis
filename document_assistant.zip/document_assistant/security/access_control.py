# -*- coding: utf-8 -*-
"""
app/security/access_control.py
────────────────────────────────────────────────────────────────────
GÖREV: Kullanıcı kimliği ve rol bilgisini yönetmek.

Eski `yetki.py`'nin karşılığıdır. İki fark var:
  1) Roller İngilizce: uzman → specialist, yonetici → manager
  2) Yetkinlik erişim matrisi burada DEĞİL, capabilities/base.py'de.
     Böylece "hangi rol neye erişir?" sorusunun tek bir cevabı olur.

Parolalar düz metin tutulmaz; pbkdf2-hmac-sha256 ile özetlenir. Aşağıdaki
depo yalnızca DEMO/geliştirme modu içindir (`USE_LDAP_AUTH=0`, varsayılan).
Kurumsal kurulumda `USE_LDAP_AUTH=1` yapılır; `authenticate()` o zaman bu
depoya hiç bakmaz, `app/security/ldap_auth.py` üzerinden LDAP/AD'ye
bağlanır — bkz. `.env`'deki `LDAP_*` ayarları.
────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import hashlib
import hmac
import os
from dataclasses import dataclass

from capabilities.base import (PERMISSION_LABELS, ROLE_LABELS, ROLE_MANAGER,
                               ROLE_SPECIALIST, permissions_for)
from config.settings import settings

# pbkdf2 parametreleri (demo için makul; üretimde iterasyon artırılabilir)
HASH_ALGORITHM = "sha256"
HASH_ITERATIONS = 120_000
SALT_BYTES = 16


def hash_password(password: str, salt: bytes | None = None) -> str:
    """Parolayı 'salt$digest' biçiminde özetler (hex)."""
    salt = salt or os.urandom(SALT_BYTES)
    digest = hashlib.pbkdf2_hmac(HASH_ALGORITHM, password.encode("utf-8"),
                                 salt, HASH_ITERATIONS)
    return f"{salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    """Parola doğrulaması — zamanlama saldırısına karşı sabit süreli karşılaştırma."""
    try:
        salt_hex, digest_hex = stored.split("$", 1)
    except ValueError:
        return False
    computed = hashlib.pbkdf2_hmac(HASH_ALGORITHM, password.encode("utf-8"),
                                   bytes.fromhex(salt_hex), HASH_ITERATIONS)
    return hmac.compare_digest(computed.hex(), digest_hex)


@dataclass(frozen=True)
class User:
    """Oturum açmış kişi."""
    username: str
    display_name: str
    role: str
    team: str = ""

    @property
    def role_label(self) -> str:
        return ROLE_LABELS.get(self.role, self.role)

    @property
    def permissions(self) -> frozenset:
        """Rolden türeyen yetkiler — arayüz düğmeleri buna göre çizilir."""
        return permissions_for(self.role)

    def can(self, permission: str) -> bool:
        return permission in self.permissions

    def as_dict(self) -> dict:
        return {"username": self.username, "display_name": self.display_name,
                "role": self.role, "role_label": self.role_label,
                "team": self.team,
                "permissions": sorted(self.permissions),
                "permission_labels": [PERMISSION_LABELS.get(item, item)
                                      for item in sorted(self.permissions)]}

    def to_session(self) -> dict:
        """Oturum çerezine yazılacak KÜÇÜK profil (yetkiler DEĞİL — bunlar
        her istekte rolden YENİDEN hesaplanır, bkz. `permissions`)."""
        return {"username": self.username, "display_name": self.display_name,
                "role": self.role, "team": self.team}

    @staticmethod
    def from_session(data: dict) -> "User | None":
        """Oturum çerezinden User kurar. Rol tanınmıyorsa
        güvenli tarafta kal: kullanıcı yok say."""
        role = (data or {}).get("role")
        if role not in (ROLE_SPECIALIST, ROLE_MANAGER):
            return None
        return User(username=data.get("username", ""),
                    display_name=data.get("display_name", ""),
                    role=role, team=data.get("team", ""))


# ────────────────────────────────────────────────────────────────────
# DEMO KULLANICI DEPOSU
# Hepsinin parolası "1234" — ilk açılışta hash'ler üretilir.
# Yeni kullanıcı eklemek için tek satır yeterlidir.
# ────────────────────────────────────────────────────────────────────
DEMO_PASSWORD = "1234"

_USER_RECORDS: dict[str, dict] = {
    "ali.kaya": {"display_name": "Ali Kaya", "role": ROLE_SPECIALIST,
                 "team": "Hizmet Masası"},
    "emre.yildiz": {"display_name": "Emre Yıldız", "role": ROLE_SPECIALIST,
                    "team": "Hizmet Masası"},
    "elif.sahin": {"display_name": "Elif Şahin", "role": ROLE_MANAGER,
                   "team": "BT Yönetimi"},
}

# Parola özetleri modül yüklenirken bir kez hesaplanır.
_PASSWORD_HASHES: dict[str, str] = {
    username: hash_password(DEMO_PASSWORD) for username in _USER_RECORDS
}


def authenticate(username: str, password: str) -> User | None:
    """Kullanıcı adı + parola doğruysa User döndürür, değilse None.

    `USE_LDAP_AUTH=1` ise kurumsal LDAP/AD'ye karşı doğrular (bkz.
    `app/security/ldap_auth.py`); kapalıyken (varsayılan) aşağıdaki demo
    depoya düşer. İki yol da aynı `User` biçimini döndürdüğü için
    çağıran taraf (giriş rotası, oturum) hangisinin çalıştığını bilmek
    zorunda değildir.
    """
    if settings.ldap.enabled:
        from .ldap_auth import authenticate as ldap_authenticate
        record = ldap_authenticate(username, password)
        return User(**record) if record else None

    # ── demo kullanıcı deposu ─────────────────────────────────────
    # Kullanıcı bulunamasa bile sahte bir doğrulama yapılır; böylece
    # "kullanıcı var mı yok mu" bilgisi yanıt süresinden sızmaz.
    username = (username or "").strip().lower()
    record = _USER_RECORDS.get(username)
    stored = _PASSWORD_HASHES.get(username, hash_password("__gecersiz__"))

    if not verify_password(password or "", stored) or record is None:
        return None
    return User(username=username, **record)


def get_user(username: str) -> User | None:
    """Oturumdaki kullanıcı adından User nesnesini tazeler."""
    record = _USER_RECORDS.get((username or "").lower())
    return User(username=username, **record) if record else None


def demo_accounts() -> list[dict]:
    """Giriş ekranında gösterilen demo hesap listesi.

    DİKKAT: Bu liste bir KOLAYLIKTIR, kapı değildir. Parola yine
    girilir ve yine doğrulanır; sadece yazma zahmetini kaldırır.
    Gerçek kurulumda `SHOW_DEMO_ACCOUNTS=0` ile kapatılır.
    """
    if os.getenv("SHOW_DEMO_ACCOUNTS", "1").strip().lower() in ("0", "false", "no"):
        return []
    return [{"username": username, "display_name": record["display_name"],
             "role": record["role"],
             "role_label": ROLE_LABELS.get(record["role"], record["role"]),
             "team": record.get("team", ""),
             "permissions": [PERMISSION_LABELS.get(item, item)
                             for item in sorted(permissions_for(record["role"]))],
             "password": DEMO_PASSWORD}
            for username, record in _USER_RECORDS.items()]
