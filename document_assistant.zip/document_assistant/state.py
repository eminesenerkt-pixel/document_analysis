# -*- coding: utf-8 -*-
"""Graph state and the typed records that flow through it.

Two graphs, two states:

  DocumentState  one document, fanned out over its candidate requirements
  CorpusState    the whole document set, used for reverse scan and reporting
"""
from __future__ import annotations
import operator
from typing import Annotated, Literal, TypedDict

# --------------------------------------------------------------------- enums
Verdict = Literal[
    "satisfied",        # requirement fully met
    "partial",          # addressed, one or more sub-elements missing
    "contradicted",     # document states something contrary to the rule
    "not_mentioned",    # requirement absent from the document
    "satisfied_by_ref", # border ring: delegated to another document, with a valid reference
    "out_of_scope",     # requirement does not apply to this document
    "needs_review",     # model could not decide; goes to a human
]

Ring = Literal["universal", "core", "border", "out_of_scope", "title_conflict"]
DocumentClass = Literal["policy", "procedure", "unknown"]
ObligationForm = Literal["action", "delegation", "prohibition", "authority", "conditional"]


# --------------------------------------------------------------------- records
class Block(TypedDict):
    """One extracted unit of the document. `id` anchors every citation."""
    id: str
    type: Literal["paragraph", "heading", "list", "table", "note"]
    source: Literal["body", "header", "footer", "footnote", "endnote"]
    in_textbox: bool
    text: str


class Requirement(TypedDict):
    """One row of the regulation register."""
    req_id: str
    article: str
    text: str
    source_sentence: str
    control_question: str
    primary_topic: str
    secondary_topics: list[str]
    obligation_form: ObligationForm
    condition_code: str
    universal: bool
    risk_level: str
    sub_elements: list[str]


class Candidate(TypedDict):
    req_id: str
    ring: Ring


class Evidence(TypedDict):
    block_id: str
    quote: str
    verified: bool
    reason: str


class Finding(TypedDict):
    document_id: str
    req_id: str
    ring: Ring
    verdict: Verdict
    confidence: float
    evidence: list[Evidence]
    missing_elements: list[str]
    referenced_document: str        # border ring: which document it defers to
    rationale: str
    samples_agreed: int             # self-consistency agreement count
    challenged: bool                # survived the adversarial pass
    recommendation: str


class DocumentProfile(TypedDict):
    title: str
    document_class: DocumentClass
    document_code: str
    version: str
    effective_date: str
    revision_date: str
    confidentiality: str
    owner: str
    approver: str
    # Some templates carry a THIRD, distinct signatory — a document-control/
    # quality sign-off that a document is officially released — separate
    # from `approver` (the BSEB-governance approval REQ-5.3 asks about).
    enactment_approver: str
    languages: list[str]            # e.g. ["tr", "en"] for bilingual files
    declared_topics: list[str]
    topic_rationale: dict[str, str]
    title_scope_conflict: bool
    conflict_note: str


class DocumentRecord(TypedDict):
    """One document's result, handed up to the corpus graph."""
    document_id: str
    path: str
    sha256: str
    profile: DocumentProfile
    findings: list[Finding]
    # reverse_check'in bulguları — madde→belge değil, belge→BSEB yönünde,
    # konu sınıflandırmasından bağımsız ikinci bir kontrol. `findings`'e
    # KARIŞTIRILMAZ, ayrı gösterilir (bkz. nodes/reverse_check.py).
    reverse_findings: list[Finding]
    warnings: list[str]
    error: str


def _merge_findings(existing: list[Finding], update: list[Finding]) -> list[Finding]:
    """Fan-out branches (check_metadata, evaluate_core/border) each contribute
    one finding for a req_id not seen before -> appended.

    verify_citations and challenge run once, sequentially, AFTER the fan-out
    has joined; each reads the *entire* current findings list and returns it
    back transformed (verdicts downgraded, challenge flags set). Under plain
    operator.add that whole list would be appended again — doubling it, then
    doubling again on the next such node — rather than replacing the entries
    it corrects. Merging by req_id gives the fan-out its additive behaviour
    while letting later whole-list passes overwrite in place."""
    by_id = {f["req_id"]: f for f in existing}
    for f in update:
        by_id[f["req_id"]] = f
    return list(by_id.values())


# --------------------------------------------------------------------- states
class DocumentState(TypedDict, total=False):
    """Per-document graph."""
    document_id: str
    path: str
    sha256: str

    blocks: list[Block]
    markdown: str
    warnings: list[str]
    token_estimate: int

    profile: DocumentProfile
    candidates: list[Candidate]

    # Parallel branches append here; verify_citations/challenge overwrite an
    # existing req_id in place rather than duplicating it (see _merge_findings).
    findings: Annotated[list[Finding], _merge_findings]
    # reverse_check'in tek seferlik çıktısı — ayrı bir listede tutulur ki
    # normal (madde→belge) bulgularının üzerine yazmasın.
    reverse_findings: Annotated[list[Finding], operator.add]
    pending_review: Annotated[list[Finding], operator.add]

    retry_count: dict[str, int]
    error: str


class EvaluationTask(TypedDict):
    """Payload of a single fan-out branch."""
    document_id: str
    markdown: str
    blocks: list[Block]
    requirement: Requirement
    ring: Ring
    samples: int


class CorpusState(TypedDict, total=False):
    """Corpus-level graph: runs the per-document graph, then closes the loop."""
    run_id: str
    document_paths: list[str]

    # Written whole by review_documents, then rewritten by recommend. No
    # reducer: an appending reducer would duplicate every document record.
    documents: list[DocumentRecord]

    covered_requirements: dict[str, list[str]]   # req_id -> [document_id]
    orphan_requirements: list[str]               # no document covers them
    missing_document_types: list[str]

    report_path: str
