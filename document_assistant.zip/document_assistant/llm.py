# -*- coding: utf-8 -*-
"""Corporate LLM client.

Assumes an OpenAI-compatible chat completions endpoint. Two guarantees the
rest of the graph relies on:

  * structured output  — the caller always gets a dict matching its schema,
                         or an explicit failure. No free-form parsing.
  * determinism        — temperature 0 on every judgement call, and the
                         document is placed FIRST in the prompt so the
                         server's prefix cache covers it across the ~255
                         requirement calls made against the same document.

Target model is Qwen3-235B-A22B. Its own model card only forbids greedy
decoding (temperature 0) in *thinking* mode ("can lead to performance
degradation and endless repetitions"); thinking is switched off here
(disable_thinking), so T=0 on judgement calls stays inside the documented
non-thinking-mode behaviour, at the cost of some of the sampling headroom
the card recommends (T=0.7) for general quality. Determinism was judged the
higher priority for a reproducible compliance verdict — revisit if
repetition/degradation is actually observed.
"""
from __future__ import annotations
import json, re, threading, time
from collections import Counter
from typing import Any

import httpx

from .config import LLMConfig


class LLMError(RuntimeError):
    """`status` carries the HTTP status when the failure was an HTTP answer
    (None for network errors, timeouts, unparseable output) — callers use it
    to tell "the server rejected this request shape" from "auth is wrong"."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


# Retrying these wastes time: malformed request, wrong/missing auth header,
# unknown model, payload too large. 429 and 5xx are transient and retried.
_PERMANENT_STATUS = (400, 401, 403, 404, 413, 422)

# Only these mean "the server did not accept this request SHAPE" — the one
# case where retrying with response_format=json_object can help. 401/403/404
# (wrong auth / unknown model) and transient failures that already used up
# every retry would just fail again, doubling the wait for nothing.
_SCHEMA_REJECT_STATUS = (400, 422)

# Qwen3 prepends a reasoning block to every answer unless disable_thinking
# is honoured server-side; left in, it both burns tokens and can break the
# JSON parser if the model wraps its real answer after it. Stripped as a
# defensive fallback even with disable_thinking on, in case a particular
# deployment ignores that field or routes reasoning into `content` anyway
# rather than a separate `reasoning_content` field.
_THINK_BLOCK = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)


class LLMClient:
    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg
        self._client = httpx.Client(
            base_url=cfg.base_url.rstrip("/"),
            timeout=cfg.timeout_s,
            headers=cfg.headers,
            # A corporate CA bundle if given, otherwise plain on/off —
            # verification stays ON by default either way.
            verify=cfg.verify,
        )
        # LangGraph fans out one thread per candidate requirement, so without
        # this a document fires a burst of concurrent requests. Fine for a
        # gateway with real capacity (min_interval_s=0, the default); an
        # endpoint with a tight per-minute budget needs it set, since the
        # fan-out would otherwise burst well past that budget before a
        # single 429 comes back.
        self._rate_lock = threading.Lock()
        self._last_request = 0.0

    def _throttle(self) -> None:
        if self.cfg.min_interval_s <= 0:
            return
        with self._rate_lock:
            wait = self._last_request + self.cfg.min_interval_s - time.monotonic()
            if wait > 0:
                time.sleep(wait)
            self._last_request = time.monotonic()

    # ------------------------------------------------------------------ raw
    def _post(self, payload: dict) -> dict:
        last = None
        for attempt in range(self.cfg.max_retries):
            self._throttle()
            try:
                r = self._client.post("/chat/completions", json=payload)
                r.raise_for_status()
                return r.json()
            except httpx.HTTPStatusError as exc:
                last = exc
                status = exc.response.status_code
                if status in _PERMANENT_STATUS:
                    # Malformed request / wrong auth header / model not
                    # found — retrying sends the exact same bytes and gets
                    # the exact same answer. Fail fast instead of burning
                    # through max_retries' worth of backoff on a misconfigured
                    # LLM_API_KEY_HEADER or LLM_CA_BUNDLE.
                    raise LLMError(
                        f"LLM request failed permanently (HTTP {status}, not "
                        f"retrying): {exc.response.text[:300]}", status=status) from exc
                if status == 429:
                    # Rate limited: if the gateway says exactly how long
                    # until it has budget again (Retry-After, or the
                    # x-ratelimit-reset-* convention several providers use),
                    # honour that instead of guessing with a fixed backoff.
                    time.sleep(min(_retry_delay_s(exc.response.headers), 60.0))
                else:
                    time.sleep(1.5 * (attempt + 1))
            except Exception as exc:                      # noqa: BLE001
                last = exc
                time.sleep(1.5 * (attempt + 1))
        raise LLMError(f"LLM request failed after {self.cfg.max_retries} tries: {last}")

    def _safe_max_tokens(self, system: str, prefix: str, suffix: str,
                        desired: int) -> int:
        """Clamp the requested answer budget to what's actually left in the
        deployment's context window, instead of trusting a caller's static
        guess. A large prompt (reverse_check's register, for one) can by
        itself already eat most of a small deployment's window — sending a
        fixed `max_tokens` regardless is exactly how a 400 ("input_tokens +
        max_tokens exceeds context length") happens. `estimate_tokens` is
        approximate (no real tokenizer here), so a safety margin is kept on
        top of it rather than trusting the arithmetic to land exactly."""
        input_tokens = estimate_tokens(system) + estimate_tokens(prefix) + estimate_tokens(suffix)
        margin = 300
        budget = self.cfg.context_window - input_tokens - margin
        if budget < 256:
            raise LLMError(
                f"prompt too large for this deployment's context window: "
                f"~{input_tokens} input tokens already leaves less than 256 for the "
                f"answer (context_window={self.cfg.context_window}). Shrink the "
                f"prompt (smaller chunks/register batches) or raise LLM_CONTEXT_WINDOW "
                f"if the deployment actually supports more.")
        return max(256, min(desired, budget))

    def _corrected_max_tokens(self, error_text: str) -> int | None:
        """`estimate_tokens` is a guess; the gateway's own rejection message
        is not — vLLM's context-length 400 spells out the real input token
        count it just measured (e.g. "You passed 8385 input tokens..."). If
        that pattern is present, trust it over our own arithmetic and compute
        the answer budget it actually leaves, instead of failing outright on
        a prompt that was in fact salvageable with a smaller `max_tokens`."""
        m = re.search(r"passed (\d+) input tokens", error_text)
        if not m:
            return None
        real_input = int(m.group(1))
        budget = self.cfg.context_window - real_input - 200
        return max(256, budget) if budget >= 256 else None

    def _json_object_fallback(self, payload: dict, system: str) -> dict:
        payload["response_format"] = {"type": "json_object"}
        # OpenAI's json_object mode requires the word "json" to appear
        # somewhere in the messages; not every system prompt in this
        # codebase happens to contain it.
        if "json" not in system.lower():
            payload["messages"][0] = {
                "role": "system", "content": system + "\n\nRespond with JSON."}
        return self._post(payload)

    def _json_object_fallback_stream(self, payload: dict, system: str, on_delta) -> str:
        payload["response_format"] = {"type": "json_object"}
        if "json" not in system.lower():
            payload["messages"][0] = {
                "role": "system", "content": system + "\n\nRespond with JSON."}
        return self._post_stream(payload, on_delta)

    # ------------------------------------------------- structured completion
    def complete_json(
        self,
        system: str,
        prefix: str,
        suffix: str,
        schema: dict,
        temperature: float | None = None,
        disable_thinking: bool | None = None,
        max_tokens: int | None = None,
    ) -> dict:
        """One structured call.

        `prefix` holds the large, reusable part (the document). `suffix` holds
        the small, varying part (the requirement). Keeping that order is what
        makes prefix caching pay off.

        `disable_thinking`, given, overrides `cfg.disable_thinking` for this
        one call — a narrow yes/no judgement against a single requirement
        gains nothing from a reasoning block, but a call that must weigh one
        document against the *entire* requirement register at once (see
        nodes/reverse_check.py) is a genuinely harder cross-referencing task,
        and thinking measurably helps recall there. A call that turns thinking
        back on should also raise `max_tokens` — the reasoning block shares
        the same budget as the final JSON answer, and the default is sized
        for a thinking-free response.
        """
        desired_max_tokens = self.cfg.max_tokens if max_tokens is None else max_tokens
        safe_max_tokens = self._safe_max_tokens(system, prefix, suffix, desired_max_tokens)
        payload = {
            "model": self.cfg.model,
            "temperature": self.cfg.temperature_judge if temperature is None else temperature,
            "max_tokens": safe_max_tokens,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prefix + "\n\n" + suffix},
            ],
            # vLLM / TGI honour this; a gateway that does not will fail and
            # fall back to the json-object mode below. Strict mode (OpenAI's
            # actual spec) requires additionalProperties:false on every
            # object node, which some gateways enforce literally — injected
            # here rather than hand-added to each schema.
            "response_format": {
                "type": "json_schema",
                "json_schema": {"name": "response",
                                 "schema": _strict_schema(schema), "strict": True},
            },
        }
        want_disabled = self.cfg.disable_thinking if disable_thinking is None else disable_thinking
        # Explicit either way, not just when disabling — a caller that asks
        # for thinking back on (reverse_check) cannot assume the server's own
        # default is "on" just because the field is left out; some
        # deployments are configured to default it off.
        payload["chat_template_kwargs"] = {"enable_thinking": not want_disabled}
        try:
            data = self._post(payload)
        except LLMError as exc:
            if exc.status not in _SCHEMA_REJECT_STATUS:
                raise
            corrected = self._corrected_max_tokens(str(exc))
            if corrected is not None:
                payload["max_tokens"] = corrected
                try:
                    data = self._post(payload)
                except LLMError as exc2:
                    if exc2.status not in _SCHEMA_REJECT_STATUS:
                        raise
                    data = self._json_object_fallback(payload, system)
            else:
                data = self._json_object_fallback(payload, system)

        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise LLMError(f"unexpected LLM response shape: {str(data)[:200]}") from exc
        content = _THINK_BLOCK.sub("", content or "").strip()
        return _parse_json(content)

    # -------------------------------------------------------------- stream
    def _post_stream(self, payload: dict, on_delta) -> str:
        """Same retry/backoff contract as `_post`, but reads the response as
        an SSE token stream and hands each fragment to `on_delta` as it is
        generated, instead of waiting for the whole completion."""
        last = None
        for attempt in range(self.cfg.max_retries):
            self._throttle()
            parts: list[str] = []
            if attempt and on_delta:
                # The previous attempt may already have shown part of its
                # answer in the live console; say so instead of letting the
                # retry's text silently run on after it as if it were one.
                on_delta("\n[bağlantı kesildi, yanıt baştan yeniden alınıyor]\n")
            try:
                with self._client.stream("POST", "/chat/completions", json=payload) as r:
                    if r.status_code != 200:
                        r.read()
                        raise httpx.HTTPStatusError(
                            f"status {r.status_code}", request=r.request, response=r)
                    for line in r.iter_lines():
                        if not line or not line.startswith("data:"):
                            continue
                        data = line[len("data:"):].strip()
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                        except json.JSONDecodeError:
                            continue
                        choices = chunk.get("choices") or [{}]
                        delta = (choices[0].get("delta") or {}).get("content") or ""
                        if delta:
                            parts.append(delta)
                            if on_delta:
                                on_delta(delta)
                return "".join(parts)
            except httpx.HTTPStatusError as exc:
                last = exc
                status = exc.response.status_code
                if status in _PERMANENT_STATUS:
                    raise LLMError(
                        f"LLM request failed permanently (HTTP {status}, not "
                        f"retrying): {exc.response.text[:300]}", status=status) from exc
                if status == 429:
                    time.sleep(min(_retry_delay_s(exc.response.headers), 60.0))
                else:
                    time.sleep(1.5 * (attempt + 1))
            except Exception as exc:                      # noqa: BLE001
                last = exc
                time.sleep(1.5 * (attempt + 1))
        raise LLMError(f"LLM stream failed after {self.cfg.max_retries} tries: {last}")

    def complete_json_stream(
        self,
        system: str,
        prefix: str,
        suffix: str,
        schema: dict,
        temperature: float | None = None,
        on_delta=None,
        disable_thinking: bool | None = None,
    ) -> dict:
        """Like `complete_json`, but the model's own tokens are handed to
        `on_delta` as they are generated, for a live progress display. The
        parsed result is identical either way — streaming only changes when
        the caller gets to see the text, never what it contains."""
        safe_max_tokens = self._safe_max_tokens(system, prefix, suffix, self.cfg.max_tokens)
        payload = {
            "model": self.cfg.model,
            "temperature": self.cfg.temperature_judge if temperature is None else temperature,
            "max_tokens": safe_max_tokens,
            "stream": True,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prefix + "\n\n" + suffix},
            ],
            "response_format": {
                "type": "json_schema",
                "json_schema": {"name": "response",
                                 "schema": _strict_schema(schema), "strict": True},
            },
        }
        want_disabled = self.cfg.disable_thinking if disable_thinking is None else disable_thinking
        # Explicit either way, same as complete_json.
        payload["chat_template_kwargs"] = {"enable_thinking": not want_disabled}
        try:
            content = self._post_stream(payload, on_delta)
        except LLMError as exc:
            if exc.status not in _SCHEMA_REJECT_STATUS:
                raise
            corrected = self._corrected_max_tokens(str(exc))
            if corrected is not None:
                payload["max_tokens"] = corrected
                try:
                    content = self._post_stream(payload, on_delta)
                except LLMError as exc2:
                    if exc2.status not in _SCHEMA_REJECT_STATUS:
                        raise
                    content = self._json_object_fallback_stream(payload, system, on_delta)
            else:
                content = self._json_object_fallback_stream(payload, system, on_delta)

        content = _THINK_BLOCK.sub("", content or "").strip()
        return _parse_json(content)

    # --------------------------------------------------- self-consistency
    def complete_json_voted(
        self,
        system: str,
        prefix: str,
        suffix: str,
        schema: dict,
        vote_key: str,
        samples: int,
    ) -> tuple[dict, int]:
        """Run the same call `samples` times and take the majority on
        `vote_key`. Returns (winning response, agreement count).

        Disagreement is signal, not noise: the caller routes low agreement to
        human review instead of silently picking one."""
        if samples <= 1:
            return self.complete_json(system, prefix, suffix, schema), 1

        results = [
            self.complete_json(system, prefix, suffix, schema,
                               temperature=self.cfg.self_consistency_temperature)
            for _ in range(samples)
        ]
        votes = Counter(str(r.get(vote_key)) for r in results)
        winner, count = votes.most_common(1)[0]
        for r in results:
            if str(r.get(vote_key)) == winner:
                return r, count
        return results[0], 1


def _retry_delay_s(headers, default: float = 5.0) -> float:
    """How long a 429 asks us to wait. Tries the standard Retry-After header
    first, then the x-ratelimit-reset-tokens/-requests convention (format
    "18s", "1m4.8s", "150ms"); falls back to `default` if neither is present."""
    retry_after = headers.get("retry-after")
    if retry_after:
        try:
            return float(retry_after)
        except ValueError:
            pass
    for key in ("x-ratelimit-reset-tokens", "x-ratelimit-reset-requests"):
        value = headers.get(key)
        if value:
            parsed = _parse_duration(value)
            if parsed is not None:
                return parsed
    return default


def _parse_duration(text: str) -> float | None:
    m = re.match(r"^(?:(\d+(?:\.\d+)?)m)?(?:(\d+(?:\.\d+)?)s)?(?:(\d+(?:\.\d+)?)ms)?$",
                 text.strip())
    if not m or not any(m.groups()):
        return None
    minutes, seconds, millis = (float(g) if g else 0.0 for g in m.groups())
    return minutes * 60 + seconds + millis / 1000


def _strict_schema(schema: dict) -> dict:
    """Recursively set additionalProperties:false on every object node.

    OpenAI's json_schema strict mode requires this on every object in the
    tree; some gateways enforce it literally and reject the request
    otherwise (vLLM/TGI mostly do not check). Applied here rather than in
    each node's schema so every caller gets it for free.
    """
    if isinstance(schema, dict):
        out = {k: _strict_schema(v) for k, v in schema.items()}
        if out.get("type") == "object" and "additionalProperties" not in out:
            out["additionalProperties"] = False
        return out
    if isinstance(schema, list):
        return [_strict_schema(v) for v in schema]
    return schema


def _parse_json(text: str) -> dict:
    """Tolerate fenced blocks and leading prose from gateways that ignore
    response_format."""
    text = (text or "").strip()
    fence = re.search(r"```(?:json)?\s*(.+?)```", text, re.S)
    if fence:
        text = fence.group(1).strip()
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start == -1 or end <= start:
            raise LLMError(f"model did not return JSON: {text[:200]}")
        try:
            parsed = json.loads(text[start:end + 1])
        except json.JSONDecodeError as exc:
            # Always LLMError, never a bare JSONDecodeError: callers catch
            # LLMError to turn a bad answer into needs_review.
            raise LLMError(f"model returned malformed JSON: {text[:200]}") from exc
    if not isinstance(parsed, dict):
        raise LLMError(f"model returned JSON that is not an object: {text[:200]}")
    return parsed


def estimate_tokens(text: str) -> int:
    """Rough estimate; good enough for routing decisions, not precise enough
    to be the last word before a request goes out (see `_safe_max_tokens`,
    which corrects itself against the gateway's own reported count on a
    context-length rejection instead of trusting this blindly).

    Calibrated against one real data point rather than guessed: a reverse_check
    call whose prompt was ~49,100 characters came back from the actual gateway
    reporting 8,385 input tokens — ~5.9 chars/token, not the ~3 chars/token a
    naive guess (or English-oriented rules of thumb) would suggest. Rounding
    down to /5 keeps a small margin on the safe (over-count) side."""
    return max(1, len(text) // 5)
