# -*- coding: utf-8 -*-
"""Corporate directory (LDAP/AD) lookup.

Answers exactly one question: *does this name, as a document's document-
control table spells it, correspond to a real, active corporate account?*
Not authentication — the service account does the binding, no end-user
password is ever handled here. Adapted from a sibling project's
`ldap_auth.py` (which *does* do password auth for an interactive login);
only its service-bind-then-search half applies to a read-only lookup, so
that is the part carried over.

A name match is a floor, not a ceiling: it says a person by that name has
an active account, not that they personally approved this document or hold
the title the document claims for them. `check_metadata` treats a miss as
something for a human to look at, never as a fabricated fact of its own.

`ldap3` is imported only inside `lookup_person`, and only once LDAP is
actually turned on (`cfg.enabled`) — a deployment that never sets
LDAP_ENABLED=true does not need the package installed.
"""
from __future__ import annotations
import logging
import time

from .config import LDAPConfig

logger = logging.getLogger(__name__)

# AD's userAccountControl is a bitmask; bit 0x2 (ACCOUNTDISABLE) means the
# account is disabled. https://learn.microsoft.com/... UF_ACCOUNTDISABLE.
_UAC_DISABLED_BIT = 0x2


def _first(values) -> str:
    return values[0] if values else ""


def lookup_person(name: str, cfg: LDAPConfig) -> dict | None:
    """Search the directory for `name`.

    Returns:
      None                    — LDAP is off, or the lookup itself failed
                                (network/bind error): "could not check",
                                not a claim about the person.
      {"found": False}        — the directory was reachable and searched;
                                no matching account exists.
      {"found": True, ...}    — a match was found; includes display_name,
                                title, department, mail and account_enabled.
    """
    name = (name or "").strip()
    if not cfg.enabled or not name:
        return None
    if not cfg.bind_dn.strip() or not cfg.user_search_base.strip():
        # Boş bind DN ile ldap3 anonim bağlanır; anonim arama genelde hiçbir
        # hesap döndürmez ve her isim sessizce "bulunamadı" görünür — yani
        # gerçekte var olan herkes için yanlış alarm. Kontrol yapılamıyorsa
        # yapılamadığı söylenmeli, "bulunamadı" denmemeli.
        logger.error("LDAP_ENABLED açık ama LDAP_BIND_DN veya LDAP_USER_SEARCH_BASE "
                     "boş; dizin kontrolü yapılamadı.")
        return None
    if not cfg.server_uri.strip():
        # Boş adresle ldap3 sessizce localhost:389'a bağlanmaya çalışır ve
        # "Connection refused" döner — asıl sebep ("adres hiç ayarlanmamış")
        # dışarıdan görünmez. Bu, webapp/auth.py'de gerçek bir kurulumda
        # yaşanan arızayla aynı hata sınıfı; burada da açıkça söyleniyor.
        logger.error("LDAP_ENABLED açık ama LDAP_SERVER_URI tanımlı değil.")
        return None

    try:
        from ldap3 import ALL, SUBTREE, Connection, Server
        from ldap3.core.exceptions import LDAPException, LDAPSocketOpenError
        from ldap3.utils.conv import escape_filter_chars
    except ImportError:
        logger.error("LDAP_ENABLED açık ama 'ldap3' paketi kurulu değil "
                     "(pip install ldap3).")
        return None

    def build_server() -> "Server":
        return Server(cfg.server_uri, get_info=ALL, use_ssl=cfg.use_ssl,
                      connect_timeout=cfg.connect_timeout)

    conn = None
    last_error: Exception | None = None
    for attempt in range(1, cfg.max_retries + 1):
        try:
            conn = Connection(build_server(), user=cfg.bind_dn,
                              password=cfg.bind_password, auto_bind=True,
                              receive_timeout=cfg.receive_timeout)
            break
        except (LDAPSocketOpenError, OSError) as error:
            last_error = error
            logger.warning("LDAP servis bağlantısı denemesi %s/%s başarısız: %s",
                           attempt, cfg.max_retries, error)
            if attempt < cfg.max_retries:
                time.sleep(cfg.retry_delay)
        except LDAPException as error:
            logger.error("LDAP servis bağlantısı kurulamadı: %s", error)
            return None

    if conn is None:
        logger.error("LDAP servis bağlantısı %s denemeden sonra başarısız: %s",
                     cfg.max_retries, last_error)
        return None

    try:
        # escape_filter_chars: `name` comes from parsed document text, not
        # a login form — an attacker-crafted document must not be able to
        # inject LDAP filter syntax through the approver/owner field.
        search_filter = cfg.user_search_filter.replace(
            "{name}", escape_filter_chars(name))
        conn.search(
            search_base=cfg.user_search_base, search_filter=search_filter,
            search_scope=SUBTREE,
            attributes=["displayName", "cn", "mail", "title", "department",
                       "userAccountControl"])
        if not conn.entries:
            return {"found": False}

        entry = conn.entries[0].entry_attributes_as_dict
        uac = _first(entry.get("userAccountControl", []))
        enabled = not (int(uac) & _UAC_DISABLED_BIT) if str(uac).isdigit() else None
        return {
            "found": True,
            "display_name": _first(entry.get("displayName", [])) or _first(entry.get("cn", [])),
            "title": _first(entry.get("title", [])),
            "department": _first(entry.get("department", [])),
            "mail": _first(entry.get("mail", [])),
            "account_enabled": enabled,
            "multiple_matches": len(conn.entries) > 1,
        }
    except LDAPException as error:
        logger.error("LDAP arama hatası (%s): %s", name, error)
        return None
    finally:
        conn.unbind()
