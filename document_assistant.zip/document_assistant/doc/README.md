# doc/ — Diyagram kaynakları

| Dosya | Anlattığı |
|---|---|
| `kullanici_akisi_sequence.mmd` | Web arayüzünde kullanıcının **ne girdiği, ne aldığı**: giriş → banka profili → belge yükleme → tarama → birleştirme → üç rapor |

`.mmd` dosyaları Mermaid kaynağıdır:

- **Azure DevOps wiki:** içeriği `::: mermaid` ile `:::` satırları arasına yapıştırın.
- **Düzenleme / önizleme:** https://mermaid.live
- **Wiki'deki karşılığı:** `wiki/Dokümantasyon-Asistanı/Faz-1-BSEB-Uyum-İncelemesi.md` → "Kullanıcı akışı".

Diyagram değişirse önce bu dosya güncellenir, wiki'deki kopya buradan alınır.
