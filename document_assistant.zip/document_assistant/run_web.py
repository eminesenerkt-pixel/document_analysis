#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Çok kullanıcılı Flask arayüzünü başlatır.

    cd <proje klasörü>
    python run_web.py

Ayarlar `.env`'den okunur: WEB_HOST, WEB_PORT, FLASK_SECRET_KEY,
USE_LDAP_LOGIN (kapalıyken demo hesaplar kullanılır — bkz. webapp/auth.py).

Klasörün ADI ÖNEMSİZDİR. Proje bu betiğin bulunduğu klasörden, sabit bir iç
adla yüklenir; üst klasör `sys.path`'e EKLENMEZ. Böylece:
  * klasör taşınırken istenen adla yeniden adlandırılabilir (boşluk, tire,
    Türkçe karakter dahil),
  * yanında duran eski bir kopya ASLA yüklenmez — Python yalnızca bu
    klasöre bakar.
"""
from __future__ import annotations
import importlib.util
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKAGE = "bseb_uyum"          # yalnızca süreç içi ad; klasör adıyla ilgisi yok

_spec = importlib.util.spec_from_file_location(
    PACKAGE, HERE / "__init__.py", submodule_search_locations=[str(HERE)])
_pkg = importlib.util.module_from_spec(_spec)
sys.modules[PACKAGE] = _pkg
_spec.loader.exec_module(_pkg)

from bseb_uyum.config import APP_VERSION, Config  # noqa: E402
from bseb_uyum.webapp import create_app  # noqa: E402

if __name__ == "__main__":
    print(f"BSEB Uygunluk Taraması · sürüm {APP_VERSION}")
    print(f"Kod klasörü: {HERE}")
    cfg = Config()
    app = create_app(cfg)
    app.run(host=cfg.web.host, port=cfg.web.port, debug=False, threaded=True)
