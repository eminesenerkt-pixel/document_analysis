# -*- coding: utf-8 -*-
"""Corpus search for the evidence agent.

Hybrid by design, lexical-first in this implementation. Regulatory Turkish is
exact-match heavy — "uçtan uca güvenli iletişim", "ikincil sistem", "bilmesi
gereken kadar" — and BM25 catches those where an embedding often will not.
Plug a vector index into `VectorSearch` and combine the two when you have an
embedding model that handles Turkish well; keep BM25 in the mix either way.
"""
from __future__ import annotations
import math
import re
from collections import Counter
from pathlib import Path

TOKEN = re.compile(r"[0-9a-zçğıöşüâîû]+", re.I)


def tokenize(text: str) -> list[str]:
    return [t.lower() for t in TOKEN.findall(text or "") if len(t) > 2]


class BM25Search:
    """Block-level BM25 over the extracted corpus."""

    K1, B = 1.5, 0.75

    def __init__(self, documents: list[dict]):
        """documents: [{document_id, blocks:[{id,text,...}]}]"""
        self.entries: list[dict] = []
        for doc in documents:
            for block in doc["blocks"]:
                if block["source"] in ("header", "footer") or len(block["text"]) < 40:
                    continue
                tokens = tokenize(block["text"])
                if tokens:
                    self.entries.append({
                        "document_id": doc["document_id"],
                        "block_id": block["id"],
                        "text": block["text"],
                        "tf": Counter(tokens),
                        "length": len(tokens),
                    })

        self.avg_len = (sum(e["length"] for e in self.entries) / len(self.entries)
                        if self.entries else 1.0)
        df = Counter()
        for e in self.entries:
            df.update(e["tf"].keys())
        n = max(1, len(self.entries))
        self.idf = {t: math.log(1 + (n - c + 0.5) / (c + 0.5)) for t, c in df.items()}

    def __call__(self, query: str, k: int = 5) -> list[dict]:
        terms = tokenize(query)
        if not terms:
            return []
        scored = []
        for e in self.entries:
            score = 0.0
            for t in terms:
                f = e["tf"].get(t, 0)
                if not f:
                    continue
                denom = f + self.K1 * (1 - self.B + self.B * e["length"] / self.avg_len)
                score += self.idf.get(t, 0.0) * f * (self.K1 + 1) / denom
            if score > 0:
                scored.append((score, e))
        scored.sort(key=lambda x: -x[0])
        return [{"document_id": e["document_id"], "block_id": e["block_id"],
                 "text": e["text"], "score": round(s, 3)}
                for s, e in scored[:k]]


def build_search(extract_dir: str):
    """Load the extraction output and return a callable search function."""
    import json
    documents = []
    for path in sorted(Path(extract_dir).glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        documents.append({"document_id": data.get("file", path.stem),
                          "blocks": data.get("blocks", [])})
    return BM25Search(documents)
