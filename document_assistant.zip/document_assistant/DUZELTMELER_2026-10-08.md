# Düzeltmeler — 8 Ekim 2026

Kod incelemesinde bulunan 16 hatanın 15'i düzeltildi. 16. madde (ölü
`security/` klasörü) silme izni verilmediği için olduğu gibi bırakıldı.

Her düzeltme, sahte (taklit) bir LLM istemcisi ve Flask test istemcisiyle
`documents/` içindeki gerçek belgeler üzerinde çalıştırılarak denendi. Gerçek
model sunucusuyla uçtan uca bir tarama bu kapsamda **yapılmadı**.

---

## 🔴 Kritik

### 1. Kanıtı olmayan "Uygun" kararları artık kabul edilmiyor
**Dosya:** `nodes/evaluate.py` → `verify_citations`

**Sorun:** Model `satisfied` deyip hiç alıntı vermezse alıntı kontrolü
tamamen atlanıyordu. Test belgesinde 21 bulgunun 21'i alıntısız olduğu hâlde
"Uygun" kalıyordu.

**Düzeltme:** `satisfied`, `partial`, `contradicted` ya da `satisfied_by_ref`
kararı verilip hiç alıntı gösterilmezse karar `needs_review` (İnceleme
Gerekli) olur. Güven en fazla 0.3'e düşer ve gerekçeye
"[karar için belgeden alıntı verilmedi]" notu eklenir.

**Test:** 21 alıntısız "Uygun" kararın 21'i de `needs_review`'a düştü.

### 2. Tek bir model hatası artık bütün belgeyi düşürmüyor
**Dosyalar:** `nodes/evaluate.py`, `nodes/profile.py`, `nodes/reverse_check.py`,
`nodes/corpus.py`

**Sorun:** Yaklaşık 100 paralel daldan birinde 502 ya da bozuk JSON
gelirse belgenin tüm sonuçları kayboluyor, web arayüzü "Hata oluştu" ile
bitiyordu.

**Düzeltme:** Hata alan adım artık kendi kapsamında yakalanıyor:

| Adım | Hata olursa |
|---|---|
| `evaluate_core` / `evaluate_border` | O madde `needs_review` olur, güven 0; gerekçede hata yazar |
| `challenge` (itiraz turu) | Bulgu olduğu gibi kalır, "[itiraz turu yapılamadı]" notu eklenir |
| `select_topics` (konu seçimi) | Yalnızca evrensel maddeler değerlendirilir, belgeye açık bir uyarı eklenir |
| `recall_guard` (ek konu kontrolü) | Adım atlanır |
| `check_translation` (çeviri kontrolü) | Uyarı eklenir: "elle karşılaştırılmalı" |
| `reverse_check` (ikinci kontrol) | O çağrı atlanır; "X/Y çağrı başarısız, sonuç eksik olabilir" uyarısı eklenir |
| `evidence_agent` | Arama durur, madde karşılıksız sayılır |
| `recommend` | Bulgu kalır, yalnızca öneri metni boş olur |

**Test:** 3. model çağrısında hata verdirildi; belge tamamlandı, 26
bulgunun 1'i `needs_review` olarak işaretlendi.

### 3. Model örnekleri tamamen ayrışınca güven artık düşürülüyor
**Dosya:** `nodes/evaluate.py` → yeni `_confidence` fonksiyonu

**Sorun:** `1 < uyum < 3` şartı yüzünden üç örneğin üçü de farklı karar
verdiğinde (uyum 1/3, en güvenilmez durum) güven düşürülmüyordu.

**Düzeltme:** Kontrol artık o maddenin kendi örnek sayısıyla yapılıyor.
Örneklerin hepsi aynı kararı vermediyse güven en fazla 0.55 olur ve bulgu
insan incelemesine gider. Kontrol `verify_citations`'tan, örnek sayısının
bilindiği `evaluate_core`/`evaluate_border`'a taşındı. Model `confidence`
alanını boş ya da hatalı döndürürse çökme yerine 0 kabul edilir.

**Test:** 1/3 uyumda güven 0.9 → 0.55 oldu; 3/3 uyumda 0.9 kaldı.

### 4. Büyük harfli Türkçe metin (İ harfi) kuralları artık bozmuyor
**Dosyalar:** `verify.py` (yeni `tr_lower`), `nodes/profile.py`,
`nodes/metadata_rules.py`

**Sorun:** Python'da `"YÖNETİM KURULU".lower()` sonucu `"yöneti̇m kurulu"`
oluyor (İ → i + nokta işareti) ve düzenli ifadeler eşleşmiyordu.
"BİLGİ GÜVENLİĞİ POLİTİKASI" başlığı `unknown` sınıfına düşüyordu.

**Düzeltme:** `tr_lower()` yardımcısı önce `İ`'yi `i`'ye çevirip sonra
küçültüyor. Belge sınıfı tespiti, künye etiketleri, onaylayan/yetki devri
kontrolü, gözden geçirme ifadesi, revizyon tablosu başlıkları ve ek konu
kontrolünün tamamı bunu kullanıyor.

**Test:** "BİLGİ GÜVENLİĞİ POLİTİKASI" → `policy`,
"İZ KAYITLARI PROSEDÜRÜ" → `procedure`.

### 5. Ters kontrol bulguları komut satırı (CLI) raporuna geri geldi
**Dosya:** `graph.py` → `_review_documents`

**Sorun:** `main.py run` ile alınan raporda 2. Kontrol (belge → BSEB) hep
boştu, çünkü kayıt oluşturulurken `reverse_findings` kopyalanmıyordu.

**Düzeltme:** `reverse_findings` belge kaydına ekleniyor ve graf başlangıç
durumunda boş liste olarak veriliyor. Web arayüzü bu fonksiyonu
kullanmadığı için orada sorun yoktu.

---

## 🟠 Güvenlik (web arayüzü)

### 6. Dosya yüklemede path traversal kapatıldı
**Dosya:** `webapp/routes.py` → yeni `_safe_upload_name`

**Sorun:** Dosya adı doğrudan kullanılıyordu; `../../config.py` gibi bir
adla proje dosyaları ezilebilirdi.

**Düzeltme:**
- Dosya adının yalnızca son bileşeni alınıyor (`/` ve `\` ayırıcıları atılıyor).
- Yalnızca `.docx` kabul ediliyor (ayrıştırıcı eski `.doc` biçimini zaten okuyamıyordu).
- Kaydetmeden önce hedefin gerçekten yükleme klasörünün içinde olduğu kontrol ediliyor.
- Türkçe karakterler korunuyor (`werkzeug.secure_filename` bunları siliyordu, bu yüzden kullanılmadı).

**Test:** `../../config.py` → reddedildi, `../../a.docx` → `a.docx`,
`Politikası.docx` → aynen korundu.

### 7. Girişteki açık yönlendirme (open redirect) kapatıldı
**Dosya:** `webapp/routes.py` → yeni `_safe_next`

**Sorun:** `/login?next=https://baska-site` giriş sonrası kullanıcıyı
dışarıya gönderiyordu.

**Düzeltme:** `next` yalnızca uygulamanın kendi yollarına (`/` ile
başlayan, `//` ile başlamayan) izin veriyor; diğer her durumda ana sayfaya
dönülüyor.

### 8. CSRF koruması eklendi; banka profili yetkiye bağlandı
**Dosyalar:** `webapp/__init__.py`, `webapp/routes.py`, `config.py`,
`webapp/templates/index.html`, `webapp/templates/login.html`,
`webapp/static/js/app.js`, `.env.example`

**CSRF:** Her oturuma rastgele bir belirteç veriliyor. Bütün POST istekleri
(giriş, banka profili, tarama başlatma) bunu form alanı ya da
`X-CSRF-Token` başlığı olarak göndermek zorunda. Gönderilmezse sayfalarda
400 hatası, `/api/` uçlarında JSON hata mesajı dönüyor.

**Banka profili:** Yeni `PROFILE_EDITORS` ayarı eklendi (virgülle ayrılmış
kullanıcı adları). Listede olmayan kullanıcı profili yalnızca görebiliyor;
POST denemesi 403 alıyor.

> ⚠️ **Yapılması gereken:** `PROFILE_EDITORS` boş bırakılırsa, demo
> kurulum bozulmasın diye herkes eskisi gibi düzenleyebilir. Üretimde
> `.env` dosyasında bu ayar doldurulmalı.

**Test:**
- CSRF belirteci olmadan giriş → 400, belirteçle → 302.
- `next=https://evil.com` → `/` adresine yönlendi.
- Yetkisiz kullanıcının profil kaydetmesi → 403.

### 9. Aynı saniyede başlayan taramalar artık çakışmıyor; bellek temizleniyor
**Dosyalar:** `webapp/routes.py`, `webapp/jobs.py`

**Sorun:** `run_id` saniye çözünürlüklüydü; aynı saniyede başlayan iki
tarama birbirinin üzerine yazıyordu. `JOBS` sözlüğü de hiç temizlenmiyordu.

**Düzeltme:** `run_id` artık zaman damgası + 6 haneli rastgele ek
(ör. `20261008-143012-a3f9c1`). Biten işler 24 saat sonra bellekten
siliniyor; çalışan işlere dokunulmuyor. Rapor dosyaları diskte kalıyor.

---

## 🟡 Mantık ve kalite

### 10. Ters kontrol: uygulanmayan maddeler ve tekrarlanan bulgular
**Dosya:** `nodes/reverse_check.py`

- Banka profilinde "Hayır" yanıtı verilmiş koşullu maddeler artık modele
  gönderilmiyor. Yanıtsız (Bilinmiyor) olanlar gönderilmeye devam ediyor.
- Aynı madde ve aynı alıntı birden fazla parçada ya da kural grubunda
  bulunursa tek bulgu olarak tutuluyor.

**Test:** 6 kural grubunun hepsi aynı aykırılığı döndürdü; sonuçta 1 bulgu kaldı.

### 11. Kural tabanlı bulgular artık LLM itirazına sokulmuyor
**Dosya:** `nodes/evaluate.py` → `challenge`

`check_metadata`'nın kurallarla verdiği kararlar (REQ-5.2.b, 5.3, 5.4.b,
5.5.a, 5.5.b) itiraz turunda atlanıyor. Böylece "evrensel halka LLM'siz"
ilkesi korunuyor. Evrensel halkanın modelle değerlendirilen diğer 3
maddesi itiraz turundan geçmeye devam ediyor.

### 12. Sınır bulgularında itiraz artık doğru soruyu soruyor
**Dosya:** `nodes/evaluate.py` → `challenge`

Sınır (border) bulgularında modele artık "gereksinim karşılanmış mı?"
diye sorulmuyor. Soru: "Belge bu konu için başka bir belgeye (kod ya da
başlıkla) atıf yapıyor mu?" Bulgu yalnızca böyle bir atıf varsa çürütülüyor.

### 13. Kanıt ajanının "buldum" cevabı artık doğrulanıyor
**Dosya:** `nodes/corpus.py` → yeni `_answer_verified`

Model "şu belgede karşılanıyor" dediğinde verdiği alıntının, aramanın
gerçekten döndürdüğü ve aynı belgeye ait bir parçada birebir geçmesi
gerekiyor. Arama yapmadan "buldum" demek, var olmayan bir belge adı
vermek ya da alıntıyı başka kelimelerle yazmak artık açığı kapatmıyor.
Sistem komutuna da (prompt) bu kural eklendi.

**Test:** gerçek alıntı → kabul; uydurma belge adı → red; başka
kelimelerle yazılmış alıntı → red.

### 14. Değerlendirilecek madde kalmasa da doğrulama adımları çalışıyor
**Dosyalar:** `nodes/evaluate.py` → `fan_out`, `graph.py`

Bütün adaylar kurallarla karara bağlanmışsa (boş fan-out), graf
eskiden `verify_citations`, `challenge` ve `route_for_review`
adımlarına uğramadan bitiyordu. Artık doğrudan `verify_citations`'a
gidiyor.

### 15. LLM istemcisindeki tutarsızlıklar
**Dosya:** `llm.py`

- **Gereksiz yedek deneme kaldırıldı:** `json_object` yedeğine yalnızca
  sunucu istek biçimini reddettiğinde (HTTP 400/422) geçiliyor. 401, 403,
  404 ve tekrar denemeleri tükenmiş geçici hatalar artık iki kat
  bekletmeden hemen bildiriliyor. `LLMError` artık HTTP durum kodunu da
  (`status`) taşıyor.
  **Test:** 401 yanıtında tek istek gönderildi, yedeğe geçilmedi.
- **Hata türü tutarlı:** `_parse_json` artık ham `JSONDecodeError` yerine
  her zaman `LLMError` fırlatıyor. JSON nesnesi olmayan bir yanıt (ör. liste)
  da reddediliyor. Beklenmedik yanıt yapısında da `LLMError` veriliyor.
- **Akışta thinking ayarı:** `complete_json_stream` artık
  `disable_thinking` parametresi alıyor ve `enable_thinking` değerini her
  iki durumda da açıkça gönderiyor (`complete_json` ile aynı).
- **Canlı konsolda tekrar:** Akış yarıda kesilip tekrar denendiğinde
  konsola "[bağlantı kesildi, yanıt baştan yeniden alınıyor]" satırı
  yazılıyor. Böylece iki denemenin metni tek bir cevap gibi birleşmiyor.

---

## ⏸️ Yapılmayan

### 16. `security/` klasörü silinmedi
Bu klasör başka bir projeden kalmış: var olmayan `capabilities.base` ve
`config.settings` modüllerini import ediyor ve hiçbir yerden
kullanılmıyor. Silme işlemi bu oturumda izin almadığı için klasör
yerinde bırakıldı. İstenirse elle silinebilir:

```bash
rm -rf /Users/eminesener/Desktop/dokuman_inceleme/security
```

---

## ➕ Yeni: Tekrarların birleştirilmesi ve üç ayrı rapor

### Sorun
Değerlendirme her BSEB gereksinimini ayrı ayrı ele alıyor. Bu, "şu madde
neden uygun değil?" sorusuna madde bazında cevap verebilmek için doğru ve
öyle kalıyor. Ama aynı çıktı doğrudan kullanıcıya gösteriliyordu:
- Aynı paragraf beş gereksinimin kanıtıysa beş kartta beş kez görünüyordu.
- Her bulgu için birbirinden habersiz ayrı bir öneri yazıldığından öneriler
  neredeyse aynı cümlelerle tekrar ediyordu.
- 1. ve 2. Kontrol aynı aykırılığı bulduğunda iki ayrı yerde yazıyordu.

### Çözüm: birleştirme adımı
**Yeni dosya:** `nodes/consolidate.py`. Bulgu başına öneri yazan eski adımın
yerini aldı (`webapp/jobs.py`, `graph.py`).

1. **Bölümlere ayırma:** Belge, başlıklarına göre bölümlere ayrılır
   (`build_sections`).
2. **Gruplama (model yok):**
   - Her olumsuz bulgu, kanıt paragrafının bulunduğu bölüme bağlanır.
   - Kanıtı olmayan "Belirtilmemiş" bulgular tema başına
     "belgeye eklenmesi gereken konu" gruplarına gider.
   - Künye kurallarının bulguları tek bir "belge künyesi" grubunda toplanır.
3. **İki kontrolün birleşmesi:** 2. Kontrol'ün bulduğu bir aykırılık
   1. Kontrol'de aynı madde için zaten varsa ayrıca yazılmaz; o bulgu
   "iki kontrol de buldu" olarak işaretlenir.
4. **Grup başına tek model çağrısı.** Üç çıktı üretir:
   - iç değerlendirme özeti,
   - ekibe gidecek değişiklik maddeleri (her farklı değişiklik bir kez),
   - bölüme doğrudan yapıştırılabilecek önerilen metin.
5. **Kod kontrolleri:**
   - **Kayıp kontrolü:** Model gruptaki bir bulguyu hiçbir değişiklik
     maddesine bağlamazsa, o bulgu kendi maddesi olarak listeye geri eklenir
     ve iç görünümlerde "model atlamıştı, otomatik eklendi" diye işaretlenir.
   - **Sızıntı kontrolü:** Ekibe giden metinde "BSEB", "yönetmelik" ya da
     "REQ-…" geçerse model bir kez daha uyarılarak çağrılır. Kalan kodlar
     metinden silinir.
   - **Hata durumu:** Model çağrısı başarısız olursa bulgular ayrı ayrı
     maddeler hâlinde listelenir; rapor yine çıkar.
6. **Öncelik modelden alınmaz.** Gruptaki maddelerin register'daki en yüksek
   risk seviyesidir; "Çelişkili" bulgu varsa en az "yüksek" olur. Aynı girdi
   her taramada aynı önceliği verir.

Öneriler artık bulgu başına değil grup başına yazıldığı için model çağrısı
sayısı da düşüyor. Testte 12 olumsuz bulgu 7 gruba indi.

### Üç rapor
| Rapor | Kime | İçerik | İndirme |
|---|---|---|---|
| **Ekip raporu** — "Belge Revizyon Talepleri" | Belge sahibi ekip | Bölüm bölüm yapılması gerekenler, önerilen metin ve öncelik. **BSEB, madde numarası, karar etiketi ve model gerekçesi yok.** İnsan incelemesi bekleyen maddeler girmez. | `report-ekip.pdf` |
| **İç rapor** | Biz | Aynı talepler, ayrıca değerlendirme özeti, dayandığı BSEB maddeleri ve kararları, insan incelemesi bekleyenler, uyarılar | `report-ic.pdf` |
| **Ayrıntılı denetim kaydı** | Denetim izi | Her BSEB maddesinin tek tek sonucu, alıntılar, 1. ve 2. Kontrol (eski PDF) | `report-ayrintili.pdf` (eski `report.pdf` adresi de buraya gider) |

**Değişen dosyalar:** `report_pdf.py`, `webapp/routes.py`.

### Sonuç sayfası
**Değişen dosyalar:** `webapp/templates/results.html`, `webapp/static/css/app.css`,
`webapp/static/js/app.js`

Sayfa yukarıdan aşağıya şu sırayla düzenlendi:
1. **Belgede değiştirilmesi gerekenler:** Bölüm bazlı kartlar. Her kartta
   "Dayandığı maddeler" açılır listesi var.
2. **İnsan incelemesi bekleyenler.**
3. **Ayrıntılı denetim kaydı:** Eski madde madde liste, varsayılan olarak
   kapalı.

En altta üç indirme butonu var. Birleştirme adımından önce alınmış eski
tarama sonuçları da açılmaya devam ediyor.

### Test edilenler (sahte model ile)
- Bölümleme ve gruplama: 15 bölümlü belgede 12 olumsuz bulgu 7 gruba indi.
- Sızıntı: model metne "BSEB" ve "REQ-" yazdı, yeniden çağrıldı ve temiz metin geldi.
- Kayıp kontrolü: model her grupta bir bulguyu atladı, kod hepsini geri ekledi.
- Raporlar: üç PDF ve sonuç sayfası üretildi. Eski adres çalışıyor;
  bilinmeyen bir rapor türü 404 veriyor.

### Bilinen sınırlar
- Bölümler, ayrıştırıcının "başlık" saydığı satırlara göre kurulur. Başlıkları
  stil ya da numarayla işaretlenmemiş bir belgede bölümler kaba olabilir.
- Model bir bulguyu atladığında geri eklenen madde, gereksinimin kendi
  cümlesiyle yazılır. Bu cümleler düzenleme diline yakın olabilir.
- Ekip raporu PDF olarak üretiliyor. Ekip metni doğrudan düzenleyecekse
  Word (.docx) çıktısı ayrıca eklenebilir.
- `render_graph.py`, `README.md` ve `docs/` altındaki şemalar yeni adımı
  henüz göstermiyor.

### Ekran düzeltmeleri (birleştirme adımından sonra)
- **Canlı konsol boş kalıyordu.** Konsol, model çıktısından yalnızca eski öneri adımının
  alan adlarını süzüyordu. Birleştirme adımının alanları (`internal_summary`, `text`,
  `proposed_text`) da eklendi (`webapp/static/js/app.js`).
- **Üst özet ve belge rozeti birleştirilmiş görünümle çelişiyordu.** Ekran "12 maddede
  iyileştirme" ve "13 madde dikkat gerektiriyor" diyordu; 2. kontrolün bulgusu 1. kontrolle
  aynı olduğu hâlde iki kez sayılıyordu. Artık "7 değişiklik talebi (12 bulgudan
  birleştirildi)" yazıyor. Birleştirmeden önceki eski sonuçlar eski biçimiyle açılıyor.
- **Ekran ve PDF başlıkları aynı.** Belgede hiç yer almayan konular ekranda da
  "Belgeye eklenmesi gereken konu: …" başlığıyla gösteriliyor.

### Sonuç sayfası: üç rapor, üç buton
Sonuç sayfasının üstünde üç buton var; her biri aynı adlı raporun ekrandaki
karşılığını açar ve kendi indirme düğmesini taşır.

| Buton | Ekranda | İndirme |
|---|---|---|
| **Ekip raporu** | Belge gibi sade görünüm: talepler, öncelik, yapılması gerekenler, önerilen metin. BSEB, madde numarası ve karar etiketi yok. **Metni kopyala** düğmesi e-postaya yapıştırılabilir düz metin kopyalar | PDF |
| **İç rapor** (varsayılan) | Bölüm bazlı talepler, dayandığı BSEB maddeleri (açılır kartlar), uyarılar, insan incelemesi bekleyenler | PDF |
| **Ayrıntılı denetim kaydı** | 1. ve 2. kontrolün madde madde sonuçları | PDF + JSON |

Birleştirme adımından önceki taramalarda yalnızca "Ayrıntılı denetim kaydı" butonu görünür.
Kopyalama, iç ağda `http://` ile açılan adreslerde de çalışır (tarayıcının pano izni
yalnızca https'te verdiği yöntem yerine yedek yöntem devreye girer).

**Değişen dosyalar:** `webapp/templates/results.html`, `webapp/static/js/app.js`,
`webapp/static/css/app.css`

### Klasör adından bağımsız çalışma *(9 Ekim)*
**Sorun:** Kod, klasörün adının `dokuman_inceleme` olduğunu varsayıyordu (`run_web.py` üst
klasörü arama yoluna ekleyip bu adla içe aktarıyordu). Klasör taşınırken yeniden
adlandırıldığında, yanında aynı adlı eski bir kopya varsa uygulama hata vermeden
**eski kodu** çalıştırıyordu.

**Düzeltme:**
- `run_web.py` projeyi yalnızca kendi bulunduğu klasörden yüklüyor; üst klasör arama
  yoluna eklenmiyor. Klasörün adı önemsiz: boşluk, parantez ve Türkçe karakter olabilir.
- `webapp/` içindeki `from dokuman_inceleme.…` satırları göreli içe aktarmaya çevrildi;
  kodda klasör adı geçmiyor.
- Açılışta konsolda, ayrıca ekranın alt bilgisinde ve her sonuçta sürüm görünüyor
  (`config.py` → `APP_VERSION`).

**Test:** Proje "BSEB Uyum Aracı (yeni)" adıyla kopyalandı. Yanına, yüklenirse hemen hata
veren `dokuman_inceleme` adlı bir tuzak klasör kondu. Kod yeni klasörden yüklendi, tuzak
klasöre hiç dokunulmadı, sayfalar açıldı.

**Değişen dosyalar:** `run_web.py`, `config.py`, `webapp/__init__.py`, `webapp/jobs.py`,
`webapp/routes.py`, `webapp/render.py`, `webapp/auth.py`, `webapp/templates/base.html`,
`webapp/templates/results.html`

---

## Değişen dosyalar

`llm.py`, `verify.py`, `graph.py`, `config.py`, `.env.example`,
`nodes/evaluate.py`, `nodes/profile.py`, `nodes/metadata_rules.py`,
`nodes/reverse_check.py`, `nodes/corpus.py`, `webapp/__init__.py`,
`webapp/routes.py`, `webapp/jobs.py`, `webapp/static/js/app.js`,
`webapp/templates/index.html`, `webapp/templates/login.html`

Birleştirme ve raporlar için ek olarak: `nodes/consolidate.py` (yeni),
`report_pdf.py`, `webapp/templates/results.html`, `webapp/static/css/app.css`

Değişiklik öncesi projenin tam yedeği oturumun geçici klasöründe
(`scratchpad/yedek_2026-10-08`) alındı. Bu klasör kalıcı değildir.
