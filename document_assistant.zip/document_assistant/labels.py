# -*- coding: utf-8 -*-
"""Turkish display labels for the internal English enums (Verdict, Ring,
severity). One place for these so a node's live progress line and the web
app's results table never drift into two different translations of the
same word."""
from __future__ import annotations

VERDICT_LABEL = {
    "satisfied": "Uygun", "satisfied_by_ref": "Referansla Uygun",
    "partial": "Kısmi", "not_mentioned": "Belirtilmemiş",
    "contradicted": "Çelişkili", "out_of_scope": "Kapsam Dışı",
    "needs_review": "İnceleme Gerekli",
}
RING_LABEL = {"universal": "Evrensel", "core": "Ana Konu", "border": "Sınır"}
SEVERITY_LABEL = {"critical": "Kritik", "high": "Yüksek", "medium": "Orta", "low": "Düşük"}

# Bir denetçinin önce bakması gerekene göre sıra: belirsiz/olumsuz en üstte,
# uygun en altta. Hem web sonuç sayfası hem PDF rapor aynı sırayı kullanır.
VERDICT_PRIORITY = {
    "needs_review": 0, "contradicted": 1, "not_mentioned": 2,
    "partial": 3, "out_of_scope": 4, "satisfied_by_ref": 5, "satisfied": 6,
}


def sorted_findings(findings: list[dict]) -> list[dict]:
    return sorted(findings, key=lambda f: VERDICT_PRIORITY.get(f["verdict"], 9))


def verdict_tr(v: str) -> str:
    return VERDICT_LABEL.get(v, v)


def ring_tr(r: str) -> str:
    return RING_LABEL.get(r, r)


def severity_tr(s: str) -> str:
    return SEVERITY_LABEL.get(s, s or "—")
