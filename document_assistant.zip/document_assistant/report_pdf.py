# -*- coding: utf-8 -*-
"""report_pdf.py — aynı taramadan üç ayrı PDF:

  build_team_pdf      EKİP RAPORU (kısa) — belge sahibi ekibe gider. Yalnızca
                      "belgede şunlar değiştirilmeli" ve önerilen metin; BSEB,
                      madde numarası, karar etiketi YOK.
  build_internal_pdf  İÇ RAPOR — bölüm bazlı birleştirilmiş bulgular, dayandığı
                      BSEB maddeleri, insan incelemesi bekleyenler.
  build_pdf_report    AYRINTILI DENETİM KAYDI — her BSEB maddesinin tek tek
                      sonucu, alıntılar (sonuç sayfasının eski hâli).

reportlab'ın standart 14 fontu (Helvetica) Türkçe'ye özgü ğ/ş/ı/İ
karakterlerini içermeyen WinAnsi kodlamasını kullanır — bu yüzden reportlab
paketinin kendi içinde gelen Bitstream Vera Sans (TTF, tam Unicode/WGL4
kapsamı, ayrı bir indirme ya da lisans sorunu yok) gömülü font olarak
kaydedilir.
"""
from __future__ import annotations
import json
from xml.sax.saxutils import escape

from .labels import VERDICT_LABEL, SEVERITY_LABEL, sorted_findings

VERDICT_COLOR = {
    "satisfied": "#2E7D1F", "satisfied_by_ref": "#2E7D1F",
    "partial": "#B9790A", "not_mentioned": "#B33333", "contradicted": "#B33333",
    "needs_review": "#5B4BC4", "out_of_scope": "#767676",
}


def _recommendation(raw: str) -> dict:
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return {}


_REGISTERED = False


def _ensure_fonts(pdfmetrics, TTFont, font_dir: str) -> None:
    global _REGISTERED
    if _REGISTERED:
        return
    pdfmetrics.registerFont(TTFont("Vera", f"{font_dir}/Vera.ttf"))
    pdfmetrics.registerFont(TTFont("Vera-Bold", f"{font_dir}/VeraBd.ttf"))
    pdfmetrics.registerFont(TTFont("Vera-Italic", f"{font_dir}/VeraIt.ttf"))
    _REGISTERED = True


def _styles(ParagraphStyle, colors) -> dict:
    return {
        "title": ParagraphStyle("title", fontName="Vera-Bold", fontSize=17, leading=22,
                                spaceAfter=4, textColor=colors.HexColor("#1A1A1A")),
        "meta": ParagraphStyle("meta", fontName="Vera", fontSize=9, leading=13,
                               textColor=colors.HexColor("#5f6368"), spaceAfter=14),
        "doc_h": ParagraphStyle("doc_h", fontName="Vera-Bold", fontSize=13, leading=17,
                                spaceBefore=16, spaceAfter=8,
                                textColor=colors.HexColor("#1A1A1A")),
        "madde": ParagraphStyle("madde", fontName="Vera-Bold", fontSize=10.5, leading=14,
                                spaceBefore=10),
        "req_text": ParagraphStyle("req_text", fontName="Vera-Italic", fontSize=9.3,
                                   leading=13, textColor=colors.HexColor("#5f6368"),
                                   spaceAfter=4),
        "label": ParagraphStyle("label", fontName="Vera-Bold", fontSize=7.5, leading=11,
                                textColor=colors.HexColor("#5f6368"), spaceBefore=6),
        "body": ParagraphStyle("body", fontName="Vera", fontSize=9.5, leading=13.5),
        "quote": ParagraphStyle("quote", fontName="Vera-Italic", fontSize=9.3, leading=13,
                                textColor=colors.HexColor("#333333")),
        "empty": ParagraphStyle("empty", fontName="Vera-Italic", fontSize=9.5,
                                textColor=colors.HexColor("#9AA0A6")),
        "bullet": ParagraphStyle("bullet", fontName="Vera", fontSize=9.5, leading=13.5,
                                 leftIndent=10, spaceAfter=3),
        "meta_tight": ParagraphStyle("meta_tight", fontName="Vera", fontSize=8.5, leading=12,
                                     textColor=colors.HexColor("#5f6368"), spaceAfter=2),
    }


def _toolkit():
    """reportlab yalnızca PDF istendiğinde import edilir."""
    import os
    import reportlab
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, SimpleDocTemplate,
                                    Spacer, Table, TableStyle)
    _ensure_fonts(pdfmetrics, TTFont, os.path.join(os.path.dirname(reportlab.__file__), "fonts"))
    return dict(colors=colors, A4=A4, ParagraphStyle=ParagraphStyle, cm=cm,
                KeepTogether=KeepTogether, PageBreak=PageBreak, Paragraph=Paragraph,
                SimpleDocTemplate=SimpleDocTemplate, Spacer=Spacer, Table=Table,
                TableStyle=TableStyle)


def _para_text(text: str) -> str:
    """Satır sonlarını koruyarak PDF paragrafına çevirir."""
    return escape(text or "").replace("\n", "<br/>")


def _boxed(t, width, flowable, bg: str):
    box = t["Table"]([[flowable]], colWidths=[width])
    box.setStyle(t["TableStyle"]([
        ("BACKGROUND", (0, 0), (-1, -1), t["colors"].HexColor(bg)),
        ("LEFTPADDING", (0, 0), (-1, -1), 10), ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    return box


def _doc_template(t, buf, title: str):
    cm = t["cm"]
    return t["SimpleDocTemplate"](buf, pagesize=t["A4"], title=title,
                                  topMargin=2 * cm, bottomMargin=2 * cm,
                                  leftMargin=2 * cm, rightMargin=2 * cm)


def _doc_title(doc_rec: dict) -> str:
    p = doc_rec.get("profile", {}) or {}
    title = p.get("title") or doc_rec.get("document_id", "")
    return f"{title} ({p['document_code']})" if p.get("document_code") else title


def _group_heading(g: dict) -> str:
    if g.get("kind") == "absent":
        return f"Belgeye eklenmesi gereken konu: {g['title']}"
    return g["title"]


SEVERITY_TEAM = {"critical": "Öncelik: çok yüksek", "high": "Öncelik: yüksek",
                 "medium": "Öncelik: orta", "low": "Öncelik: düşük"}


def build_team_pdf(result: dict) -> bytes:
    """Belge sahibi ekibe gidecek kısa rapor. Bilerek SADE: düzenleme adı,
    madde numarası, karar etiketi, model gerekçesi, güven — hiçbiri yok.
    İnsan incelemesi bekleyen maddeler de girmez (henüz kesin değiller)."""
    import io
    from datetime import date
    t = _toolkit()
    st = _styles(t["ParagraphStyle"], t["colors"])
    P, Spacer = t["Paragraph"], t["Spacer"]
    buf = io.BytesIO()
    doc = _doc_template(t, buf, "Belge Revizyon Talepleri")

    elements = [P("Belge Revizyon Talepleri", st["title"]),
                P(f"Tarih: {date.today().strftime('%d.%m.%Y')}", st["meta"])]
    for i, doc_rec in enumerate(result.get("documents", [])):
        if i:
            elements.append(t["PageBreak"]())
        groups = doc_rec.get("change_groups", [])
        elements.append(P(escape(_doc_title(doc_rec)), st["doc_h"]))
        if not groups:
            elements.append(P("Bu belgede değişiklik talebi yok.", st["empty"]))
            continue
        elements.append(P(f"Bu belgede {len(groups)} bölümde değişiklik yapılması gerekiyor. "
                          "Öncelikli olanlar başta listelenmiştir.", st["body"]))
        elements.append(Spacer(1, 6))
        for n, g in enumerate(groups, 1):
            block = [P(f"Talep {n} — {escape(_group_heading(g))}", st["madde"]),
                     P(escape(SEVERITY_TEAM.get(g.get("severity"), "")), st["meta_tight"]),
                     P("YAPILMASI GEREKENLER", st["label"])]
            block += [P("•&nbsp;&nbsp;" + escape(c["text"]), st["bullet"])
                      for c in g.get("change_requests", [])]
            if g.get("proposed_text"):
                block.append(P("ÖNERİLEN METİN", st["label"]))
                block.append(_boxed(t, doc.width, P(_para_text(g["proposed_text"]), st["body"]),
                                    "#F1F8F1"))
            block.append(Spacer(1, 8))
            elements.append(t["KeepTogether"](block[:4]))
            elements += block[4:]
    doc.build(elements)
    return buf.getvalue()


def build_internal_pdf(result: dict) -> bytes:
    """Bizim için: bölüm bazlı birleştirilmiş bulgular + dayandığı maddeler
    + insan incelemesi bekleyenler + uyarılar. Madde madde ayrıntı için
    build_pdf_report."""
    import io
    t = _toolkit()
    st = _styles(t["ParagraphStyle"], t["colors"])
    P, Spacer = t["Paragraph"], t["Spacer"]
    buf = io.BytesIO()
    doc = _doc_template(t, buf, "BSEB Uygunluk — İç Rapor")

    elements = [P("BSEB Uygunluk Değerlendirmesi — İç Rapor", st["title"]),
                P(f"Rapor no: {escape(str(result.get('run_id', '')))}", st["meta"])]
    for i, doc_rec in enumerate(result.get("documents", [])):
        if i:
            elements.append(t["PageBreak"]())
        groups = doc_rec.get("change_groups", [])
        review = doc_rec.get("review_items", [])
        elements.append(P(escape(_doc_title(doc_rec)), st["doc_h"]))
        n_items = sum(len(g["items"]) for g in groups)
        elements.append(P(f"{n_items} olumsuz bulgu {len(groups)} değişiklik talebinde "
                          f"birleştirildi · {len(review)} madde insan incelemesi bekliyor.",
                          st["body"]))
        for w in doc_rec.get("warnings", []):
            elements.append(P("Uyarı: " + escape(w), st["meta"]))
        elements.append(Spacer(1, 6))

        for n, g in enumerate(groups, 1):
            articles = sorted({it["article"] for it in g["items"] if it.get("article")})
            both = any(it.get("both_checks") for it in g["items"])
            color = VERDICT_COLOR["contradicted"] if g["severity"] in ("critical", "high") \
                else VERDICT_COLOR["partial"]
            elements.append(P(f"Talep {n} — {escape(_group_heading(g))} &nbsp;&nbsp;"
                              f"<font color='{color}'>{escape(SEVERITY_LABEL.get(g['severity'], ''))}</font>",
                              st["madde"]))
            elements.append(P("BSEB " + escape(", ".join(articles) or "—")
                              + (" · iki kontrol de buldu" if both else ""), st["meta_tight"]))
            if g.get("error"):
                elements.append(P("⚠ " + escape(g["error"]), st["meta_tight"]))
            if g.get("internal_summary"):
                elements.append(P("DEĞERLENDİRME", st["label"]))
                elements.append(P(escape(g["internal_summary"]), st["body"]))
            elements.append(P("YAPILMASI GEREKENLER (ekibe giden metin)", st["label"]))
            for c in g.get("change_requests", []):
                note = (" <font color='#B9790A'>(model atlamıştı, otomatik eklendi)</font>"
                        if c.get("added") else "")
                elements.append(P("•&nbsp;&nbsp;" + escape(c["text"]) + note, st["bullet"]))
            if g.get("proposed_text"):
                elements.append(P("ÖNERİLEN METİN", st["label"]))
                elements.append(_boxed(t, doc.width, P(_para_text(g["proposed_text"]), st["body"]),
                                       "#F1F8F1"))
            elements.append(P("DAYANDIĞI MADDELER", st["label"]))
            for it in g["items"]:
                elements.append(P(f"<b>BSEB {escape(it.get('article') or '—')}</b> · "
                                  f"{escape(VERDICT_LABEL.get(it['verdict'], it['verdict']))} — "
                                  f"{escape(it.get('requirement_text', ''))}", st["bullet"]))
            elements.append(Spacer(1, 8))

        if review:
            elements.append(P("İnsan incelemesi bekleyenler", st["doc_h"]))
            elements.append(P("Model bu maddelerde güvenilir bir karar veremedi; ekip raporuna "
                              "girmedi.", st["meta"]))
            for it in review:
                elements.append(P(f"<b>BSEB {escape(it.get('article') or '—')}</b> — "
                                  f"{escape(it.get('requirement_text', ''))}", st["bullet"]))
                if it.get("rationale"):
                    elements.append(P(escape(it["rationale"]), st["meta_tight"]))
    doc.build(elements)
    return buf.getvalue()


def build_pdf_report(result: dict) -> bytes:
    # reportlab burada, fonksiyon içinde import edilir — LDAP (ldap3) ve Word
    # yorumları (python-docx) için zaten kurulu olan aynı kural: PDF/Word
    # çıktısı hiç kullanılmayan bir kurulumda uygulamanın AÇILMASINI
    # engellememeli, sadece bu özelliğe dokunulduğunda gerekli olmalı.
    import io
    import os

    import reportlab
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import (PageBreak, Paragraph, SimpleDocTemplate,
                                    Spacer, Table, TableStyle)

    font_dir = os.path.join(os.path.dirname(reportlab.__file__), "fonts")
    _ensure_fonts(pdfmetrics, TTFont, font_dir)
    st = _styles(ParagraphStyle, colors)

    def check_banner(width: float, num: str, num_bg: str, bg: str,
                     title: str, subtitle: str) -> Table:
        content = Paragraph(
            f'<font color="{num_bg}"><b>{escape(num)}</b></font>&nbsp;&nbsp;'
            f'<b>{escape(title)}</b><br/>'
            f'<font size="8" color="#5f6368">{escape(subtitle)}</font>', st["body"])
        t = Table([[content]], colWidths=[width])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(bg)),
            ("LEFTPADDING", (0, 0), (-1, -1), 10),
            ("RIGHTPADDING", (0, 0), (-1, -1), 10),
            ("TOPPADDING", (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        return t

    def render_finding(elements: list, f: dict) -> None:
        color = VERDICT_COLOR.get(f["verdict"], "#767676")
        verdict_tr = VERDICT_LABEL.get(f["verdict"], f["verdict"])
        head = (f"BSEB {escape(f.get('article') or '—')} &nbsp;&nbsp; "
                f"<font color='{color}'>{escape(verdict_tr)}</font>")
        elements.append(Paragraph(head, st["madde"]))
        if f.get("requirement_text"):
            elements.append(Paragraph("BSEB MADDESİ", st["label"]))
            elements.append(Paragraph(escape(f["requirement_text"]), st["req_text"]))

        if f.get("rationale"):
            elements.append(Paragraph("YORUM", st["label"]))
            elements.append(Paragraph(escape(f["rationale"]), st["body"]))

        if f.get("missing_elements"):
            elements.append(Paragraph("EKSİK", st["label"]))
            elements.append(Paragraph(escape(", ".join(f["missing_elements"])), st["body"]))

        for ev in f.get("evidence", []):
            if ev.get("quote"):
                elements.append(Paragraph("BELGEDE YAZAN", st["label"]))
                elements.append(Paragraph("“" + escape(ev["quote"]) + "”", st["quote"]))

        rec = _recommendation(f.get("recommendation", ""))
        if rec.get("recommendation"):
            sev = SEVERITY_LABEL.get(rec.get("severity", ""), "")
            label_text = "ÖNERİ" + (f" ({escape(sev)})" if sev else "")
            elements.append(Paragraph(label_text, st["label"]))
            elements.append(Paragraph(escape(rec["recommendation"]), st["body"]))

        elements.append(Spacer(1, 6))

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title="BSEB Uygunluk — Ayrıntılı Denetim Kaydı",
                            topMargin=2 * cm, bottomMargin=2 * cm,
                            leftMargin=2 * cm, rightMargin=2 * cm)

    elements = [
        Paragraph("BSEB Uygunluk — Ayrıntılı Denetim Kaydı", st["title"]),
        Paragraph(f"Rapor no: {escape(str(result.get('run_id', '')))}", st["meta"]),
    ]

    documents = result.get("documents", [])
    for i, doc_rec in enumerate(documents):
        if i:
            elements.append(PageBreak())
        title = doc_rec.get("profile", {}).get("title") or doc_rec.get("document_id", "")
        elements.append(Paragraph(escape(title), st["doc_h"]))

        for w in doc_rec.get("warnings", []):
            elements.append(Paragraph("Uyarı: " + escape(w), st["meta"]))

        elements.append(check_banner(
            doc.width, "1", "#2E7D1F", "#F1F8F1", "1. Kontrol — Kural -> Belge",
            "BSEB'in her maddesi tek tek ele alınır: bu madde, bu belgede karşılanıyor mu?"))
        elements.append(Spacer(1, 8))
        findings = [f for f in doc_rec.get("findings", []) if f.get("verdict") != "out_of_scope"]
        findings = sorted_findings(findings)
        if not findings:
            elements.append(Paragraph("Bulgu yok.", st["empty"]))
        for f in findings:
            render_finding(elements, f)

        elements.append(check_banner(
            doc.width, "2", "#5B4BC4", "#F1EEFC",
            "2. Kontrol — Belge -> Kural (bağımsız ikinci tarama)",
            "Konu sınıflandırmasından TAMAMEN bağımsız: belgenin metni BSEB'in tamamına "
            "aykırı bir şey söylüyor mu? 1. Kontrol'ün hiç bakmadığı bir maddeye aykırılık "
            "burada da yakalanabilir."))
        elements.append(Spacer(1, 8))
        reverse_findings = sorted_findings(doc_rec.get("reverse_findings", []))
        if not reverse_findings:
            elements.append(Paragraph("Aykırı bir ifade bulunamadı.", st["empty"]))
        for f in reverse_findings:
            render_finding(elements, f)

    doc.build(elements)
    return buf.getvalue()
