#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Entry point.

    python -m compliance_workflow.main run     --documents ./documents
    python -m compliance_workflow.main extract --documents ./documents
    python -m compliance_workflow.main graph
    python -m compliance_workflow.main check
"""
from __future__ import annotations
import argparse, json, sys, uuid
from datetime import datetime
from pathlib import Path

from .config import Config
from .extract import extract as extract_docx
from .registry import load_registry


def _documents(folder: str) -> list[str]:
    root = Path(folder)
    return sorted(str(p) for p in root.rglob("*")
                  if p.suffix.lower() in (".docx", ".doc") and not p.name.startswith("~$"))


# ------------------------------------------------------------------ extract
def cmd_extract(cfg: Config) -> int:
    out = Path(cfg.paths.extract_dir)
    out.mkdir(parents=True, exist_ok=True)
    paths = _documents(cfg.paths.documents_dir)
    print(f"{len(paths)} document(s) in {cfg.paths.documents_dir}")
    for p in paths:
        try:
            data = extract_docx(p, tracked_changes=cfg.policy.tracked_changes)
        except Exception as exc:                                # noqa: BLE001
            print(f"  FAIL  {Path(p).name}: {type(exc).__name__}: {exc}")
            continue
        (out / f"{Path(p).stem}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        (out / f"{Path(p).stem}.md").write_text(data["markdown"], encoding="utf-8")
        flag = "  ⚠" if data["warnings"] else ""
        print(f"  ok    {Path(p).name}  {data['stats']}{flag}")
    return 0


# ---------------------------------------------------------------------- run
def cmd_run(cfg: Config) -> int:
    from .graph import build, make_checkpointer
    from .search import build_search

    cmd_extract(cfg)

    search_fn = build_search(cfg.paths.extract_dir)
    Path(cfg.paths.checkpoint_db).parent.mkdir(parents=True, exist_ok=True)

    with make_checkpointer(cfg.paths.checkpoint_db) as checkpointer:
        corpus_graph, _, registry, _ = build(cfg, search_fn, checkpointer)

        run_id = cfg.run_id or datetime.now().strftime("%Y%m%d-%H%M%S")
        paths = _documents(cfg.paths.documents_dir)
        print(f"\nreviewing {len(paths)} document(s) against "
              f"{len(registry.requirements)} requirements\n")

        result = corpus_graph.invoke(
            {"run_id": run_id, "document_paths": paths, "documents": []},
            config={"configurable": {"thread_id": run_id},
                    "recursion_limit": 10_000},
        )

    _summary(result)
    print(f"\nreport: {result.get('report_path')}")
    return 0


def _summary(result: dict) -> None:
    counts: dict[str, int] = {}
    review = 0
    for doc in result.get("documents", []):
        for f in doc.get("findings", []):
            counts[f["verdict"]] = counts.get(f["verdict"], 0) + 1
            if f["verdict"] == "needs_review":
                review += 1
    print("\nverdicts")
    for verdict, n in sorted(counts.items(), key=lambda x: -x[1]):
        print(f"  {verdict:<18}{n:5d}")
    print(f"\nneeds human review : {review}")
    print(f"uncovered requirements: {len(result.get('orphan_requirements', []))}")


# -------------------------------------------------------------------- graph
def cmd_graph(cfg: Config) -> int:
    from .config import ROOT
    from .render_graph import write
    docs_dir = ROOT / "docs"
    docs_dir.mkdir(exist_ok=True)
    path = write(str(docs_dir))
    print(f"diagram: {path}")

    try:
        from .graph import build_document_graph, build_corpus_graph
        from .llm import LLMClient
        from .registry import Registry
        client, empty = LLMClient(cfg.llm), Registry([], [])
        dg = build_document_graph(client, empty, cfg)
        cg = build_corpus_graph(client, empty, cfg, dg, lambda q, k=5: [])
        (docs_dir / "workflow_document.mmd").write_text(
            dg.get_graph().draw_mermaid(), encoding="utf-8")
        (docs_dir / "workflow_corpus.mmd").write_text(
            cg.get_graph().draw_mermaid(), encoding="utf-8")
        print(f"mermaid: {docs_dir / 'workflow_document.mmd'}, "
              f"{docs_dir / 'workflow_corpus.mmd'}")
    except Exception as exc:                                    # noqa: BLE001
        print(f"mermaid export skipped: {exc}")
    return 0


# -------------------------------------------------------------------- check
def cmd_check(cfg: Config) -> int:
    """Pre-flight: .env, register, bank profile, graph wiring, LLM endpoint."""
    from .config import ENV_FILE
    ok = True

    print(f"  env        {ENV_FILE or 'no .env found — using process environment'}")

    try:
        reg = load_registry(cfg.paths.register_xlsx,
                            cfg.paths.register_sheet, cfg.paths.topics_sheet)
        print(f"  register   {len(reg.requirements)} requirements, "
              f"{len(reg.topics)} topics, {len(reg.universal)} universal")
        bad = [r["req_id"] for r in reg.requirements
               if r["primary_topic"] not in reg.topic_codes]
        if bad:
            ok = False
            print(f"  ERROR      unknown primary topic on: {', '.join(bad[:5])}")
    except Exception as exc:                                    # noqa: BLE001
        ok = False
        print(f"  register   FAILED: {exc}")

    # Conditional requirements: an unanswered condition is not an error, but it
    # sends the requirement to a human instead of deciding it, so say so here
    # rather than letting it surface as warnings halfway through a long run.
    try:
        codes = {r["condition_code"] for r in reg.requirements if r["condition_code"]}
        answered = cfg.policy.condition_flags
        print(f"  profile    {len(answered)}/{len(codes)} conditions answered"
              f"  ({Path(cfg.paths.bank_profile_json).name})")
        if len(answered) < len(codes):
            print("             unanswered -> human review: "
                  + ", ".join(sorted(codes - set(answered))[:4])
                  + (" ..." if len(codes) - len(answered) > 4 else ""))
    except Exception:                                           # noqa: BLE001
        pass

    try:
        from .graph import build_document_graph, build_corpus_graph
        from .llm import LLMClient
        from .registry import Registry
        client, empty = LLMClient(cfg.llm), Registry([], [])
        dg = build_document_graph(client, empty, cfg)
        build_corpus_graph(client, empty, cfg, dg, lambda q, k=5: [])
        print(f"  graphs     compiled ({len(list(dg.get_graph().nodes))} document nodes)")
    except Exception as exc:                                    # noqa: BLE001
        ok = False
        print(f"  graphs     FAILED: {exc}")

    try:
        import httpx
        r = httpx.get(cfg.llm.base_url.rstrip('/') + "/models", timeout=10,
                      headers=cfg.llm.headers, verify=cfg.llm.verify)
        print(f"  llm        {cfg.llm.base_url} -> HTTP {r.status_code}")
    except Exception as exc:                                    # noqa: BLE001
        print(f"  llm        unreachable ({type(exc).__name__}: {exc}) — "
              f"set LLM_BASE_URL / LLM_API_KEY / LLM_CA_BUNDLE")

    print("\nready" if ok else "\nnot ready")
    return 0 if ok else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="compliance_workflow")
    ap.add_argument("command",
                    choices=["run", "extract", "graph", "check", "trace"])
    ap.add_argument("--documents", default=None)
    ap.add_argument("--document", default=None,
                    help="trace: the single .docx to walk through")
    ap.add_argument("--req", default="",
                    help="trace: show this requirement in full instead of the first")
    ap.add_argument("--topics", default="",
                    help="trace: force the declared topics (comma-separated)")
    ap.add_argument("--register", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--tracked-changes", default=None,
                    choices=["accepted", "original", "all"])
    ap.add_argument("--run-id", default=None)
    args = ap.parse_args(argv)

    cfg = Config()
    if args.documents:
        cfg.paths.documents_dir = args.documents
    if args.register:
        cfg.paths.register_xlsx = args.register
    if args.out:
        cfg.paths.report_dir = args.out
    if args.tracked_changes:
        cfg.policy.tracked_changes = args.tracked_changes
    cfg.run_id = args.run_id or uuid.uuid4().hex[:8]

    if args.command == "trace":
        from .trace import run as cmd_trace
        doc = args.document or next(iter(_documents(cfg.paths.documents_dir)), "")
        if not doc:
            print("no document found; pass --document")
            return 1
        return cmd_trace(cfg, doc, only_req=args.req, topics=args.topics)

    return {"run": cmd_run, "extract": cmd_extract,
            "graph": cmd_graph, "check": cmd_check}[args.command](cfg)


if __name__ == "__main__":
    sys.exit(main())
