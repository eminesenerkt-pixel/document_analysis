# -*- coding: utf-8 -*-
"""Tüm projenin üst-seviye mimari diyagramı (Türkçe, YATAY akış — soldan sağa).

`render_graph.py`'den farkı: o dosya LangGraph düğüm akışının ayrıntısını
çizer (document graph + corpus graph, tek bir motor). Bu dosya bir kat
yukarıdan bakar — BSEB düzenlemesinin 255 kurala dönüştürülmesinden web
arayüzüne kadar tüm bileşenleri ve aralarındaki veri akışını gösterir.

Akış SOLDAN SAĞA okunur (sunumda tek slayda sığması için): her "adım" bir
sütun, sütun içindeki kutular yukarıdan aşağı o adımın parçalarıdır.

    python -m <proje klasörü>.render_architecture
"""
from __future__ import annotations
from html import escape
from pathlib import Path

MARGIN = 60
COL_GAP = 46
HEADER_H = 96

STYLE = {
    "veri":   ("#ECEFF1", "#546E7A"),   # girdi/çıktı verisi
    "kod":    ("#E3F2FD", "#1565C0"),   # deterministik kod
    "llm":    ("#F3E5F5", "#7B1FA2"),   # model çağrısı
    "dis":    ("#E0F2F1", "#00695C"),   # kurum içi dış sistem (AD, ağ geçidi)
    "arayuz": ("#E8F5E9", "#2E7D1F"),   # kullanıcı arayüzü (KT marka rengi)
}

FONT = ("-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, "
        "'Helvetica Neue', Arial, sans-serif")


class Box:
    def __init__(self, cx, cy, w, h=64):
        self.cx, self.cy, self.w, self.h = cx, cy, w, h
    @property
    def left(self): return self.cx - self.w / 2
    @property
    def right(self): return self.cx + self.w / 2
    @property
    def top(self): return self.cy - self.h / 2
    @property
    def bottom(self): return self.cy + self.h / 2


def node_svg(box: Box, label: str, kind: str, sub: str = "") -> str:
    fill, stroke = STYLE[kind]
    label, sub = escape(label), escape(sub)
    out = [f'<rect x="{box.left:.0f}" y="{box.top:.0f}" width="{box.w:.0f}" '
           f'height="{box.h:.0f}" rx="10" fill="{fill}" stroke="{stroke}" stroke-width="1.8"/>']
    if sub:
        out.append(f'<text x="{box.cx:.0f}" y="{box.cy - 6:.0f}" text-anchor="middle" '
                   f'font-family="{FONT}" font-size="14" font-weight="700" '
                   f'fill="#1a1a1a">{label}</text>')
        for i, line in enumerate(_wrap(sub, int(box.w / 6.3))):
            out.append(f'<text x="{box.cx:.0f}" y="{box.cy + 13 + i * 13.5:.0f}" text-anchor="middle" '
                       f'font-family="{FONT}" font-size="10.5" fill="#5f6368">{line}</text>')
    else:
        out.append(f'<text x="{box.cx:.0f}" y="{box.cy + 5:.0f}" text-anchor="middle" '
                   f'font-family="{FONT}" font-size="14" font-weight="700" '
                   f'fill="#1a1a1a">{label}</text>')
    return "".join(out)


def edge_point(box: Box, side: str):
    return {"top": (box.cx, box.top), "bottom": (box.cx, box.bottom),
            "left": (box.left, box.cy), "right": (box.right, box.cy)}[side]


def arrow(p1, p2, label="", dashed=False, curve=0, color="#5f6368"):
    x1, y1 = p1
    x2, y2 = p2
    dash = ' stroke-dasharray="6 4"' if dashed else ""
    if curve:
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2 + curve
        d = f"M {x1:.0f} {y1:.0f} Q {mx:.0f} {my:.0f} {x2:.0f} {y2:.0f}"
    else:
        d = f"M {x1:.0f} {y1:.0f} L {x2:.0f} {y2:.0f}"
    out = [f'<path d="{d}" fill="none" stroke="{color}" stroke-width="1.8"'
           f'{dash} marker-end="url(#ok)"/>']
    if label:
        label = escape(label)
        lx = (x1 + x2) / 2
        ly = (y1 + y2) / 2 + (curve * 0.55 if curve else 0)
        tw = len(label) * 6.2 + 12
        out.append(f'<rect x="{lx - tw/2:.0f}" y="{ly - 10:.0f}" width="{tw:.0f}" '
                   f'height="19" rx="4" fill="#ffffff" opacity="0.96"/>')
        out.append(f'<text x="{lx:.0f}" y="{ly + 4:.0f}" text-anchor="middle" '
                   f'font-family="{FONT}" font-size="11" fill="#3c4043">{label}</text>')
    return "".join(out)


def panel(x, y, w, h, title, subtitle):
    title_lines = _wrap(title, int(w / 8.5))
    sub_lines = _wrap(subtitle, int(w / 6.8))
    out = [
        f'<rect x="{x:.0f}" y="{y:.0f}" width="{w:.0f}" height="{h:.0f}" rx="14" '
        f'fill="#FAFBFC" stroke="#DADCE0" stroke-width="1.5"/>'
    ]
    ty = y + 26
    for line in title_lines:
        out.append(f'<text x="{x + 20:.0f}" y="{ty:.0f}" font-family="{FONT}" font-size="15" '
                   f'font-weight="700" fill="#1a1a1a">{escape(line)}</text>')
        ty += 20
    for line in sub_lines:
        out.append(f'<text x="{x + 20:.0f}" y="{ty:.0f}" font-family="{FONT}" font-size="10.5" '
                   f'fill="#5f6368">{escape(line)}</text>')
        ty += 14
    return "".join(out)


def col(x_center: float, y_start: float, specs: list[tuple], gap: float = 26) -> list[Box]:
    """`specs`: [(genişlik, yükseklik), ...] — sütun ortasına hizalı, yukarıdan
    aşağı `gap` boşluklu bir kutu dizisi döner."""
    boxes, y = [], y_start
    for w, h in specs:
        boxes.append(Box(x_center, y + h / 2, w, h))
        y += h + gap
    return boxes


def _wrap(text: str, width: int) -> list[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width:
            lines.append(cur); cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return lines


def build_svg() -> str:
    s: list[str] = []

    # Sütun genişlikleri (soldan sağa akış derinliği)
    widths = [300, 300, 300, 340, 300, 300]
    xs = [MARGIN]
    for w in widths[:-1]:
        xs.append(xs[-1] + w + COL_GAP)
    x1, x2, x3, x4, x5, x6 = xs
    top = HEADER_H + 20

    # ---------------------------------------------------------- 1 · girdi
    girdi = col(x1 + widths[0] / 2, top + 58, [(widths[0] - 24, 56)] * 3, gap=22)
    bseb_pdf, register, docs = girdi

    # ------------------------------------------------------- 2 · çıkarım
    cikarim = col(x2 + widths[1] / 2, top + 58, [(widths[1] - 24, 58)] * 2, gap=26)
    reg_py, extract_py = cikarim

    # ------------------------------------------------ 3 · çekirdek motor
    motor = col(x3 + widths[2] / 2, top + 58, [(widths[2] - 24, 64)] * 2, gap=30)
    doc_graph, corpus_graph = motor

    # -------------------------------------------- 4 · LLM (üst) + AD (alt)
    col4_w = widths[3] - 24
    llm_col = col(x4 + widths[3] / 2, top + 58, [(col4_w, 54)] * 3, gap=18)
    llm_py, gateway, qwen = llm_col
    ad_top = llm_col[-1].bottom + 56
    ad_col = col(x4 + widths[3] / 2, ad_top, [(col4_w, 54)] * 3, gap=18)
    directory_py, auth_py, ad_server = ad_col

    # ------------------------------------------------------ 5 · arayüzler
    arayuz = col(x5 + widths[4] / 2, top + 58, [(widths[4] - 24, 56)] * 2, gap=26)
    cli, web = arayuz
    brand = Box(web.cx, web.bottom + 26 + 28, widths[4] - 24, 56)

    # ---------------------------------------------------------- 6 · çıktı
    report = Box(x6 + widths[5] / 2, top + 58 + 28, widths[5] - 24, 74)

    col_bottoms = [
        girdi[-1].bottom, cikarim[-1].bottom, motor[-1].bottom + 50,
        ad_col[-1].bottom, brand.bottom, report.bottom,
    ]
    body_bottom = max(col_bottoms) + 24
    W = xs[-1] + widths[-1] + MARGIN
    notes_y = body_bottom + 16
    notes_h = 96
    H = notes_y + notes_h + 56

    # =================================================================== çiz
    s.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W:.0f}" height="{H:.0f}" '
             f'viewBox="0 0 {W:.0f} {H:.0f}">')
    s.append('<defs><marker id="ok" viewBox="0 0 10 10" refX="9" refY="5" '
             'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
             '<path d="M 0 0 L 10 5 L 0 10 z" fill="#5f6368"/></marker></defs>')
    s.append(f'<rect width="{W:.0f}" height="{H:.0f}" fill="#ffffff"/>')

    s.append(f'<text x="{MARGIN}" y="34" font-family="{FONT}" font-size="22" '
             f'font-weight="700" fill="#1a1a1a">BSEB Uygunluk Taraması — Proje Mimarisi</text>')
    s.append(f'<text x="{MARGIN}" y="56" font-family="{FONT}" font-size="12.5" fill="#5f6368">'
             f'Düzenleme metninden web arayüzünde görüntülenen bulguya kadar tüm bileşenler — soldan sağa okunur.</text>')

    # sütun panelleri (yükseklikleri kendi içeriklerine göre, tepesi hizalı)
    def col_h(boxes_bottom):
        return boxes_bottom - top + 20

    s.append(panel(x1, top - 4, widths[0], col_h(girdi[-1].bottom), "1 · Girdi",
                   "regülasyon bir kere elle kurala dönüştürülür"))
    s.append(node_svg(bseb_pdf, "BSEB Yönetmeliği (PDF)", "veri", "elle, bir kere"))
    s.append(node_svg(register, "bseb_register.xlsx", "veri", "255 kural · 54 konu · 15 koşul"))
    s.append(node_svg(docs, "Banka Dokümanları (.docx)", "veri", "her taramada yeniden okunur"))
    s.append(arrow(edge_point(bseb_pdf, "bottom"), edge_point(register, "top"), "elle"))

    s.append(panel(x2, top - 4, widths[1], col_h(cikarim[-1].bottom), "2 · Çıkarım",
                   "kod, model yok — kurala ve belgeye yapı kazandırır"))
    s.append(node_svg(reg_py, "registry.py", "kod", "Excel → 255 atomik kural nesnesi"))
    s.append(node_svg(extract_py, "extract.py", "kod", "OOXML → bloklar + markdown"))
    s.append(arrow(edge_point(register, "right"), edge_point(reg_py, "left")))
    s.append(arrow(edge_point(docs, "right"), edge_point(extract_py, "left")))

    s.append(panel(x3, top - 4, widths[2], col_h(motor[-1].bottom + 50), "3 · Çekirdek Motor",
                   "gereksinim TABLO SORGUSUYLA seçilir — asla benzerlik aramasıyla değil"))
    s.append(node_svg(doc_graph, "Document Graph", "kod", "1 belge → iki yönlü doğrulanmış bulgular"))
    s.append(node_svg(corpus_graph, "Corpus Graph", "kod", "tüm belgeler → kapsam + rapor"))
    s.append(arrow(edge_point(doc_graph, "bottom"), edge_point(corpus_graph, "top"), "her belge"))
    s.append(arrow(edge_point(reg_py, "right"), edge_point(doc_graph, "left"), "255 kural"))
    s.append(arrow(edge_point(extract_py, "right"), (doc_graph.left, doc_graph.top + 14),
                   "bloklar", curve=-14))
    for i, line in enumerate(_wrap(
            "Düğüm bazlı ayrıntı (4 aşama, karar mantığıyla): docs/asamalar/*.svg",
            int(widths[2] / 6.2))):
        s.append(f'<text x="{corpus_graph.cx:.0f}" y="{corpus_graph.bottom + 22 + i*14:.0f}" '
                 f'text-anchor="middle" font-family="{FONT}" font-size="10.5" '
                 f'fill="#5f6368" font-style="italic">{escape(line)}</text>')

    s.append(panel(x4, top - 4, widths[3], col_h(ad_col[-1].bottom), "4 · Dış Sistemler",
                   "LLM (yargı burada) ve AD (kimlik/dizin) — iki ayrı kullanım"))
    s.append(node_svg(llm_py, "llm.py", "kod", "yapılandırılmış çıktı, self-consistency"))
    s.append(node_svg(gateway, "Kurumsal Ağ Geçidi", "dis", "özel auth, kurum sertifikası"))
    s.append(node_svg(qwen, "Qwen3-235B-A22B (vLLM/TGI)", "llm", ""))
    s.append(arrow(edge_point(llm_py, "bottom"), edge_point(gateway, "top")))
    s.append(arrow(edge_point(gateway, "bottom"), edge_point(qwen, "top")))
    s.append(node_svg(directory_py, "directory.py", "dis", "AD'de var mı? salt okunur"))
    s.append(node_svg(auth_py, "webapp/auth.py", "dis", "web girişi — parola tek seferlik"))
    s.append(node_svg(ad_server, "Kurum Active Directory", "dis", ""))
    s.append(arrow(edge_point(directory_py, "bottom"), edge_point(auth_py, "top")))
    s.append(arrow(edge_point(auth_py, "bottom"), edge_point(ad_server, "top")))
    s.append(arrow(edge_point(doc_graph, "right"), edge_point(llm_py, "left"),
                   "gereksinim+belge", curve=-18))
    s.append(arrow(edge_point(doc_graph, "right"), edge_point(directory_py, "left"),
                   "onaylayan (opsiyonel)", curve=18))

    s.append(panel(x5, top - 4, widths[4], col_h(brand.bottom), "5 · Arayüzler",
                   "aynı motoru iki farklı şekilde çağırırlar"))
    s.append(node_svg(cli, "CLI (main.py)", "arayuz", "run · extract · check · graph"))
    s.append(node_svg(web, "Web Arayüzü (Flask)", "arayuz", "çok kullanıcılı · AD girişi · SSE"))
    s.append(node_svg(brand, "Kuveyt Türk marka kimliği", "arayuz", "logo, marka yeşili"))
    s.append(arrow(edge_point(web, "bottom"), edge_point(brand, "top")))

    s.append(panel(x6, top - 4, widths[5], col_h(report.bottom), "6 · Çıktı",
                   "denetlenebilir, tekrarlanabilir kayıt"))
    s.append(node_svg(report, "findings_{run_id}.json", "veri",
                      "hüküm + kanıt + tavsiye + kapsanmayan gereksinimler"))
    s.append(arrow(edge_point(brand, "right"), (report.left, report.cy), "", curve=0))

    # notlar
    s.append(f'<rect x="{MARGIN}" y="{notes_y:.0f}" width="{W - 2*MARGIN:.0f}" height="{notes_h}" '
             f'rx="14" fill="#FAFBFC" stroke="#DADCE0" stroke-width="1.5"/>')
    s.append(f'<text x="{MARGIN+22}" y="{notes_y+28:.0f}" font-family="{FONT}" font-size="14" '
             f'font-weight="700" fill="#1a1a1a">Bir cümlede tasarım</text>')
    note = ("BSEB metni bir kere, elle, 255 atomik kurala çevrilir — bu dönüşüm denetlenebilir ve "
            "diff'lenebilir bir varlıktır. Çalışma zamanında hiçbir düzenleyici metin parse edilmez; "
            "kurallar her belgeye TABLO SORGUSUYLA (konu eşleşmesi) pushlanır, model sadece 'bu kural "
            "burada karşılanmış mı?' sorusuna tek tek, yapılandırılmış biçimde cevap verir.")
    y = notes_y + 50
    for line in _wrap(note, int((W - 2 * MARGIN - 44) / 6.6)):
        s.append(f'<text x="{MARGIN+22}" y="{y:.0f}" font-family="{FONT}" font-size="12" '
                 f'fill="#3c4043">{escape(line)}</text>')
        y += 17

    # lejant
    ly = H - 16
    items = [("veri", "veri / dosya"), ("kod", "deterministik kod"),
             ("llm", "model çağrısı"), ("dis", "kurum içi dış sistem"),
             ("arayuz", "kullanıcı arayüzü")]
    x = MARGIN
    for kind, label in items:
        fill, stroke = STYLE[kind]
        s.append(f'<rect x="{x}" y="{ly - 12:.0f}" width="20" height="14" rx="3" '
                 f'fill="{fill}" stroke="{stroke}" stroke-width="1.6"/>')
        s.append(f'<text x="{x + 28}" y="{ly:.0f}" font-family="{FONT}" font-size="12" '
                 f'fill="#3c4043">{escape(label)}</text>')
        x += len(label) * 7 + 62

    s.append("</svg>")
    return "".join(s)


def write(out_dir: str = ".") -> Path:
    out = Path(out_dir) / "proje_mimarisi.svg"
    out.write_text(build_svg(), encoding="utf-8")
    return out


if __name__ == "__main__":
    print(write())
