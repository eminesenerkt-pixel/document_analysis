# Kod Rehberi — BSEB Uygunluk Taraması

Bu dosya, projedeki her Python dosyasının ne işe yaradığını, dosya içindeki
her fonksiyon/blok bazında açıklar. Amaç: kodu ilk kez okuyan birinin, hangi
dosyaya bakması gerektiğini ve o dosyanın içindeki her parçanın rolünü
hızlıca kavraması.

Genel mimari: **LangGraph** ile kurulmuş iki graf.
- **Document graph**: tek bir `.docx` dosyasını 255 gereksinime karşı tarar.
- **Corpus graph**: tüm belgeleri tarar, sonra "hiçbir belgede karşılanmayan
  gereksinim var mı?" sorusunu sorar ve rapor üretir.

Model (LLM) sadece **yargı** verir (şu gereksinim karşılanmış mı, hangi
konuları kapsıyor); **hangi gereksinimin kontrol edileceğine asla model karar
vermez** — bu register tablosundaki kurallarla (kod) belirlenir. Bu, raporun
"neden madde 23 kontrol edildi/edilmedi" sorusuna her zaman kanıtlanabilir bir
cevap verebilmesi içindir.

---

## `config.py` — Ayarlar

Tüm ortam değişkenlerini okuyup tip-güvenli `Config` nesnesine dönüştürür.

- **`load_env()`**: Bağımlılıksız, 15 satırlık minik bir `.env` okuyucu.
  Gerçek ortam değişkenleri `.env` dosyasındakini ezer (`override=False`
  varsayılanı), böylece bir zamanlayıcı/CI, dosyaya dokunmadan
  `LLM_API_KEY` enjekte edebilir.
- **`ENV_FILE = load_env()`**: Modül import edilir edilmez `.env` yüklenir.
- **`ROOT`**: Tüm göreli yollar (`data/`, `documents/`, `output/`) paket
  klasörüne göre çözülür — proje hangi dizinden çalıştırılırsa çalıştırılsın
  aynı davranır. `WORKFLOW_ROOT` ile ezilebilir.
- **`_env`, `_env_float`, `_env_int`**: Ortam değişkenini oku, yoksa/parse
  edilemiyorsa varsayılana düş.
- **`LLMConfig`** (dataclass):
  - `base_url`, `api_key`, `model` — LLM uç noktası bilgileri (`LLM_BASE_URL`,
    `LLM_API_KEY`, `LLM_MODEL`; model varsayılanı `Qwen/Qwen3-235B-A22B`).
  - `timeout_s`, `max_retries` — istek zaman aşımı ve deneme sayısı.
  - `min_interval_s` — istekler arası minimum bekleme saniyesi
    (`LLM_MIN_INTERVAL`). Kurumsal gateway'de 0 (kapalı, varsayılan); dakikalık
    token/istek kotası düşük bir uç noktada, paralel dallanan çağrıların
    (fan-out) anında 429 almasını önler.
  - `max_tokens` — yanıtın üst sınırı (`LLM_MAX_TOKENS`, varsayılan 2000).
    Sunucunun kendi varsayılanına bırakmak, thinking modu kapanmazsa ya da
    sunucu farklı davranırsa tek bir çağrının kaçak büyümesine karşı savunma.
  - `api_key_header` / `api_key_prefix` — anahtarın gideceği header adı ve
    öneki (`LLM_API_KEY_HEADER`/`LLM_API_KEY_PREFIX`, varsayılan
    `Authorization`/`Bearer`). Kurumsal bir ağ geçidinin key-auth eklentisi
    (örn. APISIX) genelde kendi header'ını (`apikey`, öneksiz) ister.
  - `extra_headers_raw` / `extra_headers` — ağ geçidinin istediği ek
    yönlendirme header'ları (`LLM_EXTRA_HEADERS`, `"Ad: değer; Ad2: değer2"`
    formatında, property bunu sözlüğe çevirir).
  - `ca_bundle` / `verify_ssl` / `verify` — kurum içi kök sertifika
    (`LLM_CA_BUNDLE`, pakete göre çözülen yol) ve doğrulama açık/kapalı
    (`LLM_VERIFY_SSL`, varsayılan `true`). `verify` property'si httpx'in
    `verify=` parametresinin beklediği değeri (yol ya da bool) döndürür.
  - `headers` — yukarıdakilerden inşa edilen tam header sözlüğü. LLMClient
    VE `main.py check` / `trace.py` / `webapp/routes.py::llm_test`'in bağlantı testleri **aynı**
    bu property'yi kullanır — böylece bir sağlık kontrolü gerçek istemciden
    farklı bir şeyi test etmiş olmaz.
  - `disable_thinking` — Qwen3 gibi modellerin varsayılan ürettiği
    `<think>...</think>` akıl yürütme bloğunu `chat_template_kwargs:
    {"enable_thinking": false}` ile kapatır (`LLM_DISABLE_THINKING`,
    varsayılan `true` — bu projenin hedef modeli Qwen3-235B-A22B olduğu için).
  - `temperature_extract` / `temperature_judge` — her zaman 0.0 (determinizm).
    Qwen3'ün kendi model kartı yalnızca *thinking modunda* greedy decoding'i
    yasaklıyor ("performans düşüşü ve sonsuz tekrar"a yol açabilir); thinking
    kapalı olduğundan T=0 belgelenmiş davranışın dışına çıkmıyor, ama kartın
    genel kalite için önerdiği T=0.7'den feragat ediliyor — determinizm
    bilinçli olarak önceliklendirildi.
  - `temperature_draft` — tavsiye metni yazarken kullanılan sıcaklık
    (`TEMPERATURE_DRAFT`, varsayılan 0.4).
  - `samples_high_risk` — Kritik/Yüksek riskli gereksinimler için
    self-consistency örnek sayısı (`SAMPLES_HIGH_RISK`, varsayılan 3).
  - `samples_default = 1`, `self_consistency_temperature = 0.3`.
- **`PathConfig`**: register dosyası, banka profili, belgeler klasörü,
  çıktı klasörleri (`extract/`, `report/`), checkpoint veritabanı yolu.
- **`load_bank_profile(path)`**: `data/bank_profile.json`'dan 15 koşullu
  gereksinimin cevaplarını okur. Sadece `true`/`false` olan (yani
  yanıtlanmış) anahtarları alır; `null`/eksik olanlar sessizce atlanmaz —
  aşağıda `expand_requirements` bunları insan incelemesine yönlendirir.
- **`PolicyConfig`**: `tracked_changes` (Word değişiklik izleme politikası),
  `max_document_tokens`, `review_threshold` (bu güvenden düşük bulgular
  insana gider), `high_risk_levels = ("Kritik", "Yüksek")`,
  `evidence_search_rounds`, `condition_flags`.
- **`LDAPConfig`**: `directory.py` VE `webapp/auth.py`'nin paylaştığı AD
  bağlantı ayarları (`enabled`, `server_uri` — `LDAP_SERVER_URI` ya da
  kısa ad `LDAP_SERVER`, ikisi de okunur —, `use_ssl`, `bind_dn`/
  `bind_password` — servis hesabı, boşsa giriş self-bind'e düşer —,
  `user_search_base`/`user_search_filter`/`login_search_filter`,
  `upn_suffixes` — self-bind ve `{email}` yer tutucusu için, mail domaini
  AD domaininden farklı olabildiği için virgülle birden fazla yazılabilir
  —, zaman aşımı/deneme ayarları). `enabled=False` varsayılan — kapalıyken
  hiçbir alanın dolu olması gerekmez.
- **`Config`**: dört alt config'i (`llm`, `paths`, `policy`, `ldap`) bir
  araya getirir; `__post_init__` banka profilini otomatik yükler.
- **`DEFAULT = Config()`**: modül import edildiğinde bir örnek oluşturulur
  (çoğunlukla test/varsayılan amaçlı; gerçek kullanım genelde kendi
  `Config()` örneğini yaratır).

---

## `llm.py` — LLM İstemcisi

OpenAI-uyumlu `/chat/completions` uç noktasına konuşan HTTP istemcisi.
İki garanti verir: **yapılandırılmış çıktı** (her zaman şemaya uyan dict,
ya da açık hata) ve **determinizm** (yargı çağrılarında sıcaklık 0, belge
prompt'ta her zaman İLK sırada — sunucunun prefix cache'i aynı belge için
yapılan ~255 çağrı boyunca devreye girsin diye).

- **`LLMError`**: özel hata sınıfı.
- **`_PERMANENT_STATUS = (400, 401, 403, 404, 413, 422)`**: yeniden denemesi
  anlamsız HTTP kodları — bozuk istek, yanlış/eksik auth header, bilinmeyen
  model. Bunlarda `_post` hemen `LLMError` fırlatır; yanlış yapılandırılmış
  bir `LLM_API_KEY_HEADER`'da dakikalarca boşuna beklenmez.
- **`_THINK_BLOCK`**: `<think>...</think>` bloğunu yakalayan regex.
  `disable_thinking` açıkken bile savunma amaçlı uygulanır — bazı dağıtımlar
  akıl yürütmeyi ayrı bir `reasoning_content` alanına değil, düz `content`
  içine gömebiliyor.
- **`LLMClient.__init__`**: `httpx.Client` kurar; header'lar ve TLS
  doğrulaması **tek kaynaktan**, `cfg.headers` / `cfg.verify`'den gelir
  (bkz. `config.py::LLMConfig`) — böylece istemci ile `check`/`trace`'in
  bağlantı testleri hep aynı şeyi konuşur. `_rate_lock` (threading.Lock) ve
  `_last_request`: LangGraph her aday gereksinim için ayrı bir thread açıp
  paralel istek attığından, bunlar olmadan istekler anlık patlama yapar ve
  dakikalık bütçesi düşük bir uç nokta 429 döner.
- **`_throttle()`**: `min_interval_s` > 0 ise, son istekten bu yana geçen
  süreyi kilit altında ölçüp eksikse bekler. Tüm thread'ler aynı kilidi
  paylaştığı için istekler gerçekten seri hale gelir.
- **`_post(payload)`**: Asıl HTTP çağrısı. `max_retries` kez dener; her
  denemeden önce `_throttle()` çağrılır.
  - `_PERMANENT_STATUS`'taki bir kod gelirse hemen `LLMError` (deneme yok).
  - 429 (rate limit) özel olarak yakalanır: `_retry_delay_s()` ile
    sunucunun bildirdiği bekleme süresi kadar (üst sınır 60s) uyur, sonra
    tekrar dener — sabit bir bekleme yerine sunucunun "ne zaman tekrar
    dene" bilgisini kullanır.
  - Diğer hatalarda eski davranış: `1.5 * (deneme+1)` saniye bekle.
  - Tüm denemeler tükenirse `LLMError` fırlatılır.
- **`_retry_delay_s(headers)`**: Önce standart `Retry-After` header'ına
  bakar, yoksa `x-ratelimit-reset-tokens`/`-requests` header'larını
  (`"18s"`, `"1m4.8s"` gibi, bazı sağlayıcıların kullandığı bir kural)
  parse eder.
- **`_parse_duration(text)`**: `"1m4.8s"` / `"150ms"` gibi süre string'lerini
  saniyeye çevirir (regex ile dakika/saniye/milisaniye parçalarını ayırır).
- **`complete_json(system, prefix, suffix, schema, temperature=None)`**:
  Tek bir yapılandırılmış çağrı.
  - `prefix` = büyük, tekrar eden kısım (belge); `suffix` = küçük, değişen
    kısım (gereksinim) — bu sıra prefix cache'in işe yaraması için önemli.
  - `max_tokens: cfg.max_tokens` her zaman gönderilir — sunucunun kendi
    varsayılanına bırakmamak, hem cevabı kısıtlar hem thinking kapanmazsa
    tek bir çağrının kaçak büyümesine karşı üst sınır koyar.
  - `disable_thinking` açıksa `chat_template_kwargs: {"enable_thinking":
    false}` eklenir — vLLM'in Qwen3 şablonu bunu onurlandırır, tanımayan bir
    sunucu zararsızca yok sayar.
  - Önce `response_format: json_schema` (strict mode) dener.
    `_strict_schema()` ile şemaya otomatik `additionalProperties: false`
    eklenir — OpenAI'nin gerçek spesifikasyonu bunu her `object` düğümünde
    zorunlu kılıyor, bazı gateway'ler bunu sıkı uyguluyor (vLLM/TGI genelde
    umursamıyor, ama zararı yok).
  - Başarısız olursa `json_object` moduna düşer. Bu modda OpenAI, mesajlarda
    "json" kelimesinin geçmesini şart koşuyor; sistem promptunda "json"
    geçmiyorsa otomatik ekleniyor.
  - Yanıtın `content` alanı önce `_THINK_BLOCK` ile temizlenir, sonra
    `_parse_json()` ile ayrıştırılır.
- **`complete_json_voted(..., vote_key, samples)`**: Aynı çağrıyı `samples`
  kez tekrarlar (self-consistency), `vote_key` alanına göre çoğunluk oyunu
  alır. `samples <= 1` ise tek çağrı yapar. Anlaşmazlık, gürültü değil
  sinyal olarak görülür: çağıran taraf düşük anlaşmayı insan incelemesine
  yönlendirir (bkz. `nodes/evaluate.py::verify_citations`).
- **`_strict_schema(schema)`**: JSON şemasını ağaç olarak gezip her
  `"type": "object"` düğümüne `additionalProperties: false` ekler (yoksa).
- **`_parse_json(text)`**: Modelin döndürdüğü metni JSON'a çevirir.
  Markdown code-fence'leri temizler, saf JSON bulamazsa ilk `{` ile son
  `}` arasını dener; hiçbiri işe yaramazsa `LLMError`.
- **`estimate_tokens(text)`**: Kaba bir Türkçe-farkında token tahmini
  (`len(text) // 3`) — yönlendirme kararları için yeterli hassasiyette.

---

## `state.py` — Tipler ve Graf Durumu

Grafın içinden akan tüm veri yapıları burada `TypedDict`/`Literal` olarak
tanımlı. Kod mantığı yok, sadece tip sözleşmesi.

- **`Verdict`**: olası hüküm değerleri (`satisfied`, `partial`,
  `contradicted`, `not_mentioned`, `satisfied_by_ref`, `out_of_scope`,
  `needs_review`).
- **`Ring`**: `universal | core | border | out_of_scope | title_conflict`.
- **`DocumentClass`**: `policy | procedure | unknown`.
- **`ObligationForm`**: `action | delegation | prohibition | authority |
  conditional`.
- **`Block`**: çıkarılan tek bir belge birimi (id, tip, kaynak, metin) —
  her alıntının çapası budur.
- **`Requirement`**: register'ın bir satırı (id, madde, metin, risk
  seviyesi, ana/yan konu, vb.).
- **`Candidate`**: `{req_id, ring}` — bir belge için seçilmiş aday.
- **`Evidence`**: `{block_id, quote, verified, reason}` — bir bulgunun
  kanıtı ve doğrulama sonucu.
- **`Finding`**: nihai bulgu kaydı — hüküm, güven, kanıtlar, eksik
  unsurlar, gerekçe, self-consistency anlaşma sayısı, adversarial
  meydan okumayı geçip geçmediği, tavsiye metni.
- **`DocumentProfile`**: belge metadata'sı + seçilen konular + konu
  gerekçeleri + başlık/kapsam çelişkisi bayrağı.
- **`DocumentRecord`**: corpus grafına yükseltilen, bir belgenin özet
  sonucu (profile + findings + warnings + error).
- **`DocumentState`**: belge grafının durumu. `pending_review`
  `Annotated[..., operator.add]` — paralel dallar (fan-out) buraya
  **eklenerek** birleşir. `findings` ise özel bir birleştirici kullanır,
  `_merge_findings` (aynı dosyada tanımlı, `operator.add` DEĞİL):
  `check_metadata` ve `evaluate_core`/`evaluate_border`'ın fan-out'u her biri
  YENİ bir `req_id` katar (eklensin isteriz), ama `verify_citations` ve
  `challenge` mevcut TÜM `findings` listesini okuyup değiştirip aynı anahtara
  geri yazar (üzerine yazılsın isteriz, eklenmesin). Düz `operator.add` ile
  bu ikinci davranış her geçişte listeyi ikiye katlar — `verify_citations`
  1x→2x, `challenge` 2x→4x, ve `req_id` başına birbiriyle çelişen
  kopyalar biriktirir. `_merge_findings`, `req_id`'yi anahtar yaparak fan-out
  için ekleme, sıralı geçişler için üzerine-yazma davranışını aynı anda verir.
- **`EvaluationTask`**: bir fan-out dalının girdisi (belge + tek bir
  gereksinim + ring + örnek sayısı).
- **`CorpusState`**: corpus grafının durumu — tüm belgeler, kapsanan/
  kapsanmayan gereksinimler, eksik belge tipleri, rapor yolu.

---

## `registry.py` — Gereksinim Kayıt Defteri

Sistemin omurgası: 255 atomik gereksinim, her biri kendi konusu, yükümlülük
şekli, kontrol sorusu ve risk seviyesiyle. **Aday seçimi her zaman bir tablo
sorgusu — asla benzerlik araması değil.**

- **`_FORM_MAP`**: Excel'deki Türkçe yükümlülük şekli değerlerini
  (`eylem`, `delegasyon`, `yasak`, `yetki`, `kosullu_eylem`) İngilizce
  `ObligationForm` literal'lerine çevirir.
- **`Topic`** (dataclass): bir konu kodu — kod, tema, tanım, ilgili
  maddeler.
- **`Registry.__init__`**: gereksinim listesini `by_id` sözlüğüne indeksler,
  `topic_codes` kümesini çıkarır, `universal` (m.5, her belgeye uygulanan)
  alt kümesini ayırır.
- **`Registry.candidates(declared_topics)`**: **Halka atama mantığı.**
  - `universal` → her belgeye, model karar vermeden eklenir.
  - `primary_topic` (ana_konu) beyan edilen konularda ise → `core`
    ("burada karşılanmış mı?").
  - `secondary_topics` (yan_konu) beyan edilen konulara değiyorsa →
    `border` ("geçerli bir referans var mı?").
  - İkisi de değilse → aday değil (kapsam dışı).
- **`Registry.applies(req, condition_flags)`**: Koşullu bir gereksinimin
  (`kosul_kodu` dolu) uygulanıp uygulanmadığını banka profilinden okur.
  Cevap yoksa `None` döner (yok sayılmaz — insan incelemesine gider).
- **`Registry.topic_catalogue()`**: Konu seçim node'una verilen kapalı
  listenin metin hâli.
- **`load_registry(xlsx_path, ...)`**: `@lru_cache` ile önbelleklenmiş
  Excel okuyucu. `Register` sayfasından her satırı `Requirement` dict'ine,
  `Konu Sözlüğü` sayfasından `Topic` listesine çevirir. `yan_konu` ve
  `alt_unsurlar` hücreleri `|` ile ayrılmış çoklu değer olarak parse edilir.

---

## `extract.py` — Word (.docx) Ayrıştırma

`.docx` dosyasını (ZIP + OOXML XML) düşük seviyede gezip yapılandırılmış
bloklara ve markdown'a çevirir. Harici bağımlılık sadece `lxml`.

- **`q(t)` / `tag(e)`**: OOXML namespace yardımcıları — tam nitelikli etiket
  adı üretir / bir elementin yerel adını okur.
- **`clean`**: boşlukları normalize eden lambda.
- **`text_of(p, mode)`**: bir paragrafın metnini Word'ün "Değişiklikleri
  İzle" (Track Changes) işaretlemesine göre toplar. **Gerçek bir hataydı,
  düzeltildi**: eski hâli `p.iter(q("t"))` ile TÜM `<w:t>` etiketlerini
  kaçışsız topluyordu — bu, eklenen metni (`<w:ins>` içindeki `<w:t>`)
  her zaman dahil ediyor, silinen metni (`<w:del>` içindeki, FARKLI bir
  etiket olan `<w:delText>`) her zaman hariç tutuyordu; yani
  `tracked_changes` parametresi ne olursa olsun (kod hiç okumuyordu bile)
  sonuç hep "accepted" (kabul edilmiş) hâliydi. `original`/`all` sessizce
  `accepted` gibi davranıyordu. Şimdi `mode` parametresine göre üç farklı
  davranış: `accepted` (ekleneni tut, sileni at — nihai hâl), `original`
  (sileni tut, ekleneni at — düzenlemeden önceki hâl), `all` (ikisini de
  tut). `VALID_TRACKED_CHANGES` dışında bir değer sessizce `accepted`'a
  düşer; `extract()` `accepted` DIŞINDA bir mod kullanıldığında
  `warnings`'e bunu yazar — okuyan kişi "bu, resmi yayınlanmış hâl
  olmayabilir" uyarısını raporda görsün diye.
- **`REPEAT_VMERGE = True`**: dikey birleştirilmiş bir tablo hücresinin
  devam satırlarına üstteki değeri kopyalar (okurken belirsizlik kalmasın
  diye); `False` olsaydı Word'de göründüğü gibi boş bırakılırdı.
- **`is_heading(p, txt)`**: paragraf stili "Heading" ile başlıyorsa, ya da
  kısa+büyük harfli/numaralı bir satırsa başlık sayılır.
- **`is_list(p)`**: paragrafın numaralama özelliği (`numPr`) varsa liste
  öğesidir.
- **`table_rows(tbl)`**: Bir tablonun satırlarını okur; iç içe tabloları
  ayrı işler (yinelenmesinler diye); dikey birleşim devamlarını
  `REPEAT_VMERGE` kuralına göre doldurur.
- **`rows_to_md(rows)`**: Satırları markdown tablo string'ine çevirir
  (ilk satır başlıksa `---` ayırıcı satırı ekler).
- **`own_cells(tbl)`**: Sadece bu tabloya ait hücreleri döndürür
  (`iter()` kullanmaz — o iç içe tabloları da yakalayıp mükerrer
  yayınlamaya sebep olurdu).
- **`walk(container, blocks, source, counter, in_textbox, depth)`**:
  **Ana özyinelemeli gezici.** Her çocuk elementte:
  - `sdt` (içerik denetimi) → içeriğine iner.
  - `tbl` (tablo) → blok olarak ekler, sonra hücrelerin içindeki iç içe
    tabloları (`depth+1` ile) ve metin kutularını (`in_textbox=True` ile)
    ayrıca gezer.
  - `p` (paragraf) → metin varsa başlık/liste/paragraf olarak blok ekler;
    içinde metin kutusu varsa onu da gezer.
- **`notes(z, part, source, blocks, counter)`**: dipnot/sonnot XML'ini okur,
  ayırıcı olmayanları blok olarak ekler.
- **`comments(z)`**: Word yorumlarını ayrı bir liste olarak çıkarır (gövde
  metninin dışında tutulur, `ingest.py` bunu uyarı olarak işaretler).
- **`to_markdown(blocks, include_header_footer)`**: Blok listesini okunabilir
  markdown'a render eder — başlıklar `##`, listeler `-`, notlar `>` ile.
- **`extract(path, tracked_changes)`**: **Ana giriş noktası.** ZIP'i açar,
  sırayla header'ları, gövdeyi, dipnot/sonnotları, footer'ları gezer,
  yorumları toplar. Metin kutusundan okuma veya yorum varlığı uyarı olarak
  eklenir. Sonuç: dosya adı, uyarılar, header/footer/başlık/tablo/dipnot
  listeleri, yorumlar, ham bloklar, markdown, istatistikler.
- **`if __name__ == "__main__"`**: komut satırından doğrudan
  `python extract.py dosya.docx` ile çalıştırılabilir, `output/` altına
  JSON+MD yazar (geliştirme/hata ayıklama kolaylığı).

---

## `verify.py` — Alıntı Doğrulama

Halüsinasyonun büyük kısmını tek bir kuralla keser: modelin bir bloğa
atfettiği alıntı, o blokta **birebir** geçmeli.

- **`_FOLD`**: akıllı tırnak, tire çeşitleri, sıfır genişlikli boşluk gibi
  biçimlendirme gürültüsünü normal karşılıklarına eşler (kelimeleri asla
  değiştirmez — bir parafraz yine de başarısız olmalı).
- **`normalize(text)`**: Unicode NFKC normalizasyonu, `_FOLD` eşlemesi,
  markdown kaçış karakterlerini (`\*`, `\_` vb.) temizleme, `**`/`__`/`` ` ``
  işaretlerini kaldırma, boşlukları tek boşluğa indirgeme.
- **`verify_quote(blocks, block_id, quote)`**: Üç ayrı başarısızlık modu
  döndürür (bir incelemeci için anlamları farklı):
  1. `block_id` bilinmiyor → **uydurma çapa**.
  2. Alıntı iddia edilen blokta yok ama **başka bir blokta** var → gerçek
     metin, yanlış çapa.
  3. Alıntı belgenin hiçbir yerinde yok → **uydurma metin**.
  Bulunursa `(True, "verbatim")` döner.

---

## `directory.py` — Kurumsal Dizin (LDAP/AD) Sorgusu

Tek bir soruya cevap verir: *belgenin onaylayan/sahip alanındaki isim,
AD'de gerçekten var olan aktif bir hesaba mı karşılık geliyor?* **Kimlik
doğrulama DEĞİLDİR** — hiçbir parola işlenmez, sadece servis hesabıyla
salt-okunur arama yapılır. Bir başka projenin `ldap_auth.py`'sinden
uyarlanmıştır (o dosya interaktif giriş için parola da doğrular; buraya
sadece "servis hesabıyla bağlan → ara" yarısı taşınmıştır).

`cfg.ldap.enabled=False` (varsayılan) olduğu sürece bu modül hiçbir ağ
bağlantısı açmaz ve `ldap3` paketi kurulu olmasa bile proje çalışır —
`ldap3` yalnızca `lookup_person()` gerçekten çağrıldığında import edilir.

- **`_UAC_DISABLED_BIT = 0x2`**: AD'nin `userAccountControl` bit
  maskesinde "hesap devre dışı" bitini işaretler (Microsoft'un
  `UF_ACCOUNTDISABLE` sabiti).
- **`lookup_person(name, cfg)`**: Üç farklı sonuç döner, kasıtlı olarak
  birbirine karıştırılmaz:
  - `None` — LDAP kapalı, `cfg.server_uri` boş (bkz. aşağıdaki not), ya da
    sorgu başarısız oldu (bağlantı/bind hatası). "Kontrol edilemedi", kişi
    hakkında bir iddia DEĞİL.
  - `{"found": False}` — dizine gerçekten ulaşıldı ve arandı; böyle bir
    hesap yok.
  - `{"found": True, "display_name", "title", "department", "mail",
    "account_enabled", "multiple_matches"}` — eşleşme bulundu.
  - Servis hesabıyla bağlanır (bağlantı hatasında `cfg.max_retries` kez
    dener), `escape_filter_chars()` ile ismi kaçışlayıp (belge metninden
    geldiği için LDAP filter injection riskine karşı — orijinal
    `ldap_auth.py` bunu kullanıcı adı için yapmıyordu, ama oradaki isim bir
    giriş formundan geliyor, buradaki bir belge metninden) `cfg.
    user_search_filter`'daki `{name}` yerine koyar, arar.
  - `userAccountControl`'ü `_UAC_DISABLED_BIT` ile maskeleyip hesabın aktif
    olup olmadığını çıkarır.
  - Bağlanmadan ÖNCE `cfg.server_uri` boş mu diye kontrol eder — boşsa
    `ldap3` sessizce `localhost:389`'a bağlanıp anlaşılmaz bir "Connection
    refused" verirdi; kurum bilgisayarında `webapp/auth.py`'de yaşanan
    arızayla aynı hata sınıfı, burada da açıkça loglanıp `None` dönülür.

---

## `search.py` — Kanıt Ajanı için Arama

Sadece `evidence_agent`'ın kullandığı BM25 tabanlı sözcüksel arama.
Düzenleyici Türkçe (`"uçtan uca güvenli iletişim"` gibi) tam eşleşme
ağırlıklı olduğundan embedding yerine BM25 tercih edilmiş.

- **`TOKEN`, `tokenize(text)`**: 2 karakterden uzun, Türkçe karakterleri
  destekleyen basit bir tokenizer.
- **`BM25Search`**:
  - `__init__(documents)`: `{document_id, blocks}` listesinden, header/
    footer olmayan ve 40 karakterden uzun her bloğu bir BM25 girdisine
    çevirir (terim frekansı, uzunluk); IDF'yi tüm korpus üzerinden
    hesaplar.
  - `__call__(query, k)`: standart BM25 skorlama formülü (K1=1.5, B=0.75)
    ile en iyi `k` bloğu döndürür.
- **`build_search(extract_dir)`**: `extract/` klasöründeki her `*.json`
  dosyasını okuyup `BM25Search` nesnesi kurar — bu yüzden arama
  çalışmadan önce `extract` adımının çalışmış olması gerekir.

---

## `graph.py` — Graf Montajı

İki derlenmiş LangGraph grafı burada kurulur. Tasarım duruşu: bu bir
**iş akışı**, otonom bir ajan değil — kenarlar sabit, model hangi
gereksinimin kontrol edileceğine hiç karar vermez.

- **`build_document_graph(client, registry, cfg, checkpointer)`**:
  `DocumentState` üzerinde düğümleri ekler (`ingest`, `profile_document`,
  `select_topics`, `recall_guard`, `check_metadata`,
  `expand_requirements`, `evaluate_core`, `evaluate_border`,
  `verify_citations`, `challenge`, `route_for_review`), her birini gerekli
  bağımlılıklarla (`client`/`registry`/`cfg`) `functools.partial` ile
  bağlar. Kenarlar: doğrusal zincir + `ingest` başarısız olursa `END`'e
  koşullu dallanma + `expand_requirements`'tan `fan_out()` ile
  `evaluate_core`/`evaluate_border`'a **çoklu dallanma** (bir aday
  gereksinim = bir dal).
- **`_ingest_ok(state)`**: `ingest` node'unun hata alanına bakıp
  `"ok"`/`"failed"` döner — koşullu kenarın yönlendirme fonksiyonu.
- **`build_corpus_graph(client, registry, cfg, document_graph, search_fn,
  checkpointer)`**: `CorpusState` üzerinde `review_documents` →
  `reverse_scan` → (yetim varsa) `evidence_agent` → `recommend` →
  `render_report` → `END` zincirini kurar.
- **`_has_orphans(state)`**: `orphan_requirements` doluysa `"search"`,
  boşsa `"skip"` döner — `evidence_agent`'ı atlayıp atlamama kararı.
- **`_review_documents(state, document_graph, cfg)`**: `document_paths`
  listesindeki her dosya için belge grafını **sırayla** (paralel değil —
  sunucunun prefix cache'i belge başına sıcak kalsın diye) çalıştırır,
  sonuçları `DocumentRecord` listesine toplar.
- **`build(cfg, search_fn, checkpointer)`**: Her şeyi bir `Config`'ten
  tek çağrıda kurar — client, registry, iki graf. CLI'nin kullandığı
  kolaylık fonksiyonu.
- **`make_checkpointer(path)`**: SQLite tabanlı LangGraph checkpoint'i —
  uzun süren bir taramada çökme, tüm işi kaybettirmesin diye.

---

## `nodes/ingest.py` — Node: `ingest`

Tek node, model çağrısı yok. `extract.py`'ı çağırıp `DocumentState`'e
uygun forma sokar: `document_id` (dosya adı, uzantısız), `sha256` (dosya
bütünlüğü için kısa özet), bloklar, markdown, uyarılar, token tahmini.
Belge `max_document_tokens`'ı aşarsa uyarı ekler (bölümlere ayırma yolu
henüz bağlı değil — README'de "Limits" bölümünde not edilmiş). Ayrıştırma
hata verirse `error` alanını doldurup boş state döner — bu, grafın
`_ingest_ok` koşullu kenarıyla `END`'e sapmasını tetikler.

## `nodes/profile.py` — Node'lar: `profile_document`, `select_topics`,
## `recall_guard`, `expand_requirements`

İş bölümü kasıtlı: **model** amaç/kapsam metnini okuyup kapalı listeden
konu kodu seçer; **kod** o kodları gereksinim id'lerine ve halkalara
eşler. Modelin doğrudan gereksinim id'si seçmesine izin vermek hem
tekrarlanamaz olurdu hem de eksik seçime yol açardı (register'a göre,
bir konuyla ilgili maddelerin kabaca yarısı o konunun kendi regülasyon
bölümünün dışında yaşıyor).

- **`FIELD_LABELS`**: Belge metadata alanlarının (doküman no, sürüm,
  tarih, gizlilik, sahip, onaylayan) olası Türkçe etiket varyasyonları.
- **`CLASS_PATTERNS`, `_classify(title)`**: başlıktaki kelimelere göre
  belgeyi `policy` (politika) ya da `procedure` (prosedür/talimat/
  yönerge/kılavuz) olarak sınıflar.
- **`_scan_labels(fragments)`**: header/footer/tablo metinlerinden etiket→
  değer eşlemesi çıkarır. **İki ayrı biçimi de** yakalar: `"Etiket | Değer"`
  (KÜNYE tablosunun tipik satır şekli — belge_kodu/sürüm/onaylayan/sahip
  hep bu formda) VE `"Etiket: Değer"` (header'a gömülü düz metin, örn.
  "... Gizlilik Derecesi: —"). Eskiden sadece ikincisi aranıyordu; bu,
  KÜNYE tablosu kullanan (örnek belgelerin hepsi gibi) her belgede
  `document_code`/`version`/`effective_date`/`owner`/`approver` alanlarının
  hep boş çıkmasına, dolayısıyla REQ-5.2.b/5.3/5.4.b'nin uygun belgeleri
  yanlışlıkla "belirtilmemiş" işaretlemesine yol açıyordu.
- **`_matching_field(label)`** / **`_scan_table_headers(blocks)`**: ÜÇÜNCÜ
  bir tablo biçimini yakalar — `_scan_labels`'ın hâlâ göremediği: bir
  BAŞLIK satırı birden çok rolü aynı anda adlandırıp, gerçek isimler AYRI
  bir veri satırında altında durur (gerçek bir Kuveyt Türk şablonunda
  görüldü):
  ```
  Hazırlayan          | Onaylayan      | Yürürlük Onayı
  Fatih Abidin Silan  | Onurhan Yılmaz | Fatih Muhammed Ünal
  ```
  `_scan_labels` tek seferde tek satıra (tek fragment'e) bakar; bir başlık
  hücresiyle bir satır altındaki değeri onun için ilişkisiz iki satırdır.
  Bu fonksiyon tablonun HAM `rows`'una (düzleştirilmiş markdown metnine
  değil) bakıp `rows[0]`'ı başlık, `rows[1]`'i veri sayar. KÜNYE tablosuyla
  (`"Doküman No" | "POL.001"` gibi, HER satırı kendi başına bir etiket-
  değer çifti) KARIŞMAMASI için: bir satırın gerçekten başlık olması için
  hücrelerinin HEPSİ (en az 2 tanesi) bilinen bir etikete uymalı —
  KÜNYE'nin ilk satırında ikinci hücre ("POL.001") hiçbir etikete uymadığı
  için bu kural onu otomatik eler; REVİZYON GEÇMİŞİ tablosunda da "Tarih"
  hücresi hiçbir etikete uymadığından aynı şekilde elenir.
- **`FIELD_LABELS["enactment_approver"]`**: `"yürürlük onayı"` — kasıtlı
  olarak `"approver"`'dan (`"onaylayan"`) AYRI bir alan. Aynı belgede bu
  iki rol farklı kişiler olabiliyor (BSEB'in m.5/3 sorduğu yönetişim onayı
  ile doküman/kalite yönetiminin resmi yayın onayı ayrı şeyler); tek alana
  yazılsaydı ikinci gelen ilkini (`found` kilidi yüzünden) sessizce
  ezemeyip kaybolurdu. `check_metadata`'nın REQ-5.3 mantığı bilinçli
  olarak yine `approver`'a bakar; `_directory_warnings` (bkz.
  `metadata_rules.py`) ise AD'de üçünü de (`approver`/`owner`/
  `enactment_approver`) ayrı ayrı arar.
- **`_detect_languages(markdown)`**: Türkçe ve İngilizce dil işaretlerini
  regex ile arar — iki dilli belgelerde ikisini de bulmak kritik, tek
  yarısını değerlendirmek kapsamı sessizce yarıya düşürür.
- **`profile_document`** (node 1, kod): başlığı, metadata alanlarını,
  dilleri çıkarır; ayrıca `select_topics`'in okuyacağı "lead" (ilk 30
  gövde bloğu) ve başlıklar listesini `_lead`/`_headings` olarak saklar.
- **`TOPIC_SYSTEM`, `TOPIC_SCHEMA`, `select_topics`** (node 2, LLM,
  T=0): Modele kapalı 54 kodluk katalogla belgenin amaç/kapsam/başlık
  metnini verir; hangi konuları **kendisinin yönettiğini beyan ettiğini**
  (sadece değindiklerini değil) seçmesini ister. Ayrıca başlık ile
  beyan edilen kapsamın çelişip çelişmediğini sorar.
- **`GUARD_SYSTEM`, `GUARD_SCHEMA`, `recall_guard`** (node 3, LLM,
  T=0): **İkinci güvenlik geçişi.** Seçilmeyen ama kod adı belge
  metninde geçen ("near-miss") konuları bulur, modele "bunlar gerçekten
  dışarıda mı kaldı?" diye sorar. Modeller genelde az seçtiği için, bir
  konu alanının tamamen sessizce düşmesine karşı ucuz bir sigorta.
- **`expand_requirements`** (node 4, kod): `registry.candidates()` ile
  konulardan aday listesine geçer; koşullu gereksinimlerden banka
  profilinde cevabı olmayanları `unresolved` listesine ekler (bunlar
  yine de adaylıkta kalır ama uyarı olarak işaretlenir → insan
  incelemesi); başlık/kapsam çelişkisi ve çift dillilik de uyarı olarak
  eklenir.

## `nodes/metadata_rules.py` — Node: `check_metadata` (universal ring)

m.5 doküman kontrol gereksinimlerinin 5'i tamamen biçimsel — model yerine
regex/kural motoru karar verir (hem ucuz hem halüsinasyon riski yok).

- **`BOARD`, `DELEGATION`, `ANNUAL`, `CONDITIONAL`, `ADVISORY`, `LONGER`**:
  Türkçe/İngilizce regex desenleri — yönetim kurulu ifadesi, yetki devri,
  yıllık gözden geçirme, koşullu ifade, tavsiye niteliği, birden uzun
  periyot.
- **`RULE_BACKED`**: kuralla karara bağlanan 5 gereksinim id'si
  (REQ-5.2.b, 5.3, 5.4.b, 5.5.a, 5.5.b).
- **`_finding(...)`**: standart bir `Finding` kaydı üretme yardımcısı.
- **`_review_statement(blocks)`**: revizyon tarihi/gözden geçirme
  ifadesi geçen tabloyu ya da paragrafı bulur.
- **`_revision_table(blocks)`**: Gerçek bir revizyon geçmişi tablosunu
  (en az 3 sütun, ayrı sürüm+tarih sütunları) "doküman sahibi | sonraki
  revizyon tarihi" gibi yanıltıcı tek hücreli tablolardan ayırt eder.
- **`check_metadata(state, cfg)`**: Sırasıyla:
  - **REQ-5.2.b**: doküman kodu + gizlilik derecesi var mı.
  - **REQ-5.3**: onaylayan makam belge sınıfına (politika→YK zorunlu,
    prosedür→YK veya belirtilmiş yetki devri) uygun mu.
  - **REQ-5.4.b**: doküman sahibi belirtilmiş mi.
  - **REQ-5.5.a**: yıllık gözden geçirme **koşulsuz** olarak belirtilmiş
    mi (koşula bağlanmışsa `partial`/`contradicted`).
  - **REQ-5.5.b**: revizyon geçmişi tablosu eksiksiz mi (onaylayan
    sütunu, dolu değerler, en az bir önceki sürüm kaydı).
  - Son adım: `_directory_warnings(profile, cfg)` çağrılır ve sonucu
    `state["warnings"]`'e eklenir (yeni bir `Finding`/sahte REQ id
    **uydurulmaz** — bu bir düzenleyici hüküm değil, insana yönelik bir
    not).
- **`_directory_warnings(profile, cfg)`**: `cfg.ldap.enabled` kapalıysa
  (varsayılan) hiçbir şey yapmaz. Açıksa `profile["approver"]` ve
  `profile["owner"]`'ı `directory.py::lookup_person()` ile AD'de arar;
  bulunamama / birden fazla eşleşme / hesabın devre dışı olması ayrı ayrı
  uyarı metnine dönüşür. Bir isim bulunması "bu kişi bu belgeyi onayladı"
  demek değildir, sadece "bu isimde aktif bir hesap var" demektir — karar
  yine insana bırakılır.

## `nodes/evaluate.py` — Node'lar: `fan_out`, `evaluate_core`,
## `evaluate_border`, `verify_citations`, `challenge`, `route_for_review`

Asıl değerlendirme mantığı: belge-seviyesi doğal dil çıkarımı (NLI).
Halka hangi sorunun sorulacağını belirler: **core** = "burada karşılanmış
mı?" (eksikse bulgu); **border** = "geçerli bir referans var mı?" (eksikse
zayıf bulgu). İkisini birleştirmek her belgeyi değindiği her konudan
sorumlu tutardı.

- **`fan_out(state, registry, cfg)`**: Her aday gereksinim için bir
  `Send()` üretir (zaten kural motorunca karara bağlanmış olanlar hariç).
  Risk seviyesi Kritik/Yüksek ise `samples_high_risk` (3), değilse
  `samples_default` (1) örnek sayısı atanır. Hedef node, halkaya göre
  `evaluate_border` ya da `evaluate_core`.
- **`CORE_SCHEMA` / `BORDER_SCHEMA`**: yapılandırılmış yanıt şemaları —
  hüküm (enum), kanıt listesi (block_id+quote), eksik unsurlar, gerekçe,
  güven; border ayrıca `referenced_document` alanı taşır.
- **`CORE_SYSTEM`**: hüküm sözlüğünü tanımlar (satisfied/partial/
  contradicted/not_mentioned/out_of_scope/needs_review) ve kuralları
  sıralar — alıntı birebir olmalı, belge dışı bilgiye güvenilmez, "X'i
  tanımlar" yükümlülüğü sadece X yazılı olarak tanımlanmışsa karşılanır,
  gerçekten kapsam dışıysa zorla bir hüküm vermek yerine `out_of_scope`
  tercih edilir.
- **`BORDER_SYSTEM`**: burada soru "karşılanmış mı" değil "bağımlılık
  kabul edilmiş/referanslanmış mı" — `satisfied_by_ref` diğer belgeyi
  adıyla anmayı gerektirir.
- **`_requirement_block(req, ring)`**: gereksinim bilgisini (id, madde,
  metin, düzenleme lafzı, kontrol sorusu, alt unsurlar) prompt'a
  basacak metne çevirir.
- **`_run(task, client, cfg, system, schema)`**: `prefix` = belgenin
  tamamı (cache'lensin diye), `suffix` = gereksinim bloğu;
  `complete_json_voted` çağrısını yapar.
- **`_collect_evidence(raw, blocks)`**: modelin döndürdüğü en fazla 4
  kanıtı `verify_quote()` ile doğrulayıp `Evidence` listesine çevirir.
- **`evaluate_core` / `evaluate_border`**: `_run()`'ı çağırıp sonucu
  `Finding` kaydına dönüştürür (fan-out dallarının her biri bunlardan
  birini çalıştırır).
- **`verify_citations(state, cfg)`**: **Kontrolün kontrolü.** Olumlu bir
  hüküm (satisfied/partial/contradicted/satisfied_by_ref), doğrulanmış
  hiçbir kanıta dayanmıyorsa `needs_review`'e düşürülür (silinmez —
  incelemeci neyin iddia edildiğini ve neden kabul edilmediğini görsün
  diye). Ayrıca self-consistency'de tam oybirliği olmayan (3'ten az
  anlaşma) bulguların güveni 0.55 ile sınırlanır.
- **`CHALLENGE_SYSTEM`, `CHALLENGE_SCHEMA`, `challenge(state, client,
  registry, cfg)`**: **Adversarial (çelişen) ikinci model çağrısı,
  sadece olumsuz hükümler için** (`not_mentioned`/`contradicted`/
  `partial`). Modelden kendi bulgusunu belgenin metniyle çürütmeye
  çalışması istenir. Çürütülürse hüküm `needs_review`'e düşer ve
  `challenged=True` işaretlenir. En etkili yanlış-pozitif filtresi —
  bir iş birimine giden yanlış bir bulgu, kaçırılan bir bulgudan daha
  pahalıya mal olur (kaçırılanı insan incelemesi yakalar).
- **`route_for_review(state, cfg)`**: hükmü `needs_review` olan ya da
  güveni `review_threshold`'un altında kalan tüm bulguları
  `pending_review`'e ayırır.

## `nodes/corpus.py` — Node'lar: `reverse_scan`, `evidence_agent`,
## `recommend`, `render_report`

Belge-seviyesi tarama "bu belge uyumlu mu?" sorusunu cevaplar. Corpus
geçişi düzenleyicinin asıl sorduğu soruyu sorar: **"255'in her biri
NEREDE OLURSA olsun karşılanmış mı?"**

- **`COVERED = {"satisfied", "satisfied_by_ref"}`**: hangi hükümler
  "kapsanmış" sayılır.
- **`reverse_scan(state, registry, cfg)`**: Tüm belgelerin core/universal
  halkadaki olumlu bulgularını `covered` sözlüğüne toplar; universal
  olmayan, koşulu uygulanan (ya da bilinmeyen) ve kapsanmamış her
  gereksinimi `orphan_requirements`'a ekler; bunların ana konularından
  `missing_document_types` çıkarır.
- **`SEARCH_SYSTEM`, `SEARCH_SCHEMA`, `evidence_agent(state, client,
  registry, cfg, search)`**: **Sistemdeki tek gerçekten otonom bileşen.**
  Her yetim gereksinim için, model bir arama sorgusu üretir → `search()`
  (BM25) çağrılır → sonuçlar transkripte eklenir → model "devam et" ya da
  "sonuca var" der; bu döngü `evidence_search_rounds`'a kadar tekrarlanır.
  Otonom olması güvenli, çünkü çıktısı bir **yargı değil, doğrulanabilir
  bir olgu** ("X belgesinde bulundu" / "arandı, yok"). Bulunanlar
  `covered_requirements`'e eklenir, kalanlar `still_orphan` olarak döner.
- **`RECOMMEND_SYSTEM`, `RECOMMEND_SCHEMA`, `TOPIC_FAMILY`, `_family(topic)`,
  `recommend(state, client, registry, cfg)`**: Doğrulamadan ve
  adversarial geçişten sağ çıkan (yani `not_mentioned`/`contradicted`/
  `partial` — `satisfied` zaten tavsiyeye ihtiyaç duymaz) her bulgu için
  düzeltme metni yazdırır. Kısıt: sadece verilen düzenleme lafzına
  dayan, dışarıdan standart/ürün adı/sayısal eşik getirme; düzenleme
  "X'i tanımla" diyorsa tavsiye de "X tanımlansın, kim tanımlasın, ne
  sıklıkla gözden geçirilsin" der — X'in ne olması gerektiğini **asla**
  söylemez (bu, bir uygunluk bulgusuyla bir danışman görüşü arasındaki
  çizgi).
- **`render_report(state, registry, cfg)`**: Deterministik JSON
  render'ı — hiçbir karar burada verilmez, sadece
  `output/report/findings_<run_id>.json` yazılır.

---

## `main.py` — CLI Giriş Noktası

`python -m dokuman_inceleme.main <run|extract|graph|check|trace>`

- **`_documents(folder)`**: bir klasördeki tüm `.docx`/`.doc` dosyalarını
  (geçici Word kilit dosyaları `~$...` hariç) sıralı listeler.
- **`cmd_extract(cfg)`**: her belgeyi `extract()` ile ayrıştırıp
  `extract_dir`'e JSON+MD yazar; hata olursa o belgeyi atlayıp devam eder.
- **`cmd_run(cfg)`**: önce `cmd_extract` (arama indeksi için), sonra
  `build_search`, checkpointer bağlamı içinde `build()` ile grafları kurar,
  `corpus_graph.invoke()` çağırır, özet basar.
- **`_summary(result)`**: hüküm sayaçlarını ve insan incelemesi/yetim
  gereksinim sayısını basar.
- **`cmd_graph(cfg)`**: `render_graph.write()` ile SVG/PNG diyagramını
  üretir; ayrıca gerçek graf nesnelerini derleyip LangGraph'ın kendi
  mermaid çıktısını (`workflow_document.mmd`, `workflow_corpus.mmd`)
  yazar.
- **`cmd_check(cfg)`**: **Ön uçuş kontrolü.** Sırasıyla: `.env` yüklendi
  mi, register kaç satır/topic/universal, kaç koşul cevaplanmış, graflar
  hatasız derleniyor mu, `GET /models` ile LLM uç noktasına erişilebiliyor
  mu — hepsi yeşilse `ready`, değilse `not ready` (çıkış kodu 1).
- **`main(argv)`**: argparse ile komut/parametreleri okur, `Config`'i
  CLI bayraklarıyla (`--documents`, `--register`, `--out`,
  `--tracked-changes`, `--run-id`) günceller, ilgili `cmd_*` fonksiyonunu
  çağırır. `trace` komutu özel: `trace.py::run`'a delege eder.

---

## `trace.py` — `trace` Komutu (Adım Adım Gösterim)

Tek bir belgeyi gerçek kod yollarından geçirip her adımı ekrana basar —
açıklama değil, **gerçek çalışan kod**. Uç nokta yoksa `_Stub` ile
sahte-ama-şekli-doğru cevaplar üretir, böylece kural/seçim mantığı hâlâ
görülebilir.

- **`_h(title)`, `_box(label, body, limit)`**: konsola başlık/çerçeveli
  metin basan biçimlendirme yardımcıları (uzun metinleri kısaltır).
- **`_Stub`**: `LLMClient` ile aynı arayüze sahip sahte istemci; şemadaki
  alan adlarına bakıp mantıklı bir sahte cevap üretir (uç nokta
  erişilemezse otomatik devreye girer).
- **`run(cfg, document, only_req, topics)`**: Sırayla **9 bölüm** basar:
  0) register'dan örnek satırlar, 1) `ingest` çıktısı (bloklar), 2)
  `profile_document`+`select_topics`+`recall_guard` (ya da `--topics` ile
  zorlanan konular), 3) universal ring bulguları (kural motoru), 4)
  `expand_requirements`+`fan_out` ile aday listesi ve örnek sayıları, 5)
  tek bir gereksinimin (`--req` ile seçilen, yoksa ilk aday) tam
  prompt'u+cevabı, 6) `verify_citations` sonucu, 7) `challenge` (sadece
  olumsuz hükümde), 8) `recommend` prompt'u, 9) corpus-seviyesi ters
  taramanın ne yaptığının açıklaması. Uç noktaya `httpx.get(.../models)`
  ile önce erişilebilirlik testi yapar, canlıysa gerçek `LLMClient`,
  değilse `_Stub` kullanır.

---

## `render_graph.py` — Karar Mantığı Diyagramı (Türkçe, gerçek dallanmalar)

**Üçüncü sürüm.** İlk sürüm sadece node-to-node boru hattını gösteriyordu
("select_topics → recall_guard"); ikinci sürüm bunu Türkçe'ye çevirip
yatay akışa oturttu ama hâlâ "halka" gibi kelimeleri açmadan geçiyordu.
Bu sürüm, kodun **içinde** gerçekten sorulan her soruyu bir **karar kutusu
(◇, diamond)** olarak çizer ve her kararı register'dan **gerçek bir
satırla** (REQ-14.7, REQ-5.3, REQ-8.2, REQ-29.11) somutlaştırır — "bir
gereksinim koşullu ise banka profiline bakılır" demek yerine, gerçekten
`REQ-29.11`'in `BULUT_KULLANIMI` koduna bağlı olduğunu ve bu kodun
cevapsız kalması durumunda ne olduğunu (atlanmaz, uyarıyla birlikte
değerlendirilir) gösterir.

- **`Box`** / **`Diamond`**: iki ayrı geometri sınıfı. `Box.edge(side)`
  bir dikdörtgenin kenar orta noktasını verir; `Diamond.edge(side)` bir
  eşkenar dörtgenin dört köşesini verir (`top`=giriş, `right`=evet/devam,
  `bottom`=hayır/alternatif dal — akış yönü sözleşmesi budur, elle her
  seferinde hangi köşenin ne anlama geldiğini düşünmemek için). `Diamond.
  svg(text)` çokgeni ve ortasına sığdırılmış (`_wrap` ile bölünmüş) metni
  çizer.
- **`example(cx, cy, title, body)`**: sarı, kesik çizgili "sticky note" —
  bir kararın register'daki gerçek karşılığını gösterir. Bu, "halka deyip
  geçme" geri bildirimine doğrudan cevap: her önemli karar kutusunun
  yanında, o kararın GERÇEK bir maddeyle nasıl sonuçlandığını gösteren bir
  not var (REQ-14.7 → core+risk yüksek+3x örnekleme; REQ-5.3 → evrensel,
  kural motoru; REQ-8.2 → border; REQ-29.11 → koşullu).
- **`STYLE`**: artık 8 kategori — `kod`/`llm`/`agent`/`giris`'e ek olarak
  `karar` (yeşil diamond dolgusu), `iyi`/`kotu` (bir dalın olumlu/olumsuz
  sonucu — ör. "CORE halkası" yeşil, "KAPSAM DIŞI" kırmızı), `ornek` (sarı
  not).
- **`build_svg()`** üç şerit (panel), her biri kendi içinde soldan sağa:
  - **1 · Hangi kural bu belgeye sorulur?** — `ingest` başarı kontrolü →
    `select_topics`/`recall_guard` → sırasıyla üç gerçek karar: *evrensel
    mi?* (evetse `check_metadata` kural motoruna, LLM'siz) → *ana_konu
    eşleşiyor mu?* (CORE) → *yan_konu değiyor mu?* (BORDER, değilse
    KAPSAM DIŞI). Bunların hepsine AYRICA uygulanan ikinci bir karar
    zinciri: *kosul_kodu dolu mu?* → *banka profilinde cevaplı mı?*
    (hayırsa uyarıyla birlikte YİNE DE devam eder — kod `applies()==None`
    durumunu atlamaz) → *koşul sağlanıyor mu?* (hayırsa ATLA). Register
    alanlarıyla birebir eşleşir (`ana_konu`, `yan_konu`, `evrensel`,
    `kosul_kodu`) — bkz. `registry.py::candidates()`/`applies()`.
  - **2 · Bir kural nasıl değerlendirilir?** — *risk Kritik/Yüksek mi?*
    (3x örnekleme mi, 1x mi) → `evaluate_core`/`border` → *hüküm olumlu VE
    kanıt var mı?* → *alıntı birebir mi?* (hayırsa needs_review'e düşür)
    → *hüküm olumsuz mu?* (evetse `challenge`) → *çürütüldü mü?* →
    *needs_review VEYA güven<0.6 mı?* (evetse `pending_review`).
  - **3 · Kapsam taraması** — `reverse_scan` → *yetim var mı?* → kanıt
    ajanının kendi iç döngüsü: sorgu üret → BM25 ara → *bulundu mu?* →
    hayırsa *4. tura ulaşıldı mı?* (hayırsa döngü geri sorgu üretime
    döner — gerçek bir geri-besleme oku).
- **`write(out_dir)`**: `workflow_graph.svg`'yi yazar; `main.py graph` bunu
  `docs/`'a yazar. Kanvas artık ~3160×1650 civarında — üç şeridin hepsini
  gerçek karar detayıyla sığdırmak, önceki basit zincirden çok daha fazla
  yer istiyor.

**Doğrulama notu (bu sürümde tekrar karşılaşılan hatalar)**: (1)
kaçışlanmamış `<`/`>` SVG'yi geçersiz XML yapar (`html.escape()` şart);
(2) bir dalın "hayır" çıktısını ana çizginin YUKARISINA yerleştirmek,
yeterli boşluk bırakılmazsa panel başlığına taşar — bu sürümde önce
yaşandı, tüm "hayır" dallarını ana çizginin ALTINDA, birbirinden ayrı
"raflarda" (ring sonuçları bir rafta, koşul sonuçları bir raf daha
aşağıda) toplayarak çözüldü. Görsel doğrulama için `qlmanage -t` geniş/
uzun SVG'lerin en-boy oranını bozduğundan (yukarıda not edildi),
`svglib`+`reportlab` ile PDF'e render edip okumak güvenilir sonuç verdi.

---

## `render_architecture.py` — Tüm Proje Mimarisi (Türkçe)

`render_graph.py`'den **farkı**: o dosya tek bir LangGraph motorunun
düğüm akışını çizer (İngilizce). Bu dosya bir kat yukarıdan bakar — BSEB
düzenlemesinin 255 kurala dönüştürülmesinden (girdi), çıkarım (`extract.py`/
`registry.py`), çekirdek motor, LLM/AD dış sistemleri, arayüzler (CLI +
web) ve çıktıya kadar **tüm bileşenleri**, Türkçe olarak, tek bir üst
seviye diyagramda gösterir.

- **`Box`**: merkez+boyut tutan, kenarlarını (`left/right/top/bottom`)
  hesaplayan küçük yardımcı sınıf — oklar hep bir kutunun TAM kenarından
  başlayıp bitsin diye (elle `cx ± genişlik/2` hesaplamanın hataya açık
  olduğu görüldü: ilk sürümde bir metin `<run_id>` biçiminde yazılınca
  SVG'nin kendisi geçersiz XML üretti — `html.escape()` ile düzeltildi —
  ve bazı ok/kutu koordinatları çakışıyordu; `Box`+`edge_point()` bu
  sınıfın bir daha olmasını engelliyor).
- **`row(y, specs, gap)`**: bir dizi kutuyu panel genişliğine ortalanmış,
  aralarında sabit boşluklu bir sıra olarak yerleştirir — x koordinatlarını
  elle hesaplamak yerine.
- **`node_svg`/`arrow`/`panel`**: `render_graph.py`'dekiyle aynı fikir,
  ama etiketler `html.escape()`'den geçirilir (kullanıcı-görünür metin
  SVG'ye gömülürken `<`/`>`/`&` kaçışlanmazsa dosya bozulur).
- **6 panel**: Girdi (BSEB PDF + Excel register + banka dokümanları) →
  Çıkarım (registry.py, extract.py) → Çekirdek Motor (Document/Corpus
  Graph, ayrıntı için workflow_graph.svg'ye yönlendirme) → LLM (llm.py →
  kurumsal ağ geçidi → Qwen3) ve AD (directory.py, webapp/auth.py) yan
  yana → Arayüzler (CLI, Flask web arayüzü, KT marka kimliği) → Çıktı
  (JSON rapor).
- **`write(out_dir)`**: `proje_mimarisi.svg`'yi yazar. `main.py graph`'a
  bağlı DEĞİL — elle bakımı yapılan bir üst-seviye anlatım olduğu için
  (canlı graf nesnelerinden otomatik türetilmiyor); ayrı çalıştırılır:
  `python -m dokuman_inceleme.render_architecture`.

---

## `webapp/` + `run_web.py` — Çok Kullanıcılı Web Arayüzü (Flask)

**Streamlit tabanlı `app.py`'nin yerini aldı** (tek operatörlük, oturumsuz
bir araçtı; kaldırıldı). Buradaki gerekçe salt kozmetik değil: birden çok
kişinin **kendi AD hesabıyla** giriş yapıp **kendi taramalarını** görmesi
gerekiyor, ve bu, oturum/kimlik kavramı olmayan Streamlit'e doğal olarak
sığmıyordu. İş mantığı yine tekrar yazılmadı — `webapp/jobs.py` aynı
`graph.py`/`nodes/*` fonksiyonlarını çağırır.

```bash
cd /Users/eminesener/Desktop/dokuman_inceleme
.venv/bin/python run_web.py            # http://127.0.0.1:5000
```

### Mimari — neden arka plan thread'i + SSE

Bir tarama LLM gecikmesi yüzünden dakikalarca sürebilir. Flask'ın
senkron istek modelinde bunu tek bir HTTP isteğinde beklemek pratik
değil (tarayıcı/ara sunucu zaman aşımına uğrar). Çözüm:

```
POST /api/scan          → dosyaları kaydeder, ScanJob'ı arka plan thread'inde
                          başlatır, hemen run_id döner (istek BEKLEMEZ)
GET  /api/scan/<id>/events → Server-Sent Events: iş thread'i ilerledikçe
                          canlı satır satır akar (gerçek bir akış — Streamlit
                          sürümündeki uyku-tabanlı sahte akıştan farklı olarak)
GET  /api/scan/<id>/results → iş bitince sonuç HTML parçasını döner
```

- **`webapp/jobs.py`**:
  - `ScanJob` (dataclass): `run_id`, `owner` (kullanıcı adı), `status`
    (`running`/`done`/`error`), `log` (satır listesi, kilit korumalı),
    `result`. `emit()`/`finish()`/`fail()`/`snapshot_log(since)` — SSE
    endpoint'i `snapshot_log` ile "son okuduğum yerden itibaren yeni
    satırlar" alır.
  - `JOBS: dict[str, ScanJob]` — bellek-içi iş kaydı. Tek süreçli kurum
    içi bir araç için yeterli; birden çok worker sürecine
    (`gunicorn -w N`) ölçeklenecekse bu Redis/veritabanına taşınmalı.
  - `start_scan(cfg, owner, saved_paths)`: `ScanJob` oluşturur,
    `threading.Thread(daemon=True)` ile `_run_scan`'i başlatır.
  - `_run_scan(job, cfg, saved_paths)`: **`app.py`'deki `start` bloğunun
    birebir taşınmışı** — `extract_docx` → `build_search` →
    `build_document_graph` → her belge için `doc_graph.invoke()` →
    `reverse_scan` → (yetim varsa) `evidence_agent` → `recommend` →
    `render_report`. Tek fark: `st.status.write()` yerine `job.emit()`.
    Hata olursa `job.fail(traceback...)` — thread çöker ama Flask süreci
    çökmez, SSE `error` olayı istemciye ulaşır.
- **`webapp/auth.py`**: bkz. aşağıdaki "Giriş" bölümü.
- **`webapp/render.py`**: `VERDICT_LABEL`/`VERDICT_CLASS`/`VERDICT_PRIORITY`/
  `RING_LABEL`/`SEVERITY_LABEL`/`SEVERITY_CLASS` sözlükleri artık burada,
  Jinja filtresi olarak (`register_filters`) şablonlara bağlanıyor —
  `results.html` `{{ f.verdict|verdict_label }}` gibi kullanıyor.
- **`webapp/routes.py`**: tek `Blueprint` (`web`). `/login`, `/logout`,
  `/` (ana sayfa), `/profile` (banka profili — `app.py`'nin kenar
  çubuğundaki mantığın taşınmışı), `/api/llm-test`, `/api/scan`,
  `/api/scan/<id>/events`, `/api/scan/<id>/results`,
  `/api/scan/<id>/report.json`. **Sahiplik kontrolü her uçta**:
  `job.owner != current_user().username` ise `404` (403 değil — bir
  kaydın var olup olmadığı bilgisi bile başka bir kullanıcıya sızmasın
  diye).
- **`webapp/__init__.py`**: `create_app(cfg)` — Flask fabrikası.
  `FLASK_SECRET_KEY` boşsa süreç başına rastgele bir anahtar üretir
  (oturumlar yeniden başlatmada düşer) ve loglara uyarı yazar.
- **`run_web.py`**: paketin dışından mutlak import yapabilmek için
  `sys.path`'e üst dizini ekler (eski `app.py` ile aynı desen), `Config()`
  ve `create_app()`'i çağırıp `app.run(host=cfg.web.host, port=cfg.web.
  port, threaded=True)` yapar.

### Giriş (`webapp/auth.py`) — iki yol, tek arayüz

```
USE_LDAP_LOGIN=true   → AD'ye karşı doğrular: servis hesabıyla kullanıcıyı
                        bul (LDAP_LOGIN_SEARCH_FILTER, {username} yerine
                        giriş formundaki değer), sonra KENDİ parolasıyla
                        bağlanmayı dene. Parola hiç saklanmaz.
USE_LDAP_LOGIN=false  → (varsayılan) yerel demo hesap deposu — AD olmadan
                        arayüzü denemek için (`demo.kullanici`/`1234`).
```

Bu, **`directory.py`'den kasıtlı olarak ayrı**: `directory.py` bir
belgedeki ismin AD'de var olup olmadığını sorar (salt-okunur, parola
yok); `auth.py` gerçek bir insanın oturum açmasını doğrular (parola var,
tek seferlik LDAP bind). İkisi aynı `cfg.ldap.*` bağlantı bilgilerine
konuşur ama ayrı arama filtreleri kullanır
(`user_search_filter` vs `login_search_filter`) çünkü farklı sorular
sorarlar — bkz. `config.py:LDAPConfig` docstring'i. Login'in kendisi de
`LDAPConfig.enabled`'dan **bağımsız** bir bayrakla (`WebConfig.
use_ldap_login`) açılıp kapanır: biri "bu araca kim girebilir", diğeri
"bu aracın içindeki bir kontrol" — birbirini açıp kapatmaz.

- **`User`** (frozen dataclass): `username`, `display_name`, `email`.
  `to_session()`/`from_session()` — oturum çerezine sadece bu küçük
  profil yazılır, yetkiler her istekte yeniden hesaplanmaz çünkü şu an
  rol/yetki matrisi yok (istenirse `servicedesk_ai`'deki
  `capabilities/base.py` deseniyle eklenebilir).
- **`_ldap_authenticate`**: `directory.py::lookup_person`'a çok benzer bir
  bağlan-ara akışı, artık üçüncü bir adımla tamamlanıyor: bulunan DN'e
  kullanıcının kendi parolasıyla bağlanmayı dener (`ldap_auth.py`
  referans deseninin TAM hâli, `directory.py`'nin sadece ilk yarısını
  kullanmasının aksine). **Kurum bilgisayarında yaşanan gerçek arızadan
  sonra** (bkz. kardeş `servicedesk_ai` projesindeki `mrck/` — o klasör bu
  düzeltmeler taşındıktan sonra silindi) üç savunma eklendi:
  - **Boş adres koruması**: `cfg.server_uri` boşsa `ldap3` sessizce
    `localhost:389`'a bağlanmaya çalışıp "Connection refused" verir —
    gerçek neden ("adres hiç ayarlanmamış") görünmez kalır. Artık
    bağlanmadan önce açıkça hata basılıp `None` dönüyor.
  - **Servis hesabı olmadan giriş (self-bind)**: `LDAP_BIND_DN` boşsa,
    kullanıcı arama adımı servis hesabı yerine kullanıcının KENDİ
    hesabıyla (UPN olarak, `upn_suffixes[0]` ile tamamlanmış) yapılır.
    Bağlantı kurulduysa parola zaten doğrulanmıştır — ayrı 3. adım
    (`self_bind` ise) atlanır. Bu, IT'den servis hesabı beklemeden AD
    girişini denemeyi mümkün kılıyor.
  - **`_build_login_filter`**: `{account}` (çıplak hesap adı) ve
    `{email}` (hesap+ilk UPN soneki) AYRI yer tutucular — tek bir
    `{username}`'i hem `sAMAccountName` hem `mail` alanına aynı anda
    vermek yanlış (`sAMAccountName=esener` ile `mail=esener` farklı
    sorgulardır; ikincisi tam adres ister). Kurumda TAM OLARAK bu yüzden
    `(mail={username})` filtresiyle kullanıcı bulunamamıştı. Eski
    tek-yer-tutuculu filtreler `{username}`'in filtrenin `mail`/
    `userPrincipalName` araması yapıp yapmadığına bakılarak otomatik
    `{account}`/`{email}`'e çevrilir, geriye dönük uyumluluk bozulmaz.
  - `LDAPConfig.server_uri` artık `LDAP_SERVER_URI` VEYA (kardeş
    projenin kullandığı kısa ad) `LDAP_SERVER`'ı okur — ayar adı
    farkının aynı "boş adres" arızasına yol açtığı bir kez daha
    görülmüştü.
- **`_demo_authenticate`**: sabit-zamanlı karşılaştırma
  (`hmac.compare_digest`) — kullanıcı bulunamasa bile hash hesaplanır,
  "var mı yok mu" bilgisi yanıt süresinden sızmasın diye.
  `demo_accounts(cfg)` giriş ekranında gösterilecek listeyi döner; AD
  girişi açıkken ya da `SHOW_DEMO_ACCOUNTS=false` iken boş liste.
- **`login_required`**: `current_user() is None` ise `/api/*` isteğine
  `401` JSON, sayfa isteğine `/login?next=...`'e yönlendirme.

### Şablonlar ve statik dosyalar

- **`templates/base.html`**: üst gezinme çubuğu (logo, kullanıcı adı,
  çıkış), tüm giriş-gerektiren sayfaların iskeleti.
- **`templates/login.html`**: bağımsız (base'i extend etmez) — ortalanmış
  kart, logo, demo hesap kutusu (varsa).
- **`templates/index.html`**: bağlantı testi, sürükle-bırak yükleme
  alanı, canlı konsol paneli, sonuç konteyneri (JS ile doldurulur),
  kullanıcının son 10 taraması.
- **`templates/results.html`**: **kısmi şablon** — `render_template`
  ile HTML string olarak üretilip `/api/scan/<id>/results` yanıtı olarak
  dönüyor, istemci bunu `innerHTML` ile enjekte ediyor (bkz. `app.js`).
  Hüküm bazlı kartlar, rozetler, kanıt alıntıları, tavsiye metni —
  Streamlit sürümündeki kart tasarımının aynısı, artık gerçek HTML/CSS.
- **`templates/profile.html`**: banka profili formu — 15 koşul için
  radyo düğmeleri, `POST /profile` ile kaydedilir.
- **`static/css/app.css`**: marka rengi (`#43B02A`, logodan örneklendi)
  CSS değişkeni olarak (`--brand`); `.kt-console` canlı günlük paneli
  (koyu, terminal görünümlü, her satır `kt-fade-in` animasyonuyla belirir
  — SSE'den gelen satırların "akarak" yazılması hissi buradan gelir);
  `.kt-card`/`.kt-badge` hüküm renklendirmesi (Streamlit sürümüyle aynı
  palet: uygun=marka yeşili, kısmi=amber, çelişkili/belirtilmemiş=kırmızı,
  inceleme gerekli=mor, kapsam dışı=gri).
- **`static/js/app.js`**: sürükle-bırak dosya seçimi; form gönderimi
  `fetch`/`FormData` ile `/api/scan`'e; `EventSource` ile SSE dinleme,
  her satırı konsola ekleyip ilerleme çubuğunu **tahmini** olarak
  ilerletme (gerçek toplam adım sayısı önceden bilinmiyor, `done`
  olayında kesin %100); iş bitince `/results`'ı çekip DOM'a enjekte etme;
  dinamik içerik olay devretme (`document.addEventListener` + `closest`)
  ile açılıp kapanan belge/bulgu kartları.
- **`static/img/logo.png`**: `data/kt-yesil-logo-yatay.png`'nin bir
  kopyası — Flask statik dosyaları `static/` altından servis eder,
  `data/`'ya doğrudan erişemez.

---

## `data/`, `documents/`, `prompts/` — Veri Klasörleri

- **`data/bseb_register.xlsx`**: Regülasyonun kendisi, 255 satırlık
  register + 54'lük konu sözlüğü + 15'lik koşul kodları sayfası olarak.
  Kod hiçbir zaman BSEB PDF'ini çalışma zamanında parse etmez — bu Excel
  dosyası elle bir kere üretilmiş, tekrar üretilebilir/diff'lenebilir
  asıl varlıktır.
- **`data/bank_profile.json`**: 15 koşullu gereksinimin banka-özel
  cevapları (bkz. `config.py::load_bank_profile`).
- **`data/kt-yesil-logo-yatay.png`**: Kuveyt Türk kurumsal logosu — asıl
  kopya burada; `webapp/static/img/logo.png` (Flask'ın statik dosya
  sunumu `data/`'ya doğrudan erişemediği için) bunun bir kopyasıdır.
  Marka yeşili (`#43B02A`) buradan örneklenip `webapp/static/css/app.css`
  ve `templates/*.html`'deki rozet/kart renklerine taşınmıştır.
- **`documents/`**: taranacak örnek `.docx` dosyaları.
- **`prompts/`**: şu an boş — tüm sistem promptları ilgili node
  dosyalarının içinde sabit string olarak tutuluyor (`TOPIC_SYSTEM`,
  `CORE_SYSTEM` gibi), ayrı dosyalara çıkarılmamış.

---

## Uçtan uca akış özeti

```
main.py (CLI) veya run_web.py (çok kullanıcılı web arayüzü, webapp/)
  │
  ├─ extract.py           .docx → bloklar + markdown
  ├─ registry.py           Excel → 255 gereksinim + 54 konu
  ├─ llm.py                 OpenAI-uyumlu / kurumsal ağ geçidi istemcisi
  │
  └─ graph.py  (LangGraph)
       │
       ├─ document graph  (nodes/ingest.py, profile.py, metadata_rules.py,
       │                    evaluate.py)
       │     ingest → profile_document → select_topics → recall_guard
       │     → check_metadata → expand_requirements
       │     ⇉ evaluate_core / evaluate_border  (fan-out, bir gereksinim = bir dal)
       │     → verify_citations (verify.py) → challenge → route_for_review
       │
       └─ corpus graph    (nodes/corpus.py)
             review_documents (belge grafını her dosya için çalıştırır)
             → reverse_scan → [yetim varsa] evidence_agent (search.py, BM25)
             → recommend → render_report
             → output/report/findings_<run_id>.json
```
