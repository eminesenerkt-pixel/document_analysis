# -*- coding: utf-8 -*-
"""Runtime configuration.

Everything that changes between environments is read from the environment, and
the environment is filled from a `.env` file next to the package. Nothing
secret is hard-coded here and nothing secret belongs in the repository —
`.env` is git-ignored, `.env.example` is the template that is committed.

The corporate LLM endpoint is assumed to be OpenAI-compatible (vLLM, TGI,
LiteLLM gateway and most in-house gateways expose that shape).
"""
from __future__ import annotations
import json
import os
from dataclasses import dataclass, field
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent

# Ekranın alt bilgisinde ve açılışta konsolda görünür. Kod başka bir makineye
# kopyalandığında "gerçekten yeni sürüm mü çalışıyor?" sorusunun cevabı budur
# — kod değiştikçe güncellenmeli.
APP_VERSION = "2026-10-09 · bölüm bazlı birleştirme + üç rapor"


# ----------------------------------------------------------------- .env
def load_env(path: str | Path | None = None, override: bool = False) -> Path | None:
    """Minimal dotenv reader — no dependency, because a locked-down corporate
    Python may not have python-dotenv and this is fifteen lines.

    Real environment variables win over the file unless override=True, so a
    scheduler or a CI job can still set LLM_API_KEY without editing anything.
    """
    env_path = Path(path) if path else Path(os.getenv("ENV_FILE") or PACKAGE_DIR / ".env")
    if not env_path.is_file():
        return None
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip()
        if value[:1] == value[-1:] and value[:1] in ("'", '"'):
            value = value[1:-1]
        if override or key not in os.environ:
            os.environ[key] = value
    return env_path


ENV_FILE = load_env()

# Paths are anchored to the package, not the working directory, so the same
# command works from a scheduler, a notebook or a shell in any folder.
ROOT = Path(os.getenv("WORKFLOW_ROOT") or PACKAGE_DIR)


def _p(relative: str) -> str:
    return str(ROOT / relative)


def _env(name: str, default: str) -> str:
    return os.getenv(name) or default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ[name])
    except (KeyError, ValueError):
        return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ[name])
    except (KeyError, ValueError):
        return default


def _env_bool(name: str, default: bool) -> bool:
    return _env(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


def _env_list(name: str, default: str = "") -> list[str]:
    return [item.strip() for item in _env(name, default).split(",") if item.strip()]


def _env_path(name: str, default: str = "") -> str:
    """A relative path (e.g. `certs/kurum-ca.pem`) resolves against the
    package directory, not the process's working directory — otherwise a
    service/scheduler started from elsewhere silently fails to find the
    corporate CA bundle."""
    value = _env(name, default)
    if not value:
        return ""
    p = Path(value).expanduser()
    return str(p if p.is_absolute() else PACKAGE_DIR / p)


@dataclass
class LLMConfig:
    base_url: str = field(
        default_factory=lambda: _env("LLM_BASE_URL", "http://localhost:8000/v1"))
    api_key: str = field(default_factory=lambda: _env("LLM_API_KEY", "not-needed"))
    model: str = field(default_factory=lambda: _env("LLM_MODEL", "Qwen/Qwen3-235B-A22B"))
    timeout_s: int = field(default_factory=lambda: _env_int("LLM_TIMEOUT", 180))
    max_retries: int = field(default_factory=lambda: _env_int("LLM_MAX_RETRIES", 3))

    # Floor seconds between outgoing requests, across all threads. 0 means no
    # throttle (fine for a corporate gateway with real capacity). Set this if
    # the endpoint enforces a per-minute token/request budget lower than what
    # evaluate_core/evaluate_border's fan-out (one thread per candidate
    # requirement) would otherwise burst past before a single 429 comes back.
    min_interval_s: float = field(
        default_factory=lambda: _env_float("LLM_MIN_INTERVAL", 0.0))

    # Upper bound on the model's answer, sent as `max_tokens`. Left unset
    # (0), most servers fall back to their own default, which can silently
    # truncate a JSON answer or — if thinking mode is left on — let a single
    # call run to the model's full context. The schema response here is
    # modest (verdict + a few quotes + a paragraph of rationale); this caps
    # runaway generation rather than shaping normal answers.
    max_tokens: int = field(default_factory=lambda: _env_int("LLM_MAX_TOKENS", 2000))

    # Total context budget (input + output combined) the DEPLOYMENT actually
    # enforces — not a property of the model architecture, and not something
    # this codebase can discover on its own. Qwen3-235B-A22B's own native
    # window is far larger than most self-hosted servings actually expose;
    # this in-house gateway (vllm-qwen3-235b-fp8) was measured at 16384 by a
    # real 400 response ("model's context length is only 16384 tokens") once
    # a large call (reverse_check, register + a document chunk) crossed it.
    # Every complete_json/_stream call clamps its own `max_tokens` against
    # this so a large prompt shrinks the answer budget instead of the
    # request being rejected outright — set this to match whatever gateway
    # you actually point LLM_BASE_URL at.
    context_window: int = field(
        default_factory=lambda: _env_int("LLM_CONTEXT_WINDOW", 16384))

    # ---------------------------------------------------- corporate gateway
    # An in-house gateway (e.g. APISIX in front of a self-hosted vLLM/TGI
    # server) rarely speaks plain "Authorization: Bearer <key>" — the
    # key-auth plugin typically wants its own header name with no prefix.
    # Defaults below reproduce plain Bearer auth, so a standard
    # OpenAI-compatible endpoint needs no changes; only a gateway with its
    # own auth scheme needs to override them.
    api_key_header: str = field(
        default_factory=lambda: _env("LLM_API_KEY_HEADER", "Authorization"))
    api_key_prefix: str = field(
        default_factory=lambda: _env("LLM_API_KEY_PREFIX", "Bearer"))
    # "Name: value; Name2: value2" — extra routing headers a gateway may
    # require (consumer id, tenant, trace id).
    extra_headers_raw: str = field(
        default_factory=lambda: _env("LLM_EXTRA_HEADERS", ""))
    # An internal hostname usually sits behind the corporate root CA rather
    # than a public one. If set, verification stays ON against this bundle
    # instead of being switched off.
    ca_bundle: str = field(default_factory=lambda: _env_path("LLM_CA_BUNDLE", ""))
    verify_ssl: bool = field(default_factory=lambda: _env_bool("LLM_VERIFY_SSL", True))
    # Qwen3 (this project's target model) reasons before every answer by
    # default, wrapping it in a <think>...</think> block — several times the
    # token cost and latency of the answer itself, for no benefit on a
    # schema-constrained yes/no-shaped judgement call. On by default; a
    # server that does not recognise the field ignores it harmlessly.
    disable_thinking: bool = field(
        default_factory=lambda: _env_bool("LLM_DISABLE_THINKING", True))

    @property
    def extra_headers(self) -> dict:
        headers = {}
        for part in self.extra_headers_raw.split(";"):
            name, sep, value = part.partition(":")
            if sep and name.strip():
                headers[name.strip()] = value.strip()
        return headers

    @property
    def verify(self):
        """What httpx's `verify=` wants: a CA bundle path, or a bool."""
        return self.ca_bundle or self.verify_ssl

    @property
    def headers(self) -> dict:
        """Full request header set — the single source of truth so LLMClient
        and the CLI's own connectivity probes (`check`, `trace`) authenticate
        identically instead of `check` silently testing something different
        from what a real run sends."""
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            prefix = self.api_key_prefix.strip()
            headers[self.api_key_header] = (
                f"{prefix} {self.api_key}" if prefix else self.api_key)
        headers.update(self.extra_headers)
        return headers

    # Per-node sampling. Judgement nodes run cold, drafting nodes run warm.
    temperature_extract: float = 0.0     # profiling, topic selection
    temperature_judge: float = 0.0       # requirement evaluation
    temperature_draft: float = field(
        default_factory=lambda: _env_float("TEMPERATURE_DRAFT", 0.4))

    # Self-consistency: how many samples for high-risk requirements.
    samples_high_risk: int = field(
        default_factory=lambda: _env_int("SAMPLES_HIGH_RISK", 3))
    samples_default: int = 1
    self_consistency_temperature: float = 0.3


@dataclass
class PathConfig:
    register_xlsx: str = field(
        default_factory=lambda: _env("REGISTER_XLSX", _p("data/bseb_register.xlsx")))
    bank_profile_json: str = field(
        default_factory=lambda: _env("BANK_PROFILE_JSON", _p("data/bank_profile.json")))
    topics_sheet: str = "Konu Sözlüğü"
    register_sheet: str = "Register"
    documents_dir: str = field(
        default_factory=lambda: _env("DOCUMENTS_DIR", _p("documents")))
    extract_dir: str = field(
        default_factory=lambda: _env("OUTPUT_DIR", _p("output")) + "/extract")
    report_dir: str = field(
        default_factory=lambda: _env("OUTPUT_DIR", _p("output")) + "/report")
    checkpoint_db: str = field(
        default_factory=lambda: _env("OUTPUT_DIR", _p("output")) + "/checkpoints.sqlite")


def load_bank_profile(path: str) -> dict[str, bool]:
    """Answers to the register's conditional requirements (kosul_kodu).

    Kept in a JSON file rather than .env: there are sixteen of them, they are
    not secret, and they are an auditable statement about the bank that someone
    has to sign off. An unanswered condition is not silently dropped — the
    requirement is routed to human review.
    """
    p = Path(path)
    if not p.is_file():
        return {}
    data = json.loads(p.read_text(encoding="utf-8"))
    return {k: bool(v) for k, v in data.items()
            if not k.startswith("_") and isinstance(v, bool)}


@dataclass
class PolicyConfig:
    # Tracked-change policy for extraction: accepted | original | all
    tracked_changes: str = field(
        default_factory=lambda: _env("TRACKED_CHANGES", "accepted"))

    # A document longer than this is chunked instead of passed whole.
    max_document_tokens: int = field(
        default_factory=lambda: _env_int("MAX_DOCUMENT_TOKENS", 15_000))

    # Verdict is escalated to human review below this confidence.
    review_threshold: float = field(
        default_factory=lambda: _env_float("REVIEW_THRESHOLD", 0.6))

    # Requirements whose risk level triggers multi-sample evaluation.
    high_risk_levels: tuple[str, ...] = ("Kritik", "Yüksek")

    # Evidence agent: how many search rounds before it must decide.
    evidence_search_rounds: int = field(
        default_factory=lambda: _env_int("EVIDENCE_SEARCH_ROUNDS", 4))

    # reverse_check (belge -> BSEB): the document is split into chunks of at
    # most this many characters, each checked against the full 255-rule
    # register in its OWN call, instead of one call holding the whole
    # document in mind at once alongside the whole register. A document
    # under this size becomes a single chunk — no artificial splitting.
    reverse_check_chunk_chars: int = field(
        default_factory=lambda: _env_int("REVERSE_CHECK_CHUNK_CHARS", 3000))

    # reverse_check: the 255-rule register is ALSO split, into groups of at
    # most this many rules, each sent in its own call alongside a document
    # chunk — rather than the full register (measured at ~8000 tokens, half
    # of this deployment's 16384-token context window) riding along with
    # EVERY document chunk. Splitting the register is what actually buys
    # room for `disable_thinking=False`'s reasoning block; clamping
    # `max_tokens` (see llm.py::_safe_max_tokens) only stopped the crash, it
    # did not give the model any more room to think.
    reverse_check_rules_per_batch: int = field(
        default_factory=lambda: _env_int("REVERSE_CHECK_RULES_PER_BATCH", 50))

    # Bank profile answers for conditional requirements (kosul_kodu).
    condition_flags: dict[str, bool] = field(default_factory=dict)


@dataclass
class LDAPConfig:
    """Read-only directory lookup for REQ-5.3 (approval authority).

    NOT a login/auth flow — no password is ever handled here. The question
    is "does the name a document lists as approver/owner correspond to a
    real, active corporate account?", answered with the service account's
    own bind, the same way `ldap_auth.py`'s steps 1-2 look a user up before
    it ever touches their password (step 3 there is irrelevant here).

    Off by default (`enabled=False`): a document set can be scanned and a
    compliance report produced with zero network dependency beyond the LLM
    endpoint. Turning this on adds one more external system a run depends
    on, so it is opt-in rather than assumed.
    """
    enabled: bool = field(default_factory=lambda: _env_bool("LDAP_ENABLED", False))
    # LDAP_SERVER: a sibling in-house project uses this shorter name for the
    # same setting — accepted as a fallback so pasting its .env block here
    # doesn't silently leave the address empty (which makes ldap3 try
    # localhost:389 with no indication why — this bit a real deployment).
    server_uri: str = field(
        default_factory=lambda: _env("LDAP_SERVER_URI", "").strip() or _env("LDAP_SERVER", "").strip())
    use_ssl: bool = field(default_factory=lambda: _env_bool("LDAP_USE_SSL", True))
    # Service account for LOOKUPS (directory.py) and, if set, for the LOGIN
    # search too (webapp/auth.py). Left empty, webapp/auth.py's login falls
    # back to binding as the user's own account instead — see that module.
    bind_dn: str = field(default_factory=lambda: _env("LDAP_BIND_DN", ""))
    bind_password: str = field(default_factory=lambda: _env("LDAP_BIND_PASSWORD", ""))
    user_search_base: str = field(default_factory=lambda: _env("LDAP_USER_SEARCH_BASE", ""))
    # {name} is substituted with the (filter-escaped) name pulled from the
    # document's approver/owner field. Wildcards because a document's typed
    # name rarely matches AD's stored displayName byte-for-byte (casing,
    # middle names, Turkish characters).
    user_search_filter: str = field(
        default_factory=lambda: _env(
            "LDAP_USER_SEARCH_FILTER",
            "(&(objectClass=user)(|(displayName=*{name}*)(cn=*{name}*)))"))
    # {username} is what a person types into the web app's login form —
    # an exact-match lookup, unlike the fuzzy {name} filter above. Kept as
    # its own field rather than reusing user_search_filter: the two answer
    # different questions (who typed this vs who does this name belong to)
    # even though both run against the same AD server/service account.
    #
    # {account} (bare, domain-stripped) and {email} (account+first UPN
    # suffix) are substituted separately — see webapp/auth.py::
    # _build_login_filter. A single {username} fed into both
    # sAMAccountName and mail at once is wrong: "sAMAccountName=esener"
    # and "mail=esener" are not the same query, one needs the bare account
    # and the other needs the full address. This exact mismatch broke a
    # real login (filter was "(mail={username})", typed value got reduced
    # to the bare account, so it searched for "mail=esener" instead of
    # "mail=esener@kurum.com.tr" and never found the entry).
    login_search_filter: str = field(
        default_factory=lambda: _env(
            "LDAP_LOGIN_SEARCH_FILTER",
            "(|(sAMAccountName={account})(mail={email})(userPrincipalName={email}))"))
    # First entry is used to build {email} from a bare account name, and to
    # self-bind (see webapp/auth.py) when LDAP_BIND_DN is empty. Comma-
    # separated because a bank's mail domain and its internal AD domain are
    # often different (ör. mail @kurum.com.tr, AD suffix @kurum.local).
    upn_suffixes: list[str] = field(
        default_factory=lambda: _env_list("LDAP_UPN_SUFFIXES", ""))
    # ldap3's Server(connect_timeout=...) hits a low-level socket call that
    # wants a plain int; a float here (5.0) throws "required argument is not
    # an integer" the moment it tries to open a socket — before it ever
    # reaches the network, so it fails identically against every candidate
    # address a multi-DC domain name resolves to. Kept int to match the
    # sibling project (servicedesk_ai), where this exact setting is proven
    # working against the same AD.
    connect_timeout: int = field(
        default_factory=lambda: _env_int("LDAP_CONNECT_TIMEOUT", 5))
    receive_timeout: int = field(
        default_factory=lambda: _env_int("LDAP_RECEIVE_TIMEOUT", 10))
    max_retries: int = field(default_factory=lambda: _env_int("LDAP_MAX_RETRIES", 2))
    retry_delay: float = field(default_factory=lambda: _env_float("LDAP_RETRY_DELAY", 1.0))


@dataclass
class WebConfig:
    """Multi-user Flask app (`webapp/`) settings.

    Independent of `LDAPConfig.enabled` on purpose: a bank may want AD
    login for the tool itself without turning on the (separate, opt-in)
    approver/owner directory cross-check, or vice versa — one gates who can
    open the app, the other gates one compliance check inside it.
    """
    host: str = field(default_factory=lambda: _env("WEB_HOST", "127.0.0.1"))
    port: int = field(default_factory=lambda: _env_int("WEB_PORT", 5000))
    # Ephemeral if unset: sessions do not survive a restart. Set
    # FLASK_SECRET_KEY in .env for a deployment that should keep users
    # logged in across restarts.
    secret_key: str = field(default_factory=lambda: _env("FLASK_SECRET_KEY", ""))
    use_ldap_login: bool = field(default_factory=lambda: _env_bool("USE_LDAP_LOGIN", False))
    show_demo_accounts: bool = field(
        default_factory=lambda: _env_bool("SHOW_DEMO_ACCOUNTS", True))
    # Banka profili (bank_profile.json) TÜM kullanıcıların taramalarını
    # etkileyen ortak bir beyandır. Virgülle ayrılmış kullanıcı adları
    # (giriş sonrası oturumdaki hâliyle, ör. AD'de e-posta) yalnızca bu
    # kişilerin profili değiştirmesine izin verir. Boş bırakılırsa (demo
    # kurulum) herkes değiştirebilir — üretimde mutlaka doldurulmalı.
    profile_editors: list[str] = field(
        default_factory=lambda: [u.lower() for u in _env_list("PROFILE_EDITORS", "")])

    def can_edit_profile(self, username: str) -> bool:
        return not self.profile_editors or (username or "").lower() in self.profile_editors


@dataclass
class Config:
    llm: LLMConfig = field(default_factory=LLMConfig)
    paths: PathConfig = field(default_factory=PathConfig)
    policy: PolicyConfig = field(default_factory=PolicyConfig)
    ldap: LDAPConfig = field(default_factory=LDAPConfig)
    web: WebConfig = field(default_factory=WebConfig)
    run_id: str = ""

    def __post_init__(self) -> None:
        if not self.policy.condition_flags:
            self.policy.condition_flags = load_bank_profile(self.paths.bank_profile_json)


DEFAULT = Config()
